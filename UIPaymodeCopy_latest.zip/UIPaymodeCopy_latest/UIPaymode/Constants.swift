//
//  Constants.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 27/12/16.
//  Copyright © 2016 WorldlineMacbook2. All rights reserved.
//

import UIKit


var gSessionID : String = "0"
var gUsername : String = ""
var gRefferenceNumber = NSArray()
var gBankCode = "00035"
var gDeviceID = ""

// ip address & port number
let ipAddress = ""
let portNumber = ""
let bankCode = "00035"


let commonTxtColor : UIColor = UIColor.white
let paymodeCategoryArray = ["Transaction Limit" , "In Store Transactions" , "ATM Withdrawals" , "Internet Transaction" , "Merchant category" , "Foreign Transaction" , "Hotlist card"]

// theme colors
let mainBackGroundColor : UIColor = UIColor(red: 0/255, green: 103/255, blue: 161/255, alpha: 1)

let secondaryBackGroundColor : UIColor = UIColor.white

let tertiaryBackgroundColor : UIColor = UIColor.gray

let shadowColor : UIColor = UIColor.black
let primaryColorHex : UInt = 0xDE2417
let secondaryColorHex : UInt = 0x00579b
let primaryColor : UIColor = UIColor(string:"#DE2417")// red
let secondaryColor:UIColor = UIColor(string: "#00579b")//dark blue
let secondaryblurColor : UIColor = UIColor(string:"#056398")// blue
let accentColor : UIColor = UIColor(string: "#33CD5D") // green color
let hintColor : UIColor = UIColor(string: "#BCBCBC") // grey

//let textFieldBorderColorPrimary : UIColor = primaryColor

// button corner radius
let cornerRadius : CGFloat = 20

// login length validations
let usernameLength : Int = 5
let passwordLength : Int = 5


// floating label
let floatingLabelColor : UIColor = primaryColor
let shadowRad = 5


//home tableview array
let homeCategoryArray  : [String] = ["Card State" , "Recent Transactions" , "Expense History" , "Expense Graph" , "Availiable Balance"]

// string url
let commonURL : String  = "http://192.168.32.213:8080/PayModGlobal/services/MainService/masterService?"
//"http://115.113.36.187:8080/PayModGlobal/services/MainService/masterService?"
// textfield extension
extension UITextField{
    
    convenience init(_ coder: NSCoder? = nil) {
        self.init()
        
        self.backgroundColor = secondaryBackGroundColor
        self.textColor = UIColor.black
        
    }
}

let payModeArray : NSArray = [
    ["header":"Transaction Limit","message" : "Set transaction limit for your selected card. Please note the set limit would be maximum limit for a single transaction."] ,
    ["header":"In Store Transactions","message": "Enable/Disable transactions on swipe or chip card machines."],
    ["header": "ATM Withdrawals","message": "Enable/Disable withdrawals on ATM Machines"],
    ["header": "Internet Transactions","message": "Enable/Disable transactions over Internet."],["header": "Foreign Transactions","message": "Enable/Disable transactions on location outside your residing country."],
    ["header": "Card Limit","message": "Monthly Available Limit of the selected card"], ["header": "Transaction Limit","message": "Limit of the card on per transaction basis."],["header": "Hotlist Card","message": "This feature is for hotlisting the card."],["header": "Merchant Category","message": "This feature to limit transactions as per the categories defined."]];


let dialogueTitle : String = "Payment Modulator"


//response codes
let successResponseCode : Int = 0

//currencySymbol
let currencySymbol = " ₹"

//response constants
var responseCode : String = "responseCode"

// password message
var passwrdMessage = "Your password should be at least 8 - 20 characters long and should include at least one uppercase letter, one lowercase letter one number and one special character."


//home alert string array
let homeAlert : [String] = ["1.EMI options is availiable on Credit Card @ lowe interest rate." , "2.Get upto 4X Reward points with Signature Credit Card with added lifestyle benefits."]

class Constants: NSObject {
    
    

}
