//
//  mPinViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 22/12/16.
//  Copyright (c) 2016 WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol mPINDelegeate
{
    func submitMpinBtnClicked()
}

class mPinViewController: UIViewController {
    @IBOutlet weak var submitButtonOutlet: UIButton!
    @IBOutlet weak var mPinTextfield: UITextField!
    
    var delegate1 : mPINDelegeate?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.submitButtonOutlet.layer.borderColor = UIColor.white.cgColor
        self.submitButtonOutlet.layer.borderWidth = 2
        submitButtonOutlet.layer.cornerRadius = 20

        // Do any additional setup after loading the view.
    }
    
    
    func setDelegate(_ delegate:mPINDelegeate)
    {
        self.delegate1 = delegate
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func submitButtonClicked(_ sender: AnyObject) {
        
        print("clicked"+mPinTextfield.text!, terminator: "")
        delegate1?.submitMpinBtnClicked()
    }
    
    
    
    

}
