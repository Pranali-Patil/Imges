//
//  LoginViewPresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 23/01/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//


//{"session_id":"816960","username":"ubi2113","bankcode":"00035","reference_number":"c6654843cbd8862804316493b9e66526","update":{"Active":{"change_flag":"N","enable":"N"},"channels_list":[{"channel_id":0,"change_flag":"N","enable":"N"},{"channel_id":1,"change_flag":"Y","enable":"N"},{"channel_id":2,"change_flag":"N","enable":"N"},{"channel_id":3,"change_flag":"N","enable":"Y"},{"channel_id":4,"change_flag":"N","enable":"Y"}],"codes":{"mcc_codes":[],"country_codes":[]},"txn_limit":{"change_flag":"N","amount":"0"},"overall_limit":{"change_flag":"N","amount":"0"}},"mpin":"52c69e3a57331081823331c4e69d3f2e","class_name":"SetCardStatus","function":"setCardStatus"}

import UIKit
import Alamofire

class LoginViewPresenter: NSObject {
    
    // create protocol object
    var pLoginViewProtocolObj : PLoginViewCallBack?
    
    // object of model
    var loginModeObj : LoginModel?
    
    
    
    init(loginViewProtocolObj : PLoginViewCallBack)
    {
        pLoginViewProtocolObj = loginViewProtocolObj
    }
    
    
    // check validations
    func checkUsernamePwdValidations(userName : String , password : String) -> Bool
    {
        if((userName.characters.count) < usernameLength)    // username length validation
        {
            pLoginViewProtocolObj?.onErrorMessage(errorMsg: ("please enter valid user name"))
            return false
        }
            
        else if((password.characters.count) < passwordLength)   // password length validation
        {
            pLoginViewProtocolObj?.onErrorMessage(errorMsg: "please enter valid user name")
            return false
        }
        return true
    }
    
    
    // login hit
    func hitLoginserver(username : String , password : String)
    {
        
        
        //encrypted password
        //FIXME:- put algo on password
        let md5Data = CommonClass().MD5(string:password)
        let md5Hex =  md5Data!.map { String(format: "%02hhx", $0) }.joined()
        print("md5Hex: \(md5Hex)")

        let encrptedPwd = md5Hex//"cfd031fcae0f0dcb451dee4a6a1f792a"//md5Hex
        
        

        
        let stringUrl = commonURL + "param=%7B%27username%27:%27\(username)%27,%27password%27:%27\(encrptedPwd)%27,%27bankcode%27:%2700035%27,%27class_name%27:%27Login%27,%27function%27:%27userAuth%27%7D"
        //let stringURL = "https://\(ipAddress):\(portNumber)/CCA-Service/validateCardHolder/bankCode=\(bankCode)/cardHolderId=\(userNameTextfield.text!)/password=\(encrptedPwd)"
        
        
        
        CommunicationManager.sendGetURL(stringURL: stringUrl , onSuccess: { (response) in
            
            
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let test : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    self.loginModeObj = LoginModel(loginDict: test)
                    
                    if(self.loginModeObj?.successCode! == true)
                    {
                        self.pLoginViewProtocolObj?.onSuccessfulResponse(sessionID : (self.loginModeObj?.session_id!)!)
                    }
                    else
                    {
                        self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: (self.loginModeObj?.succeessMsg!)!)

                    }

                    
                    print(test)
                    
                    
                } else {
                    
                    self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: "error occurred")
                }
            }
            
            
            
            
            print(response!)
            
        }) { (error) in
            
            self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: (error?.localizedDescription)!)
        }
        
        
        
    }
    
    
    
    


    //ubi2113
    //Pass@1234
    
    
}
