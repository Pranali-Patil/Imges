//
//  ViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 20/12/16.
//  Copyright (c) 2016 WorldlineMacbook2. All rights reserved.
//
// 192.168.33.132
//ubi2113
//  ENCRYPTION_KEY="MZygpewJsCpRrfOr"
//var iv = "F27D5C9927726BCEFE7510B1BDD3D137";
//var salt = "3FF2EC019C627B945225DEBAD71A01B6985FE84C95A70EB132882F88C0A59A55";
//I/plain params: {"username":"9167400094","password":"40330be92f153a177e64684e466dd492","platform":"android","device_id":"c4J6sbDIN3k:APA91bHn-OXpAMFA9pZ6McF2nFYHH-rKB6uurYTuEh7qiKvCmQtpzf0CDs2DbGU5hWylxGIH64KeTiuJI6w7mBjq-XptSHFVIS4ad0k56EPWs1p3q3xkfl8LQA5bDZrI35wMXcpAUTwJ","bank_code":"00006","class_name":"Login","function":"authenticate"}
//01-23 16:25:59.810 27088-27088/com.worldlineindia.bob.merchant I/encrypted params: 8KwCUFgOuhmVEC3aH59leD+YjWQKk4UZEPbhlPPbZLajyzOEdsvWmbN8vP6b4QxCs4BCjq8IETeokPXtCXGRfrfvszODZ6hvLhvXzkj2+J2dCU50Zg3zMbUh3IrZF9sqxhCvfgNrt5dYEyOKlAS7N1nUf3Ccmwmr8VQjQxDQwB9HGXtANj5QYYiua5HB5Pk0eoN6HQSytL3LbGMU4GRzAK4OxTCFC/PAAeYSqRXn0fA6MrhLXYDU3r2uTgvFELtWuNwSPveK2vgWnrlzxVwDJ/cgWbQQwBbX8mTmA3yDlKtTPPiu8q+y4yBqwAyFZGSaRXbr81TX90y7B6MdY6T9uVOZWOc+5eQhM8SPmltOBWzUeeztT9X9KaMBtLVsZjdJylSosMmoBlR1dihIAiHV24uOyJ+vA9JQwlPJs4ys0iqb4mfkpWv5Dm+F72IDkfpj



//==========
//Byte[] value  ---  [B@c39f790
//Card number      ----     4391551100004036
//Encrypted card no ---  38C01C69B7D49AAF6F19D939C2F3E5EBA6B06D986A4AAEA8798C3ACDEE20D59D




//Previous Item	Next Item
//Connected to Microsoft Exchange


import UIKit
import SCLAlertView
import CryptoSwift
import Security


import JavaScriptCore
//import SwiftLuhn


class ViewController: UIViewController , UITextFieldDelegate {
  
    // button outlets
    @IBOutlet weak var loginButtonOutlet: UIButton!
    @IBOutlet weak var registerButtonOutlet: UIButton!
    @IBOutlet weak var forgotPwdOutlet: UIButton!
    
    
    // textfield outlets
    @IBOutlet weak var userNameTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    // Label Outlet
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var dontHaveAnAcctLabel: UILabel!
    
    // presenter object
    var loginViewPresenterObj : LoginViewPresenter?
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        

        //self.testAES()
        //self.test()
        // set dynamic UI theme
        self.doInitialThemeStatus()
        
        // disable login button
        loginButtonOutlet.alpha = 0.5
        loginButtonOutlet.isEnabled = false
        
        // set textfield delegates
        userNameTextfield.delegate = self
        passwordTextfield.delegate = self
        
        // local notifications to verify username pwd length
        NotificationCenter.default.addObserver(self, selector:#selector(textFieldLenghtVerify), name: NSNotification.Name(rawValue: "UITextFieldTextDidChangeNotification"), object: self.userNameTextfield)
        NotificationCenter.default.addObserver(self, selector:#selector(textFieldLenghtVerify), name: NSNotification.Name(rawValue: "UITextFieldTextDidChangeNotification"), object: self.passwordTextfield)
        
        // initialize presenter object
        //loginViewPresenterObj = LoginViewPresenter(loginViewProtocolObj: self)

    }
    
    
    // test text field lengths
    func textFieldLenghtVerify(notification:NSNotification)->Bool
    {
        // take out user name string from userName textfield
        let userName:String = userNameTextfield.text!
        
        // take out password string from password textfield
        let pwdValue:String = passwordTextfield.text!
        
        // set minimum username length equal to 5
        if (userName.characters.count >= usernameLength)
        {
            // set minimum password length equal to 8
            if (pwdValue.characters.count >= passwordLength)
            {
                // if both the conditions are true enable login button
                loginButtonOutlet.isEnabled = true
                
                // set login button lpha to 1
                loginButtonOutlet.alpha = 1.0
                
                // return true & end this function here
                return true
            }
                
                // password length is less than desired one then disable login button
            else
            {
                // disable login button
                loginButtonOutlet.isEnabled = false
                loginButtonOutlet.alpha = 0.5
            }
            
        }
            
            // if user name is less than desired one then disable login button
        else
        {
            // disable login button
            loginButtonOutlet.isEnabled = false
            loginButtonOutlet
                .alpha = 0.5
        }
        return false;
        
    }
    

    
    // do initial theme setup
    func doInitialThemeStatus()
    {
        self.view.backgroundColor = mainBackGroundColor
        
        loginButtonOutlet.backgroundColor = secondaryBackGroundColor
        registerButtonOutlet.backgroundColor = secondaryBackGroundColor
        
        registerButtonOutlet.titleLabel?.textColor = mainBackGroundColor
        registerButtonOutlet.titleLabel?.textColor = mainBackGroundColor
        forgotPwdOutlet.titleLabel?.textColor = mainBackGroundColor
        
        // set corner radius for buttons
        loginButtonOutlet.layer.cornerRadius = cornerRadius
        registerButtonOutlet.layer.cornerRadius = cornerRadius
        
        
        // set label colors
        welcomeLabel.textColor = secondaryBackGroundColor
        dontHaveAnAcctLabel.textColor = secondaryBackGroundColor
        
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    
    
    
    override func viewWillAppear(_ animated: Bool) {
    // hide navigation bar
    self.navigationController?.navigationBar.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
        
    // login buttonClicked
    @IBAction func loginButtonClicked(_ sender: Any) {
        
        // validate username & password length
        let checkLengthBool : Bool = (loginViewPresenterObj?.checkUsernamePwdValidations(userName: userNameTextfield.text!, password: passwordTextfield.text!))!
        
        if(checkLengthBool == true)
        {
            loginViewPresenterObj?.hitLoginserver(username: userNameTextfield.text!, password: passwordTextfield.text!)
        }
        
        else
        {
            self.alertView(stringMessage: "please enter valid user name & password")
        }
        
    }
    
    // on success
    func onSuccessfulResponse()
    {
        
    }
    
    // on failure
    func onErrorMessage(errorMsg : String)
    {
        // put an alert view
        self.alertView(stringMessage: errorMsg)
    }
    
    
    
    // function which shows alert message
    func alertView(stringMessage : String)
    {
        let appearance = SCLAlertView.SCLAppearance(
            kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
            kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
            kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!,
            showCloseButton: true
        )
        
        let alert = SCLAlertView(appearance: appearance)
        
        alert.showWarning("", subTitle: stringMessage)
    }

    
//    func test()
//    {
//        let commonJSPath = Bundle.main.path(forResource: "AesUtil", ofType: "js")
//        let fileContent = try? String(contentsOfFile: commonJSPath! as String, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
////        print(fileContent ?? String() )
//        
//        // create a javascript context environment and evaluate script
//        let context1 = JSContext()
//        
//            context1?.evaluateScript(fileContent as String!)
//        print(fileContent)
//            
//            // get reference to hello() function
//            let helloFunc = context1?.objectForKeyedSubscript("generateKey")
//            // execute hello() function with parameter
//            let helloValue = helloFunc?.call(withArguments: ["3FF2EC019C627B945225DEBAD71A01B6985FE84C95A70EB132882F88C0A59A55","F27D5C9927726BCEFE7510B1BDD3D137"])//,"MZygpewJsCpRrfOr","1233433"])
//            
////            // get reference to hola() function
//            let holaFunc = context1?.objectForKeyedSubscript("hello")
//            // execute hola() function with parameter
//            let holaValue = holaFunc?.call(withArguments: ["Bobby" , "sssdsds"])
//        
//            print(holaValue!) // print "Hello World!!!"
//            print(helloValue!)  // print "Hola Bobby Cómo estás
//        
//        
//
//    }
//    
//    // func to test AES
//    func testAES()
//    {
////        var  context: JSContext? = {
////=========================================================================
//        
//            // 1
////             let commonJSPath = Bundle.main.path(forResource: "mylib", ofType: "js")
////            let fileContent = try? String(contentsOfFile: commonJSPath! as String, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
////            print(fileContent )
////            
////            // create a javascript context environment and evaluate script
////                    let context1 = JSContext()
////            
////            for i in 0...10
////            {
////                context1?.evaluateScript(fileContent as String!)
////                
////                // get reference to hello() function
////                let helloFunc = context1?.objectForKeyedSubscript("hello")
////                // execute hello() function with parameter
////                let helloValue = helloFunc?.call(withArguments: ["World!!!"])
////                
////                // get reference to hola() function
////                let holaFunc = context1?.objectForKeyedSubscript("hola")
////                // execute hola() function with parameter
////                let holaValue = holaFunc?.call(withArguments: ["Bobby" , "sssdsds"])
////                
////                print(helloValue!) // print "Hello World!!!"
////                print(holaValue!)  // print "Hola Bobby Cómo estás
////
////            }
//        
//        //====================
//            
//            // 2
////            do {
////                let common = try String(contentsOfFile: commonJSPath, encoding: String.Encoding.utf8)
////                _ = context?.evaluateScript(common)
////            } catch (let error) {
////                print("Error while processing script file: \(error)")
////            }
//            
////            return context1
////        }()
//        
//        
//        let salt : Data = "3FF2EC019C627B945225DEBAD71A01B6985FE84C95A70EB132882F88C0A59A55".data(using: .utf8)!
//        // MZygpewJsCpRrfOr
//        let key : Data = BBAES.key(bySaltingPassword: "MZygpewJsCpRrfOr", salt: salt, keySize: BBAESKeySize.size128, numberOfIterations: BBAESSaltDefaultLength)
//        
//        
//        
//        
//        
//        //
//////        NSString *secretMessage = @"My secret message.";
//////        NSLog(@"Original message: %@", secretMessage);
//        let testDict : NSDictionary = ["username":"9167400094","password":"40330be92f153a177e64684e466dd492","platform":"android","device_id":"c4J6sbDIN3k:APA91bHn-OXpAMFA9pZ6McF2nFYHH-rKB6uurYTuEh7qiKvCmQtpzf0CDs2DbGU5hWylxGIH64KeTiuJI6w7mBjq-XptSHFVIS4ad0k56EPWs1p3q3xkfl8LQA5bDZrI35wMXcpAUTwJ","bank_code":"00006","class_name":"Login","function":"authenticate"]
//        
//
//        let secretMessage : NSString = NSString(format: " %@", testDict)//"123"
//        print( secretMessage)
//
//        
//        //let iv : Data = "F27D5C9927726BCEFE7510B1BDD3D137".data(using: .utf8)!
//        let iv : Data = BBAES.iv(from: "F27D5C9927726BCEFE7510B1BDD3D137")
//        
//        let str : String = BBAES().getHashKey()
//        
//        do
//        {
//            try(print(secretMessage.aesEncrypt(str, iv: "F27D5C9927726BCEFE7510B1BDD3D137")!))
//        }
//
//        catch
//        {
//        }
//        //print(secretMessage.aesEncrypt(str, iv: "F27D5C9927726BCEFE7510B1BDD3D137")!)
//        
//        let keyData = str.data(using: .utf8)
//
//        
//        let encryptedString : NSString = secretMessage.bb_AESEncryptedString(forIV: iv, key: keyData, options: BBAESEncryptionOptions.includeIV) as NSString//secretMessage.bb_AESDecryptedString(forIV: iv, key: key) as NSString
//        print(encryptedString)
//        
//        
////        NSString *decryptedMessage = [encryptedString bb_AESDecryptedStringForIV:nil key:key];
////        NSLog(@"Decrypted message: %@", decryptedMessage);
//        
////        let decryptedMessage = encryptedString.bb_AESDecryptedString(forIV: iv, key: salt) as? String
////        
////        print(decryptedMessage)
//        
////        NSString *encryptedString = [secretMessage bb_AESEncryptedStringForIV:[BBAES randomIV] key:key options:BBAESEncryptionOptionsIncludeIV];
////        NSLog(@"Encrypted message: %@", encryptedString);
//        
//                
//        
//        
//    }
    
    

}

extension NSString {
    
    func aesEncrypt(_ key: String, iv: String) throws -> String? {
        guard let data = self.data(using: String.Encoding.utf8.rawValue) else {
            return nil
        }
        let enc = try AES(key: key, iv: iv, blockMode:.CBC).encrypt(data)
        let encData = Data(bytes: enc, count: Int(enc.count))
        let base64String: String = encData.base64EncodedString(options: Data.Base64EncodingOptions.init(rawValue: 0))
        let result = String(base64String)
        return result
    }

}


