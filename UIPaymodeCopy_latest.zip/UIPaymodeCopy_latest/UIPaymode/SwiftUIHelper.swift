//
//  SwiftUIHelper.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 01/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//
//{'session_id':'328562','username':'ubi1123','bankcode':'00035','reference_number':'0c28db064011a895157cc307bfda4a04','update':{'Active':{'change_flag':'N','enable':'N'},'channels_list':[{'channel_id':0,'change_flag':'N','enable':'Y'},{'channel_id':1,'change_flag':'N','enable':'N'},{'channel_id':2,'change_flag':'N','enable':'Y'},{'channel_id':3,'change_flag':'N','enable':'Y'},{'channel_id':4,'change_flag':'N','enable':'N'}],'codes':{'mcc_codes':[],'country_codes':[]},'txn_limit':{'change_flag':'Y','amount':'110.0'},'overall_limit':{'change_flag':'N','amount':'11000.0'}},'mpin':'7a21f06ab31f3698d1ea224d03cf6a32','class_name':'SetCardStatus','function':'setCardStatus'}

import UIKit

class SwiftUIHelper: NSObject {
    
    

}


//MARK:Color extension
extension UIColor {
    convenience init(string: String) {
        var chars = Array(string.hasPrefix("#") ? string.characters.dropFirst() : string.characters)
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 1
        switch chars.count {
        case 3:
            chars = [chars[0], chars[0], chars[1], chars[1], chars[2], chars[2]]
            fallthrough
        case 6:
            chars = ["F","F"] + chars
            fallthrough
        case 8:
            alpha = CGFloat(strtoul(String(chars[0...1]), nil, 16)) / 255
            red   = CGFloat(strtoul(String(chars[2...3]), nil, 16)) / 255
            green = CGFloat(strtoul(String(chars[4...5]), nil, 16)) / 255
            blue  = CGFloat(strtoul(String(chars[6...7]), nil, 16)) / 255
        default:
            alpha = 0
        }
        self.init(red: red, green: green, blue:  blue, alpha: alpha)
    }
}
