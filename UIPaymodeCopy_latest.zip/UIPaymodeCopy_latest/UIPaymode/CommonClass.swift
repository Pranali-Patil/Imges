//
//  CommonClass.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 16/01/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit
import SWXMLHash
import SCLAlertView
import CryptoSwift


//let CC_MD5_DIGEST_LENGTH = 5

class CommonClass: NSObject {
    

    // get MD5 encrypted string
    func MD5(string: String) -> Data? {
        guard let messageData = string.data(using:String.Encoding.utf8) else { return nil }
        var digestData = Data(count: Int(CC_MD5_DIGEST_LENGTH))
        
        _ = digestData.withUnsafeMutableBytes {digestBytes in
            messageData.withUnsafeBytes {messageBytes in
                CC_MD5(messageBytes, CC_LONG(messageData.count), digestBytes)
                
            }
        }
        
        return digestData
    }
    
    
    // get JSON out of XML string
    func getJSONfromSoapXMLResponse(responseString : String) -> [String:Any]
    {
        // json dict
        var json = [String:Any]()
        
        // parse SOAP xml response
        let xml = SWXMLHash.parse(responseString)
        
        print(xml["ns:masterServiceResponse"]["ns:return"][0].element!.text!)
        
        // take out JSON string out of SOAP xml
        let stringJSON = ((xml["ns:masterServiceResponse"]["ns:return"][0].element!.text!))
        
        print(stringJSON)
        //let dict = convertToDictionary(a)
        
        
        if let data = stringJSON.data(using: String.Encoding.utf8) {
            do {
                json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as!
                    [String:Any]
                print(json)
            } catch {
                print("Something went wrong")
            }
        }
        
        return json
        
    }
    
    func makeCardViewEffect(customView:UIView , shadowColor : UIColor , cornerRadius : CGFloat ,shadowOffsetWidth : CGFloat = 0 , clipBool : Bool = false)
    {
        // card effect
        customView.clipsToBounds = clipBool
        customView.layer.shadowOffset = CGSize(width: shadowOffsetWidth , height: shadowOffsetWidth)
        customView.layer.cornerRadius = cornerRadius;
        customView.layer.shadowRadius = CGFloat(shadowRad);
        customView.layer.shadowOpacity = 0.5;
        customView.layer.shadowColor = UIColor.black.cgColor

    }
    
    // make uibutton rounded
    func makeButtonRounded(button : UIButton ,backgroundColor : UIColor , textColor : UIColor)
    {
        button.titleLabel?.textColor = textColor
        //button.titleLabel?.textColor = UIColor.white
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = backgroundColor
        button.layer.cornerRadius = button.frame.height/2//cornerRadius
    }
    
    //addBottomLine to textfield
    func addBottomLine(textfield:UITextField , borderColor : UIColor)
    {
        let bottomBorder = CALayer()
        bottomBorder.frame = CGRect(x: 0.0 , y: textfield.frame.size.height - 1, width: textfield.frame.size.width, height: 1.0)//CGRect(0.0, textfield.frame.size.height - 1, textfield.frame.size.width, 1.0)
        bottomBorder.backgroundColor = borderColor.cgColor
        textfield.layer.addSublayer(bottomBorder)
    }
    
    // disable uilabel
    func disableUILabelColorWithAnim(label : UILabel ,textField : UITextField, placeHolderString: String)
    {
        //let pstring : NSString = textField.placeholder! as NSString
        //print("pstring \(pstring)")
        let preservedFrame : CGRect = label.frame
        //label.textColor = floatingLabelColor
        let textfieldValue : NSString = textField.text! as NSString
        if textfieldValue.length == 0
        {
            let labelDestFrame : CGRect = textField.frame
            UIView.animate(withDuration: 0.5, delay: 0.01, options:UIViewAnimationOptions.curveEaseOut, animations: {() -> Void in
                
                //label.textColor = floatingLabelColor
                label.frame = labelDestFrame
                
            },
                           completion: {(finished: Bool) -> Void in
                            label.transform = label.transform.scaledBy(x: 1.0, y: 1.0);
                            label.sizeToFit()
                            textField.placeholder = placeHolderString
                            label.frame = preservedFrame
                            label.isHidden = true
            })
        }
        else
        {
            //label.textColor = primaryColor
            
        }
    }
    
    
    //enable label floating
    func highlightUILabelWithAnim(label : UILabel, textField : UITextField, themeUIColor : UIColor )
    {
        
        label.isHidden = false
        let textfieldValue : NSString = textField.text! as NSString
        let labelDestFrame : CGRect = label.frame
        //label.frame = textField.frame
        if textfieldValue.length == 0
        {
            label.frame = textField.frame
            label.transform = label.transform.scaledBy(x: 1.0, y: 1.0);
            label.sizeToFit()
            label.textColor = themeUIColor
            UIView.animate(withDuration: 0.5, delay: 0.01, options:UIViewAnimationOptions.curveEaseOut, animations: {() -> Void in
                label.textColor = themeUIColor
                label.frame = labelDestFrame
                textField.placeholder = ""
                label.transform = label.transform.scaledBy(x: 1.0, y: 1.0);
                label.sizeToFit()
                
            },
                           completion: {(finished: Bool) -> Void in
                            
                            NSLog("Label done Done!")
                            //textField.placeholder = textfieldplaceHolder
                            label.transform = label.transform.scaledBy(x: 1.0, y: 1.0);
                            label.sizeToFit()
            })
        }
        else
        {
            //label.textColor = themeUIColor
        }
    }
    
    //insert 
    func insert(seperator: String, afterEveryXChars: Int, intoString: String) -> String {
        
        let newStr = intoString.replacingOccurrences(of: " ", with: "")
        var output = ""
        newStr.characters.enumerated().forEach { index, c in
            if index % afterEveryXChars == 0 && index > 0 {
                output += seperator
            }
            output.append(c)
        }
        return output
    }

    func getCorrectUrl(urlStrng:String) -> String
    {
        
        //var url = urlStrng.replacingOccurrences(of: "'", with: "%27")
        //print(url)
        //let safeURL = url.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlPathAllowed)
        //print(safeURL)
        var url = CFURLCreateStringByAddingPercentEscapes(
            nil,
            urlStrng as CFString!,
            nil,
            "!*'();:@&=+$,/?%#[]" as CFString!,
            CFStringBuiltInEncodings.UTF8.rawValue
        ) as String

        url =  url.replacingOccurrences(of: "\"", with: "%22")
        url = "%7B" + url + "%7D"
        return url
    }
    
    
    //MARK:mpin pop up code
    var delegate : PMpinProtocol?
    func popppedUPmPINView()
    {
        // Add a text field
        let alert = SCLAlertView(appearance: SCLAlertView.SCLAppearance(showCloseButton : false))
        
        let txt = alert.addTextField("Enter your MPIN")
        alert.addButton("Submit") {
            print("Text value: \(txt.text)")
            
            self.delegate?.onSuccessMpin(successBool: true)
        }
        alert.addButton("Cancel", action: {
            self.delegate?.onSuccessMpin(successBool: false)
        })
        alert.showEdit(dialogueTitle ,
                       subTitle: "Please Enter your MPIN" ,
                       colorStyle : primaryColorHex)
    }
    
    //set delegate
    func setDelegate(pMpinProtocol : PMpinProtocol)
    {
       delegate = pMpinProtocol
    }
    
    //hit mpinService
    func urlHitMPIN(mPinString : String)
    {
        let strURL = ""
    }
    
    
    // tap submit button

    func tapSubmitButton(){
        
    }
    
    
    // alertview with specific time limit
    func alertToast(title : String , message : String , alerBool : Bool = false)
    {
        if(alerBool == false)
        {
            
            SCLAlertView().showTitle(
                title, // Title of view
                subTitle: message, // String of view
                duration: 2.0, // Duration to show before closing automatically, default: 0.0
                completeText: "Done", // Optional button value, default: ""
                style: .success, // Styles - see below.
                colorStyle: primaryColorHex,
                colorTextButton: 0xFFFFFF
            )
        }
        
        else
        {
            
            SCLAlertView().showTitle(
                title, // Title of view
                subTitle: message, // String of view
                style: .success, // Optional button value, default: ""
                closeButtonTitle: "Done", // Styles - see below.
                colorStyle: primaryColorHex,
                colorTextButton: 0xFFFFFF
            )
        }

    }
    
    
    
    
    
    
    
        
    
    


    
    
    
    


    


}

extension String {
    func aesEncrypt(key: String, iv: String) throws -> String{
        let data = self.data(using: String.Encoding.utf8)
        let enc = try AES(key: key, iv: iv, blockMode:.CBC).encrypt(data!.bytes)
        let encData = NSData(bytes: enc, length: Int(enc.count))
        let base64String: String = encData.base64EncodedString(options: NSData.Base64EncodingOptions(rawValue: 0));
        let result = String(base64String)
        return result!
}
    // to delete -
    func clippedMerchantString() -> String
    {
        let fullString : String = self
        let fullNameArr : [String] = fullString.components(separatedBy: "\u{2013}")
        
        // And then to access the individual words:
        let firstPart : String = fullNameArr[0]
        
        return firstPart
    }
    
    
    //base64
    func fromBase64() -> String? {
        guard let data = Data(base64Encoded: self) else {
            return nil
        }
        
        return String(data: data, encoding: .utf8)
    }
    
    func toBase64() -> String {
        return Data(self.utf8).base64EncodedString()
    }
    
    
    
}


extension Sequence where Iterator.Element: Hashable {
    func unique() -> [Iterator.Element] {
        var seen: [Iterator.Element: Bool] = [:]
        return self.filter { seen.updateValue(true, forKey: $0) == nil }
    }
}

// struct for paymode
struct StructPayMode
{
    var singleTxnLimitSetByPrimary : String
    var overallTxnLimitSetByPrimary : String
    var singleTxnLimitSetByUser : String
    var overallTxnLimitSetByUSer : String
    var inStoreTransactionBool : Bool
    var atmWithdrawelBool : Bool
    var internetTxnBool : Bool
    var merchantCategoryBool : Bool
    var countryCategoryBool : Bool
    var hotListCardBool : Bool
    var merchantNonSelectedArray = NSArray()
    var countryNonSelectedArray = NSArray()
}

