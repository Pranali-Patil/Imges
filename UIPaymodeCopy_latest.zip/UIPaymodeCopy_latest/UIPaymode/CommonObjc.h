//
//  NSObject+CommonClass.h
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 20/01/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonObjc : NSObject
    
    +(NSMutableArray *)arrayWithoutnNode:(NSString *)decrypted startTag:(NSString *)startTag subModuleTag:(NSString *)submoduletag requestedTag:(NSString *)requestedTag ;
    
    + (NSString *)stringWithHexFromData:(NSData *)data;



@end
