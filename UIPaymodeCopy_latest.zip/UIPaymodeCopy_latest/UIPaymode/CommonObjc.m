//
//  NSObject+CommonClass.m
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 20/01/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

#import "CommonObjc.h"

@implementation CommonObjc
    
    +(NSMutableArray *)arrayWithoutnNode:(NSString *)decrypted startTag:(NSString *)startTag subModuleTag:(NSString *)submoduletag requestedTag:(NSString *)requestedTag
    {
        
        NSString *starttag=[[NSString alloc]initWithFormat:@"<%@>",startTag];
        NSString *endtag=[[NSString alloc]initWithFormat:@"</%@>",startTag];
        NSString *startsubModuleTag=[[NSString alloc]initWithFormat:@"<%@>",submoduletag];
        NSString *endsubModuleTag=[[NSString alloc]initWithFormat:@"</%@>",submoduletag];
        NSString *startrequestedTag=[[NSString alloc]initWithFormat:@"<%@>",requestedTag];
        NSString *endrequestedTag=[[NSString alloc]initWithFormat:@"</%@>",requestedTag];
        NSMutableArray *colorplus = [[NSMutableArray alloc]init];
        NSRange enddivisionrangeforbilling;
        NSString *result = nil;
        NSRange divRange = [decrypted rangeOfString:starttag options:NSCaseInsensitiveSearch];
        
        NSLog(@"%d" , divRange.location != NSNotFound) ;
        if (divRange.location != NSNotFound)
        {
            NSRange endDivRange;
            //NSLog(@"line3......");
            endDivRange.location = divRange.length + divRange.location;
            endDivRange.length   = [decrypted length] - endDivRange.location;
            endDivRange = [decrypted rangeOfString:endtag options:NSCaseInsensitiveSearch range:endDivRange];
            int i=0;
            if (endDivRange.location != NSNotFound)
            {
                //NSLog(@"line4......");
                divRange.location += divRange.length;
                divRange.length = endDivRange.location - divRange.location;
                
                result = [decrypted substringWithRange:divRange];
                i++;
                
                
            }
            // NSLog(@"line5......::%@",result);
            int j =0;
            NSRange divisionrange = NSMakeRange(0, [result length]);
            while (TRUE)
            {
                //NSLog(@"line6......");
                divisionrange = [result rangeOfString:startsubModuleTag options:NSCaseInsensitiveSearch range:divisionrange];
                if (divisionrange.location == NSNotFound)
                break;
                NSRange enddivisionrange;
                enddivisionrange.location = divisionrange.length + divisionrange.location;
                enddivisionrange.length   = [result length] - enddivisionrange.location;
                enddivisionrange = [result rangeOfString:endsubModuleTag options:NSCaseInsensitiveSearch range:enddivisionrange];
                if (enddivisionrange.location == NSNotFound)
                break;
                divisionrange.location += divisionrange.length;
                divisionrange.length = enddivisionrange.location - divisionrange.location;
                NSString *shippingResult = [result substringWithRange:divisionrange];
                // NSLog(@"shippingResult::%@",shippingResult);
                if(![shippingResult length ]==0)
                {
                    shippingResult = [shippingResult stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    j++;
                    NSRange forbilling= NSMakeRange(0, [shippingResult length]);
                    //while (TRUE)
                    {
                        NSLog(@"result for idrs range>>>>><<<<<<<<<<%@",shippingResult);
                        
                        forbilling = [shippingResult rangeOfString:startrequestedTag options:NSCaseInsensitiveSearch range:forbilling];
                        //NSLog(@"Befor IFbilling");
                        if (forbilling.location != NSNotFound)
                        //break;
                        {
                            // NSLog(@"inside ifforbilling");
                            enddivisionrangeforbilling.location = forbilling.length + forbilling.location;
                            enddivisionrangeforbilling.length   = [shippingResult length] - enddivisionrangeforbilling.location;
                            enddivisionrangeforbilling = [shippingResult rangeOfString:endrequestedTag options:NSCaseInsensitiveSearch range:enddivisionrangeforbilling];
                            if (enddivisionrangeforbilling.location == NSNotFound)
                            break;
                            forbilling.location += forbilling.length;
                            forbilling.length = enddivisionrangeforbilling.location - forbilling.location;
                            NSString *newColorOtions = [shippingResult substringWithRange:forbilling];
                            //NSLog(@"newColorOptions:::%@",newColorOtions);
                            [colorplus addObject:newColorOtions ? newColorOtions:@""];
                            forbilling.location = enddivisionrangeforbilling.location + enddivisionrangeforbilling.length ;
                            forbilling.length = [shippingResult length] - forbilling.location;
                        }else{
                            //NSLog(@"not found");
                            [colorplus addObject:@""];
                        }
                    }
                    //NSLog(@"Outer");
                    divisionrange.location = enddivisionrange.location + enddivisionrange.length ;
                    divisionrange.length = [result length] - divisionrange.location;
                }
            }
            
        }
        return colorplus;
    }
    
    + (NSString *)stringWithHexFromData:(NSData *)data
    {
        NSString *result = [[data description] stringByReplacingOccurrencesOfString:@" " withString:@""];
        result = [result substringWithRange:NSMakeRange(1, [result length] - 2)];
        return result;
    }

@end
