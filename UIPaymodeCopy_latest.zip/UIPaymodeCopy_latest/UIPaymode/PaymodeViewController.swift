////
//  PaymodeViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 27/12/16.
//  Copyright © 2016 WorldlineMacbook2. All rights reserved.
//

//card status
//0   // active
//1   // inactive
//2   // hotlist
//3   // delete
//4   // cancelled

// pay mode response
// {"message":"success","responseCode":0,"responseObject":{"acctLimit":1555000,"singleTxnLimitOfSecondary":110,"intlLimit":0,"referenceNumber":"0c28db064011a895157cc307bfda4a04","overAllLimitOfSecondary":11000,"availableBalance":1555000,"cardDayLimit":1555000,"singleTxnLimitOfPrimary":1555000,"updated":null,"created":1445320226000,"singleTxnLimitSetByPrimary":1555000,"cardCreditLimit":1555000,"overAllLimitOfPrimary":1555000,"cardCashLimit":155500,"overAllLimitSetByPrimary":1000}

//store country codes
var countryCodeArray = NSMutableArray()
var merchantCodeArray = NSMutableArray()


import UIKit
import SCLAlertView

class PaymodeViewController: UIViewController , UITableViewDelegate , UITableViewDataSource , PPaymentCallback {

    @IBOutlet weak var cardView: UIView!
    
    @IBOutlet weak var tableview: UITableView!
    
    @IBOutlet weak var headerView: UIView!
    
    @IBOutlet weak var mainCardView: UIView!
    @IBOutlet weak var contentViewConstantHeight: NSLayoutConstraint!
    
    
    
    
    var transactionEnable : Bool? = true
    var refNo: String?
    var paymodePresenterObj : PaymodPresenter?
    var selectedRow : Int = 0
    
    
    
    
    // country enable bool
    var countryEnable : Bool = true
    var merchantEnable : Bool = true
    
    //paymode struct object
    var sPaymodeStructObject : StructPayMode?
    

    
    
    @IBOutlet weak var submitButtonOutlet: UIButton!
    
    //var viewController : PopUpViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sPaymodeStructObject = StructPayMode(singleTxnLimitSetByPrimary: "1000", overallTxnLimitSetByPrimary: "2000", singleTxnLimitSetByUser: "10", overallTxnLimitSetByUSer: "10", inStoreTransactionBool: true, atmWithdrawelBool: true, internetTxnBool: false, merchantCategoryBool: true, countryCategoryBool: true, hotListCardBool: false, merchantNonSelectedArray:[100,10], countryNonSelectedArray:[100,10])

        //self.readjson()

        headerView.backgroundColor = primaryColor
        // give corner radius of card view
//        cardView.layer.cornerRadius = 5
//        cardView.layer.shadowColor = UIColor.darkGray.cgColor
//        cardView.layer.shadowOpacity = 0.5
//        cardView.layer.shadowRadius = 5
         tableview.layer.cornerRadius = 5
        // give corner radius of table view
        //tableview.layer.shadowColor = UIColor.darkGray.cgColor
        //tableview.layer.shadowOffset = CGSize(width: 0, height: 1)
        //tableview.layer.shadowOpacity = 1
        //tableview.layer.shadowRadius = 5.0
        //tableview.layer.cornerRadius = cornerRadius
        //tableview.layer.masksToBounds = true
        //tableview.clipsToBounds = false
        //tableview.layer.masksToBounds = false
        
        print(countryEnable)
        tableview.layer.borderColor = UIColor.lightGray.cgColor
        tableview.layer.borderWidth = 1.0
        CommonClass().makeCardViewEffect(customView: tableview, shadowColor: shadowColor, cornerRadius: cornerRadius , clipBool : true)
        
        self.paymodePresenterObj = PaymodPresenter(pPaymentCallback:self)
        tableview.tableFooterView = UIView()
        
        CommonClass().makeButtonRounded(button: submitButtonOutlet, backgroundColor: primaryColor, textColor: UIColor.white)
        
        //self.paymodePresenterObj?.hitPaymodeSaveChanges(refNo: "hjb")//self.refNo!)
        CommonClass().makeCardViewEffect(customView: mainCardView, shadowColor: shadowColor, cornerRadius: cornerRadius , clipBool : true)
        

       // addCardButton.layer.cornerRadius = 20
        submitButtonOutlet.alpha = 0.5
        submitButtonOutlet.isUserInteractionEnabled = false
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    //MARK: tableview data source method
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return paymodeCategoryArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : PaymodeTablesiewViewCell = tableView.dequeueReusableCell(withIdentifier: "paymodeCellIdentifier") as! PaymodeTablesiewViewCell
        cell.categoryLabel.text =  paymodeCategoryArray [indexPath.row]
        
        cell.swichButtonOutlet.tag = indexPath.row
        
        cell.swichButtonOutlet.addTarget(self, action: #selector(PaymodeViewController.stateChanged(_:)), for: UIControlEvents.valueChanged)
        cell.countryPoppedUpButton.addTarget(self, action: #selector(countryButtonClicked), for: .touchUpInside)
        cell.customView.isHidden = true
        cell.countryPoppedUpButton.tag = indexPath.row
        cell.hintButton.tag = indexPath.row
        cell.hintButton.addTarget(self,action:#selector(hintButtonClicked(sender:)), for: .touchUpInside)
        
        switch(indexPath.row)
        {
            case 0 : self.dealWithTransactionLimitCell(cell: cell) // transaction
            case 1 : self.enableDisableSwitch(cell: cell, switchBool: (sPaymodeStructObject?.inStoreTransactionBool)!)                          // in store transaction 
            case 2 : self.enableDisableSwitch(cell: cell, switchBool: (sPaymodeStructObject?.atmWithdrawelBool)!)                               // atm withdrawel
            case 3 : self.enableDisableSwitch(cell: cell, switchBool: (sPaymodeStructObject?.internetTxnBool)!)                                 // intrnet transaction bool
            case 4 : self.enableDisableSwitch(cell: cell, switchBool: (sPaymodeStructObject?.merchantCategoryBool)!)                            // merchant select bool
            case 5 : self.enableDisableSwitch(cell: cell, switchBool: (sPaymodeStructObject?.countryCategoryBool)!)                             // country select bool
            case 6 : self.enableDisableSwitch(cell: cell, switchBool: (sPaymodeStructObject?.hotListCardBool)!)                                 //hotlist card bool
            
            
            default : break
        }
        
        // merchant
        if(indexPath.row == 4 && merchantEnable == sPaymodeStructObject?.merchantCategoryBool)
        {
            let selectedArray : NSMutableArray = paymodePresenterObj!.selectedCountryAndMerchants(countryBool: false)
            cell.countryInfoLabel.text =  "non-selected merchants :\n" + selectedArray.componentsJoined(by: " , ")
            cell.countryPoppedUpButton?.setBackgroundImage(UIImage(named: "merchantLogo"), for: UIControlState.normal)
        }
        
        // country
        if(indexPath.row == 5 && countryEnable == sPaymodeStructObject?.countryCategoryBool)
        {
            let selectedArray : NSMutableArray = paymodePresenterObj!.selectedCountryAndMerchants(countryBool: true)
            cell.countryInfoLabel.text =  "selected countries :\n" + selectedArray.componentsJoined(by: " , ")
            cell.countryPoppedUpButton?.setBackgroundImage(UIImage(named: "countryLogo"), for: UIControlState.normal)
        }
        
        if(indexPath.row == (paymodeCategoryArray.count - 1))
        {
            print(tableview.frame.origin.x)
            print(tableview.contentSize.height)
            self.calculateContentHeight()
            cell.contentView.layer.borderColor = primaryColor.cgColor
            cell.contentView.layer.borderWidth = 1.0

        }

        return cell
        
    }
    
    
    //MARK:- tableview delegate
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if((indexPath.row == 0) && (transactionEnable == true))
        {
            return 300 + 44
        }
            
        else if ((indexPath.row == 4) && sPaymodeStructObject?.merchantCategoryBool == true)
        {
            return 94
        }
        
        else if ((indexPath.row == 5) && sPaymodeStructObject?.countryCategoryBool == true)
        {
            return 94

        }
        else
        {
            return 44
        }
    }
    
    //hintButtonClicked
    func hintButtonClicked(sender:UIButton) {
        
//        viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "popUpView") as! PopUpViewController
//        
//        self.addChildViewController(viewController)
//        viewController.view.frame = CGRect(x: 0, y: 0,width: 250, height: (viewController.okButtonOutlet.frame.origin.y+viewController.okButtonOutlet.frame.height));
//        viewController.setDelegate(self)
        let payModeDict : [String : String] = (payModeArray[sender.tag]) as! [String : String]
//        viewController.setViewAttributes(subTitle: payModeDict["header"]!, content: payModeDict["message"]!)
//        viewController.okButtonOutlet.setTitle("OK", for: .normal)
//        
//        viewController.view.center = self.view.center
//        viewController.view.layer.cornerRadius = 10
//        self.view.addSubview(viewController.view)
//        viewController.didMove(toParentViewController: self)
        SCLAlertView().showTitle(
            "Payment Modulator", // Title of view
            subTitle: "\n\(payModeDict["header"]!)\n\n\(payModeDict["message"]!)", // String of view
            duration: 5.0, // Duration to show before closing automatically, default: 0.0
            completeText: "Done", // Optional button value, default: ""
            style: .info, // Styles - see below.
            colorStyle: primaryColorHex,//0xA429FF,
            colorTextButton: 0xFFFFFF
        )

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    // segue delegate
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "showForeignTrans")
        {
            let vc = segue.destination as! ForeignTransactionViewController
            if self.selectedRow == 4        // for merchants
            {
                vc.countryBool = false
            }
            else
            {
                vc.countryBool = true      // for country (geolocations)
            }
        }
    }
    
    
    
    func stateChanged(_ switchState: UISwitch) {
        print(switchState.tag)
        submitButtonOutlet.alpha = 1.0
        submitButtonOutlet.isUserInteractionEnabled = true

        
        switch (switchState.tag)
        {
            case 1 : sPaymodeStructObject?.inStoreTransactionBool = self.chngeSwitchPosition(switchObj: switchState)                          // in store transaction
            case 2 : sPaymodeStructObject?.atmWithdrawelBool = self.chngeSwitchPosition(switchObj: switchState)                            // atm withdrawel
            case 3 : sPaymodeStructObject?.internetTxnBool = self.chngeSwitchPosition(switchObj: switchState)                                                         // intrnet transaction bool
            case 4 : sPaymodeStructObject?.merchantCategoryBool = self.chngeSwitchPosition(switchObj:switchState)                                                        // merchant select bool
            case 5 : sPaymodeStructObject?.countryCategoryBool = self.chngeSwitchPosition(switchObj: switchState)                                                       // country select bool
            case 6 :sPaymodeStructObject?.hotListCardBool = self.chngeSwitchPosition(switchObj: switchState)                                                            //hotlist card bool
                
                
            default : break

        }
        
//        // for // transaction limit
//        if((switchState.tag == 0) &&  switchState.isOn)
//        {
//            transactionEnable = true
//        }
//        
//        else if((switchState.tag == 0))
//        {
//            transactionEnable = false
//        }
//        
//        // for // merchant enable
//        if((switchState.tag == 4) &&  switchState.isOn)
//        {
//            merchantEnable = true
//        }
//            
//        else if((switchState.tag == 4))
//        {
//            merchantEnable = false
//        }
//
//        // for // country enable
//        if((switchState.tag == 5) &&  switchState.isOn)
//        {
//            countryEnable = true
//        }
//            
//        else if((switchState.tag == 5))
//        {
//            countryEnable = false
//        }

        
        
        
        tableview.reloadData()


    }

    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func addCardView(_ myView : UIView)
    {
        myView.layer.shadowColor = UIColor.darkGray.cgColor
        myView.layer.shadowOffset = CGSize(width: 0, height: 1)
        myView.layer.shadowOpacity = 1
        //myView.layer.shadowRadius = 5.0
        myView.layer.cornerRadius = cornerRadius
        myView.clipsToBounds = true
        myView.layer.masksToBounds = true
        myView.layer.borderWidth = 1.0
        myView.layer.borderColor = UIColor.lightGray.cgColor
        self.calculateContentHeight()
    }
    
    // back button clicked
    @IBAction func backButtonClicked(_ sender: Any) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    
    //MARK:-callback delegate
    func onSuccessCallback(message:String)
    {
        
    }
    
    //MARK:- calculate content height
    func calculateContentHeight()
    {
        contentViewConstantHeight.constant = mainCardView.frame.origin.x + mainCardView.frame.size.height + 10 + tableview.frame.origin.x + tableview.contentSize.height + 80
    }
    
    //MARK:- country button ACtn
     func countryButtonClicked(sender: UIButton) {
            selectedRow = sender.tag
            self.performSegue(withIdentifier: "showForeignTrans", sender: self)
    }

    //MARK:- 0:transaction view
    func dealWithTransactionLimitCell(cell : PaymodeTablesiewViewCell)
    {
        cell.customView.isHidden = false
        cell.swichButtonOutlet.isHidden = true
        let viewController:PaymodeTransactionViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "paymodeTransactionDetails") as! PaymodeTransactionViewController
        
        //self.addChildViewController(viewController)
        viewController.view.frame = CGRect(x: 0, y: 0, width: cell.customView.frame.width, height: cell.customView.frame.height);
        //viewController.view.center = cell.customView.center
        //viewController.view.layer.cornerRadius = 10
        viewController.setIntialTransactionValues(sPaymodeObj: sPaymodeStructObject!)
        cell.customView.addSubview(viewController.view)
        self.addCardView(cell.customView)
        
        //cell.countryInfoLabel.isHidden = true
        
        //viewController.didMoveToParentViewController(self)

    }
    
    //MARK:-swich action
    func enableDisableSwitch(cell: PaymodeTablesiewViewCell ,switchBool : Bool)
    {
        cell.swichButtonOutlet.isOn = switchBool
    }
    
    //MARK:-change switch position
    func chngeSwitchPosition(switchObj : UISwitch) -> Bool
    {
        var currentBoolAfterChange : Bool?
        if(switchObj.isOn == true)
        {
            currentBoolAfterChange = false
            switchObj.isOn = false
        }
        else
        {
            currentBoolAfterChange = true
            switchObj.isOn = true
        }
        
        return currentBoolAfterChange!
    }
}
