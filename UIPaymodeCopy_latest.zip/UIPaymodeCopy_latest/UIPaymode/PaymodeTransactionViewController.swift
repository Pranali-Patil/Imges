//
//  PaymodeTransactionViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 28/12/16.
//  Copyright © 2016 WorldlineMacbook2. All rights reserved.
//

import UIKit

class PaymodeTransactionViewController: UIViewController {
    
    @IBOutlet weak var transactionLimitTxtField: UITextField!
    
    @IBOutlet weak var transactionLimitSlider: UISlider!

    @IBOutlet weak var monthlySpentLimitTxtfield: UITextField!
    
    @IBOutlet weak var monthlySpentLimitSlider: UISlider!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        transactionLimitSlider.minimumValue = 0
        monthlySpentLimitSlider.minimumValue = 0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
//    @IBAction func transactionLimitSliderAction(_ sender: UISlider) {
//        let currentValue = Int(sender.value)
//        transactionLimitTxtField.text = "\(currentValue)"
//
//    }
//    
//        @IBAction func monthlyLimitActionSlider(_ sender: UISlider) {
//        let currentValue = Int(sender.value)
//        monthlySpentLimitTxtfield.text = "\(currentValue)"
//    }

    @IBAction func valuChange(_ sender: Any) {
        
        print("1223")
    }
    @IBAction func sliderValueDidChange(_ sender: UISlider) {
        print("1223")

    }
    
    
    
        
    func setIntialTransactionValues(sPaymodeObj : StructPayMode)
    {
        transactionLimitTxtField.text = sPaymodeObj.singleTxnLimitSetByUser
        monthlySpentLimitTxtfield.text = sPaymodeObj.overallTxnLimitSetByUSer
        transactionLimitSlider.maximumValue = Float(sPaymodeObj.singleTxnLimitSetByPrimary)!
        transactionLimitSlider.maximumValue = Float(sPaymodeObj.overallTxnLimitSetByPrimary)!

    }
    
    

}
