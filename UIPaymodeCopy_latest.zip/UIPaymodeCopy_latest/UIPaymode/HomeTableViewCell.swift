//
//  HomeTableViewCell.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 14/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

class HomeTableViewCell: UITableViewCell {
    
    @IBOutlet weak var categoryNameLabel: UILabel!
    
    @IBOutlet weak var categoryIconImgView: UIImageView!
    
    
    @IBOutlet weak var switchOutlet: UISwitch!
    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
