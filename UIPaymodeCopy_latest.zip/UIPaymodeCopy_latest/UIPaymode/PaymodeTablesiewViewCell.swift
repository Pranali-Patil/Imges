//
//  PaymodeCollectionViewCell.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 27/12/16.
//  Copyright © 2016 WorldlineMacbook2. All rights reserved.
//

import UIKit

class PaymodeTablesiewViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var swichButtonOutlet: UISwitch!
    @IBOutlet weak var customView: UIView!
    @IBOutlet weak var hintButton: UIButton!
    @IBOutlet weak var countryInfoLabel: UILabel!
    
    @IBOutlet weak var countryInfoButton: UIButton!
    
    @IBOutlet weak var countryPoppedUpButton: UIButton!
}
