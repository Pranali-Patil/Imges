var hello = function(message) {
  return "Hello " + message;
}

var hola = function(name , ret) {
  return "Hola " + name + " Cómo estás?" + ret;
} 
