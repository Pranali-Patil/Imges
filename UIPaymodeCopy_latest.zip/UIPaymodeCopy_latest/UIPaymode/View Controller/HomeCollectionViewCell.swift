//
//  HomeCollectionViewCell.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 14/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    
    // card view outlets
    @IBOutlet weak var upperCardLineView: UIView!
    
    @IBOutlet weak var lowerCardLineView: UIView!
    @IBOutlet weak var cardTitleView: UILabel!
    
    @IBOutlet weak var cardLogoImageView: UIImageView!
    @IBOutlet weak var ExpDateLabel: UILabel!
    @IBOutlet weak var cardBottomView: UIView!
    @IBOutlet weak var subtitleCardLabel: UILabel!
    
    @IBOutlet weak var cardMainView: UIView!
    
    @IBOutlet weak var cardTypeLabel: UILabel!
    
    
    var sessionID : String?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        upperCardLineView.backgroundColor = secondaryColor
        lowerCardLineView.backgroundColor = secondaryColor
        cardTitleView.textColor = secondaryColor
        ExpDateLabel.textColor = secondaryColor
        subtitleCardLabel.textColor = secondaryColor
        cardBottomView.backgroundColor = primaryColor
        cardTypeLabel.textColor = secondaryColor
        
        
        CommonClass().makeCardViewEffect(customView: cardMainView, shadowColor: shadowColor, cornerRadius: cornerRadius , clipBool : true)
        
    }
    

}
