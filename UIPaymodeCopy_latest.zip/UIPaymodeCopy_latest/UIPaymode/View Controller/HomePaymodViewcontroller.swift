 //
//  HomePaymodViewcontroller.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 13/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit
 import SCLAlertView

class HomePaymodViewcontroller: UIViewController , UICollectionViewDelegate , UICollectionViewDataSource , UIScrollViewDelegate , UITableViewDelegate , UITableViewDataSource , PHomePaymodeCallBack , PMpinProtocol {
    
    @IBOutlet weak var headerView: UIView!      //header view
    
    @IBOutlet weak var homeCollectionView: UICollectionView!    //colllection view outlet
    
    @IBOutlet weak var myPageControl: UIPageControl! // page controller
    
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var scrollContentViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var balanceTxtField: UITextField!
    
    var currentCardIndexInt : Int?
    
    @IBOutlet weak var alertTableView: UITableView!
    
    
    var rowTitle : String?
    
    var switchStatus : Bool = true
    
    var expensBool : Bool?
    
    //presenter object
    var homePresenterObj : HomePaymodePresenter?
    
    // card view outlet
    
    //home model obj array
    var homeModelObjArray = NSMutableArray()
    
    //common class obj
    var commonClassObj = CommonClass()
    
    //referrence number
    var refNumber : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //homeCollectionView.scroll
        self.myTableView.isHidden = true
        self.alertTableView.isHidden = true

        self.myTableView.estimatedRowHeight = 80
        self.myTableView.rowHeight = UITableViewAutomaticDimension
        self.myTableView.tableFooterView = UIView()

        
        
        self.alertTableView.estimatedRowHeight = 80
        self.alertTableView.rowHeight = UITableViewAutomaticDimension
        
        

        // Do any additional setup after loading the view.
        self.setUITheme()
        homePresenterObj = HomePaymodePresenter(pLoginViewCallBack: self)
        homePresenterObj?.getHomeData()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // hide nav bar
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @IBAction func backButtonClicked(_ sender: Any) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- collection view data source
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        myPageControl.numberOfPages = homeModelObjArray.count
        return homeModelObjArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell : HomeCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "homeCollectionCell", for: indexPath) as! HomeCollectionViewCell
        let homeModelObj = homeModelObjArray[indexPath.row] as! HomePaymodeModel
        cell.ExpDateLabel.text = "Expiry Date: " + CommonClass().insert(seperator: "/", afterEveryXChars: 2, intoString: homeModelObj.exipryDate!)//homeModelObj.exipryDate!
        cell.cardTypeLabel.text = homeModelObj.cardType!
        cell.cardTitleView.text = "xxxx   xxxx   xxxx   " + homeModelObj.cardNumber!
        if(homeModelObj.primaryAddOnIndicator == 0)
        {
           cell.subtitleCardLabel.text = "Primary card"
        }
        else
        {
            cell.subtitleCardLabel.text = "Addon card"

        }
        balanceTxtField.text = homeModelObj.balance!
        
        
        return cell
    }
    
    //MARK:- collection view delegate
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        return CGSize(width : self.view.bounds.size.width , height : CGFloat(self.homeCollectionView.bounds.size.height))
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let homeModelObj = homeModelObjArray[indexPath.row] as! HomePaymodeModel
        self.refNumber = homeModelObj.refNo
        self.performSegue(withIdentifier: "showPaymodSegue", sender: self)
    }
    
    
    //MARK:- set UI attributes
    func setUITheme()
    {
        self.headerView.backgroundColor = primaryColor
        self.myPageControl.tintColor = secondaryColor
        self.myPageControl.currentPageIndicatorTintColor = primaryColor
        //CommonClass().makeCardViewEffect(customView: self.myTableView, shadowColor: shadowColor, cornerRadius: cornerRadius , clipBool : true)
        //myTableView.layer.borderColor = secondaryColor.cgColor
        //myTableView.layer.borderWidth = 2
        self.myTableView.layer.cornerRadius = cornerRadius
        let shadowPath = UIBezierPath(roundedRect: myTableView.bounds, cornerRadius: cornerRadius)
        
        myTableView.layer.masksToBounds = false
        myTableView.layer.shadowColor = shadowColor.cgColor
        myTableView.layer.borderColor = UIColor.black.cgColor
        myTableView.layer.shadowOffset = CGSize(width: 3 , height: 3);
        myTableView.layer.shadowOpacity = 4
        myTableView.layer.shadowPath = shadowPath.cgPath
        
        
    }
    
    //MARK:- tableview data source
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(tableView == myTableView)
        {
            //tableViewHeightConstraint.constant = tableView.frame.height//CGFloat(44*(homeCategoryArray.count+1))
            scrollContentViewHeight.constant = 900//tableViewHeightConstraint.constant + 100
            return homeCategoryArray.count

        }
        else
        {
            return homeAlert.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if(tableView == myTableView)

        {
        
        let cell : HomeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "homeCellIdentifier") as! HomeTableViewCell
        if(indexPath.row == 0)
        {
            cell.switchOutlet.isHidden = false
            cell.switchOutlet.isOn = switchStatus
            cell.switchOutlet.addTarget(self, action: #selector(PaymodeViewController.stateChanged(_:)), for: UIControlEvents.valueChanged)
            
        }
        else
        {
            cell.switchOutlet.isHidden = true
            cell.accessoryType = .disclosureIndicator

        }
        
        cell.categoryIconImgView.image = UIImage(named: homeCategoryArray[indexPath.row])
        cell.categoryNameLabel.text = homeCategoryArray[indexPath.row]
        
        return cell
            
        }
        else
        {
            let cell : HomeAlertTableViewCell = tableView.dequeueReusableCell(withIdentifier: "alertdentifier") as! HomeAlertTableViewCell
            
            cell.alertLabel.text = homeAlert[indexPath.row]
            return cell
        }
        
    }
    
    // set header view
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if(tableView == alertTableView)
        {
            let returnedView = UIView(frame: CGRect(x:10, y:0, width:self.alertTableView.frame.size.width, height:30)) //set these values as necessary
            returnedView.backgroundColor = primaryColor
            
            let label = UILabel(frame: CGRect(x:10, y:0, width:returnedView.frame.size.width, height:returnedView.frame.size.height))
            label.text = "Alert"//self.sectionHeaderTitleArray[section]
            label.textColor = UIColor.white
            returnedView.addSubview(label)
            
            return returnedView

        }
        else
        {
            return nil

        }
        
    }
    
    // return heder height
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if(tableView == alertTableView)
        {
            return 30
        }
        else
        {
            return 0
        }
    }

    
    //MARK:-tableview delegate
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
//        if(tableView == myTableView)
//        {
//            return 50
//
//        }
//        
//        else
//        {
//            return nil
//            
//        }
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if(tableView == myTableView)
        {
            if(indexPath.row == 2)          //expense history
            {
                self.rowTitle = homeCategoryArray[indexPath.row]
                self.expensBool = true
                self.performSegue(withIdentifier: "recentTransSegue", sender: self)
            }
            if(indexPath.row == 1)          // recent transaction
            {
                self.rowTitle = homeCategoryArray[indexPath.row]
                self.expensBool = false
                self.performSegue(withIdentifier: "recentTransSegue", sender: self)
            }
            
            if(indexPath.row == 3)          // pie chart
            {
                self.rowTitle = homeCategoryArray[indexPath.row]
                self.performSegue(withIdentifier: "showExpenseGraph", sender: self)
                
                
            }

        }
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        let homeModelObj = homeModelObjArray[0] as! HomePaymodeModel
        
        if (segue.identifier == "recentTransSegue")
        {
            let vc = segue.destination as! RecentViewController
            vc.refNumber = homeModelObj.refNo!
            vc.navString = rowTitle!
            vc.expensBool = self.expensBool
            
        }
        if(segue.identifier == "showPaymodSegue")
        {
            let vc = segue.destination as! PaymodeViewController
            vc.refNo = homeModelObj.refNo!

        }
        
        if(segue.identifier == "showExpenseGraph")
        {
            let vc = segue.destination as! ExpenseGraphViewController
            vc.referrenceNumber = homeModelObj.refNo!

        }
    }

    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        var visibleRect = CGRect()
        
        visibleRect.origin = homeCollectionView.contentOffset
        visibleRect.size = homeCollectionView.bounds.size
        
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        
        let visibleIndexPath: IndexPath = homeCollectionView.indexPathForItem(at: visiblePoint)!
        myPageControl.currentPage = visibleIndexPath.row
        }
    
    //MARK:- protocol delegate
    func onSuccessfulResponse(modelObjArray : NSMutableArray)
    {
        homeModelObjArray = modelObjArray
        self.homeCollectionView.reloadData()
    }
    
    func onSucceefulswitchPosition()
    {
        self.switchStatus = homePresenterObj!.getCurrentCardStatus(index : myPageControl.currentPage)
        self.myTableView.isHidden = false
        self.alertTableView.isHidden = false
        self.myTableView.reloadData()
        tableViewHeightConstraint.constant = self.myTableView.contentSize.height - 60//myTableView.frame.height+60//CGFloat(44*(homeCategoryArray.count+1))
        //self.scrollContentViewHeight.constant =

    }
    
    // switch position changes
    func stateChanged(_ switchState: UISwitch) {
        print(switchState.tag)
        //commonClassObj.setDelegate(pMpinProtocol: self)
        self.homePresenterObj!.popppedUPmPINView()
        
        if switchState.isOn {
            print( "The Switch is On")
        } else {
            print("The Switch is Off")
        }
    }
    
    
    
    
    func onSuccessMpin(successBool : Bool)
    {
        if(successBool == true)
        {
            if(switchStatus == true)
            {
                self.switchStatus = false
            }
            else
            {
                self.switchStatus = true
                
            }

        }
        else
        {
        }
        self.myTableView.reloadData()
    }
    
    // refresh button
    @IBAction func refreshButtonClicked(_ sender: Any) {
        if(refNumber == nil)
        {
            let homeModelObj = homeModelObjArray[0] as! HomePaymodeModel
            self.refNumber = homeModelObj.refNo
        }
        
        homePresenterObj?.hitPieChartUrl(referrenceNo: refNumber!)
        
    }
    
    
    func onSuccessBalanceHit(responseObject : String)
    {
        self.balanceTxtField.text = responseObject
    }
    
    
    
    
    
    //{"message":"success","amount":53.05,"success":true,"channel":{"no_of_txn_per_channel":{"atm":1.0,"international":0.0,"online":0.0,"pos":4.0},"txn_percentage_per_channel":{"atm":9.52,"international":0.0,"online":0.0,"pos":90.48},"amount_percentage_per_channel":{"atm":5.05,"international":0.0,"online":0.0,"pos":48.0}},"mcc":{"myArrayList":[{"map":{"amount":5.05,"total_txn":1,"percentage":"9.52","mcc":"Financial Institutions – Manual Cash Disbursements"}},{"map":{"amount":48.0,"total_txn":4,"percentage":"90.48","mcc":"Lodging – Hotels, Motels, Resorts, Central Reservation Services (not elsewhere classified)"}}]}}
    
    

}
