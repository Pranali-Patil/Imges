//
//  RecentTableViewCell.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 16/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

class RecentTableViewCell: UITableViewCell {
    
    @IBOutlet weak var merchantName: UILabel!
    
    @IBOutlet weak var balance: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var declineStatus: UILabel!
    
    @IBOutlet weak var declineDetails: UILabel!
    
    @IBOutlet weak var recentMainView: UIView!
    
    
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        recentMainView.backgroundColor = primaryColor
        merchantName.textColor = commonTxtColor
        balance.textColor = commonTxtColor
        dateLabel.textColor = commonTxtColor
        declineStatus.textColor = commonTxtColor
        declineDetails.textColor = commonTxtColor
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
