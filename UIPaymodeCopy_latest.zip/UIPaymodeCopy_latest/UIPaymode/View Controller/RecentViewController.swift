//
//  RecentViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 16/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

class RecentViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,PRecentTrans {

    @IBOutlet weak var recentTableView: UITableView!
    
    @IBOutlet weak var NavTitleLabel: UILabel!
    
    var refNumber : String?
    var navString : String?
    var recentTransPresenterObj : RecentViewPresenter?
    var recentTransArray = NSArray()
    var expensBool : Bool? = false
    
    @IBOutlet weak var headerView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.recentTableView.rowHeight = UITableViewAutomaticDimension;
        self.recentTableView.estimatedRowHeight = 210.00
        self.recentTableView.separatorStyle = .none
        self.recentTableView.allowsSelection = false
        recentTransPresenterObj = RecentViewPresenter(pRecentTrans: self)
        self.setUITheme()
        NavTitleLabel.text = navString!
        
        recentTransPresenterObj?.hitRecentTransServer(referrenceNo: self.refNumber! , expensBool: self.expensBool!)
        

        // Do any additional setup after loading the view.
    }
    
    
    
    
    
    
    func setUITheme()
    {
        headerView.backgroundColor = primaryColor
        NavTitleLabel.textColor = commonTxtColor
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //UITableView Delegate
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recentTransArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : RecentTableViewCell = tableView.dequeueReusableCell(withIdentifier: "recentIdentifier")! as! RecentTableViewCell
        
        let recentTransObj = self.recentTransArray[indexPath.row] as! RecentTransList
        CommonClass().makeCardViewEffect(customView: cell.recentMainView, shadowColor: shadowColor, cornerRadius: CGFloat(shadowRad))
        cell.recentMainView.backgroundColor = primaryColor
        cell.merchantName.text = recentTransObj.merchantName//"worldline domestic merchant"
        cell.balance.text = recentTransObj.amount//"22.0"
        cell.dateLabel.text = recentTransObj.txnDateString! + "          " + recentTransObj.tXNTimeString! //"22/02/1090"
        if(expensBool == false)
        {
            cell.declineStatus.text = recentTransObj.txn_message!
            cell.declineStatus.isHidden = false
        }
        else
        {
            cell.declineStatus.text = ""
            cell.declineStatus.isHidden = true
        }
        
        cell.declineDetails.text = ""
        cell.declineDetails.isHidden = true
        //cell.declineDetails.text = "your card is blocked for transaction over internewyour card is blocked for transaction over internew"
        
        return cell
    }
    
    //back button clicked
    @IBAction func backButtonClicked(_ sender: Any) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:-Recent Protocol Delegate
    func onSucceesfullResponse()
    {
        
    }
    func onErrorMessage(errorMsg: String)
    {
        
    }
    
    
    //MARK:View Controler delegate
    func onSuccessfulTransHistory(transArray : NSArray)
    {
        self.recentTransArray = transArray
        self.recentTableView.reloadData()
    }


    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
