//
//  ForeignTransactionViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 01/03/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

let countryKey = "country"
let merchanntKey = "merchants"

class ForeignTransactionViewController: UIViewController , UITableViewDataSource , UITableViewDelegate , UISearchResultsUpdating , UISearchBarDelegate {
    
    var countryArray = NSMutableArray()
    var numberArray = NSMutableArray()
    var selectedArray=NSMutableArray()
    var filteredArray = NSArray()//[String]()
    var shouldShowSearchResults = false
    var countryBool : Bool = true
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var navTitleLabel: UILabel!
    
    @IBOutlet weak var saveButtonOutlet: UIButton!
    
    @IBOutlet weak var tableView: UITableView!
    var searchController: UISearchController!
    
    var countryCount : Int = 0
    
    var selectedRow : Int = 0
    


    override func viewDidLoad() {
        super.viewDidLoad()
        headerView.backgroundColor = primaryColor
        
        
        

        //for adjustable tableview row height
        self.tableView.estimatedRowHeight = 270.0 ;
        self.tableView.rowHeight = UITableViewAutomaticDimension;
        
        var countryArrayMutable = NSArray()
        let defaults = UserDefaults.standard

        if countryBool == true
        {
            navTitleLabel.text = "List of Countries"
            countryArrayMutable = defaults.value(forKey: countryKey) as! NSArray
        }
        else
        {
            navTitleLabel.text = "List of Merchants"
            countryArrayMutable = defaults.value(forKey: merchanntKey) as! NSArray

        }
        
        self.countryArray = NSMutableArray(array: countryArrayMutable)
        
        
        
        self.configureSearchController()
        CommonClass().makeButtonRounded(button: saveButtonOutlet, backgroundColor: primaryColor, textColor: UIColor.white)
        //searchControllersearchController.searchBar.tintColor = primaryColor
        //searchController.searchBar.barTintColor = primaryColor
        //searchController.searchBar.showsCancelButton = true
        

        
    }
    
    // select menu
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Mark:UItableview data source
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if shouldShowSearchResults {
            return filteredArray.count
        }
        else {
            if !shouldShowSearchResults {
                self.countryCount = 0
            }

            return countryArray.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "countryCell") as! CountryTableViewCell
        
        var countryDict : NSDictionary = NSDictionary()//countryArray[indexPath.row] as! NSDictionary
        
        
        
        if shouldShowSearchResults {
            countryDict = filteredArray[indexPath.row] as! NSDictionary
        }
        else {
                countryDict = countryArray[indexPath.row] as! NSDictionary
        }
        
        cell.countryLabel.text = countryDict["name"] as? String

        
        cell.checkBoxButtn.addTarget(self, action:#selector(self.tickClicked(sender:)),for: .touchUpInside)
        
        if(countryDict["code"] as? Int != nil)
        {
            cell.checkBoxButtn.tag = (countryDict["code"] as! Int)

        }
        else
        {
            print((countryDict["name"]))
            cell.checkBoxButtn.tag = Int(countryDict["code"] as! String)!

        }
        
        
        if (countryDict["isSelected"] as? Bool == true) {
        cell.checkBoxButtn.setBackgroundImage(UIImage(named:"checked"), for: UIControlState.normal)
            if !shouldShowSearchResults {
                self.countryCount = countryCount + 1
            }

        }
        else
        {
            cell.checkBoxButtn.setBackgroundImage(UIImage(named:"unchecked"), for: UIControlState.normal)
        }

        
        return cell
    }
    
    func tickClicked(sender: UIButton!)
    {
        let value : Int = sender.tag
        
        var i : Int = 0
        for countryElement in self.countryArray
        {
            let countryMutableElement : NSMutableDictionary = NSMutableDictionary(dictionary: countryElement as! Dictionary)//(countryElement as! NSDictionary).mutableCopy() as! NSMutableDictionary
            let countryCodeInt : Int = Int(countryMutableElement["code"] as! String)!
            if(countryCodeInt == value)
            {
                if(countryMutableElement["isSelected"] as? Bool == true)
                {
                    self.countryCount = self.countryCount - 1
                    countryMutableElement["isSelected"] = false
                }
                else
                {
                    if(countryCount > 3 && countryBool == true)
                    {
                        CommonClass().alertToast(title: "warning", message: "You can not select more than 4 countries", alerBool: true)
                    }
                    else
                    {
                        self.countryCount = self.countryCount + 1
                        countryMutableElement["isSelected"] = true


                    }

                }
                
                
                //make dictionary mutable
                let immutableDict : NSDictionary = NSDictionary(dictionary: countryMutableElement)
                
                self.countryArray[i] = immutableDict

                //self.countryArray.add(immutableDict)
                break
            }
            i = i + 1
        }
        
        
        
        
        let defaults = UserDefaults.standard

        if(countryBool == true)
        {
            defaults.set(countryArray, forKey: countryKey)
        }
        else
        {
            defaults.set(countryArray, forKey: merchanntKey)
        }
        
        
       // if countryArray.contains()
        //{
          //  selectedArray.remove(numberArray.object(at: value))
        //}
        //else
        //{
          //  selectedArray.add(numberArray.object(at: value))
        //}
        
        print("Selecetd Array \(selectedArray)")
        
        if(shouldShowSearchResults == true)
        {
            self.updateSearchResults(for: self.searchController)
        }
        else
        {
            tableView.reloadData()
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func configureSearchController() {
        // Initialize and perform a minimum configuration to the search controller.
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search here..."
        searchController.searchBar.delegate = self
        searchController.searchBar.sizeToFit()
        
        // Place the search bar view to the tableview headerview.
        self.tableView.tableHeaderView = searchController.searchBar
    }
    
    //perform search
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        
        shouldShowSearchResults = true
        //self.tableView.reloadData()
    }
    
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        shouldShowSearchResults = false
        self.tableView.reloadData()
    }
    
    //search bar action
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if !shouldShowSearchResults {
            shouldShowSearchResults = true
            self.tableView.reloadData()
        }
        
        searchController.searchBar.resignFirstResponder()
    }
    
    
    
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        return searchController.searchBar
//    }
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//        return searchController.searchBar.frame.height
//    }
    
    //searchbar update
    func updateSearchResults(for searchController: UISearchController){
       let searchString = searchController.searchBar.text
        
        // Filter the data array and get only those countries that match the search text.
        filteredArray = countryArray.filter({ (country) -> Bool in
            let countryDict : NSDictionary = country as! NSDictionary
            let countryText: NSString = countryDict["name"] as! NSString
            
            return (countryText.range(of: searchString!, options: NSString.CompareOptions.caseInsensitive).location) != NSNotFound
        }) as NSArray
        
        // Reload the tableview.
        self.tableView.reloadData()
    }
    
    
    // back button clicked
    @IBAction func backButtonClicked(_ sender: Any) {
        let _ = self.navigationController?.popViewController(animated: true)
    }

    // save button
    @IBAction func saveButtonClicked(_ sender: Any) {
        self.performSegue(withIdentifier: "backToPaymod", sender: self)
 
    }
    
    //perform segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "backToPaymod"
        {
            let vc = segue.destination as! PaymodeViewController
            if countryBool == true
            {
                countryCodeArray = self.calculateArrayToBePassBack(countryBool: countryBool)
                //vc.countryCodeArray = self.calculateArrayToBePassBack(countryBool: countryBool)

            }
            else
            {
                merchantCodeArray = self.calculateArrayToBePassBack(countryBool: countryBool)
                //vc.merchantCodeArray = self.calculateArrayToBePassBack(countryBool: countryBool)

            }
        }
    }
    
    func calculateArrayToBePassBack(countryBool:Bool) -> NSMutableArray
    {
        let arrayToBeSendBack = NSMutableArray()
        
        for countryElement in countryArray
        {
            let countryElementdict : NSDictionary = countryElement as! NSDictionary
            if(countryElementdict["isSelected"] as? Bool == countryBool)
            {
                
                arrayToBeSendBack.add(countryElementdict["code"]!)
            }
        }
        return arrayToBeSendBack
    }
    
    
    // read json
    func readjson()
    {
        if let filepath = Bundle.main.path(forResource: "Country", ofType: "txt")
        {
            do
            {
                let contents = try String(contentsOfFile: filepath)
                print(contents)
                let con = Array(contents.characters)
                print(con.count)
                print(con[17022])
                print(con[17023])
                print(con[17024])
                self.passJsonTct(jsonText: contents)
                
            }
            catch
            {
                // contents could not be loaded
            }
        }
        else
        {
            // example.txt not found!
        }
    }
    
    func passJsonTct(jsonText : String)
    {
        var dictonary:NSDictionary?
        
        if let data = jsonText.data(using: String.Encoding.utf8) {
            
            do {
                dictonary = try JSONSerialization.jsonObject(with: data, options: [])  as? NSDictionary
                
                
                if let myDictionary = dictonary
                {
                    print(myDictionary.count)
                    
                    print(myDictionary["country"])
                    let defaults = UserDefaults.standard
                    
                    // manipulate merchant array
                    let mutableMerchantArray = NSMutableArray()
                    let merchantMainArray : NSArray = myDictionary[merchanntKey] as! NSArray //defaults.value(forKey: merchanntKey) as! NSArray
                    
                    for merchantDict in merchantMainArray
                    {
                        for (key , value) in (merchantDict as! NSDictionary)
                        {
                            print(merchantDict)
                            let merchantDict : NSMutableDictionary = NSMutableDictionary()
                            merchantDict.setValue(key, forKey: "code")
                            merchantDict.setValue(value, forKey: "name")
                            merchantDict.setValue(true, forKey: "isSelected")
                            mutableMerchantArray.add(merchantDict)
                        }
                    }
                    let merchantArray : NSArray = Array(mutableMerchantArray) as NSArray
                    
                    
                    //country
                    defaults.set(myDictionary[countryKey], forKey:countryKey)
                    //merchants
                    defaults.set(merchantArray ,  forKey: merchanntKey)
                    UserDefaults.standard.synchronize()     // synchronise
                }
            } catch let error as NSError {
                print(error)
            }
        }
    }
    

}
