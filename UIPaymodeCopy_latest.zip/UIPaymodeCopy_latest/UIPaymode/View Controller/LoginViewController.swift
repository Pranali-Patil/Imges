//
//  LoginViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 01/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit
import SCLAlertView
import SwiftLuhn
import CryptoSwift

class LoginViewController: UIViewController , UITextFieldDelegate , PLoginViewCallBack , PpopUpViewDelegeate {
    
    // card outlets
    @IBOutlet weak var cardView: UIView!
    @IBOutlet weak var cardTopLineView: UIView!
    @IBOutlet weak var cardBottomLineView: UIView!
    @IBOutlet weak var cardLogoImageview: UIImageView!
    @IBOutlet weak var cardImageView: UIImageView!
    @IBOutlet weak var bottomCardView: UIView!
    @IBOutlet weak var cardTitleLabel: UILabel!
    @IBOutlet weak var cardSubtitleLabel: UILabel!
    
    // hedader view
    @IBOutlet weak var headerView: UIView!

    
    @IBOutlet weak var masterView: UIView!
    
    @IBOutlet weak var poweredByLabel: UILabel!
    
    
    // username password
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var usernameTextfield: UITextField!
    
    @IBOutlet weak var passwordTextfield: UITextField!
    
    @IBOutlet weak var passwordLabel: UILabel!
    
    @IBOutlet weak var loginButtonOutlet: UIButton!
    
    @IBOutlet weak var forgotPasswordButtnOutlet: UIButton!
    
    @IBOutlet weak var createAccntButtnOutlet: UIButton!
    
    @IBOutlet weak var helpButtonOutlet: UIButton!
    
    var viewController : PopUpViewController!
    
    var commonTextField : UITextField?
    var kbHeight = CGFloat()
    var offsetCheckBOOL :Bool? = false
    var helpPoppedUpflagValue : Bool? = false


    
    
    
    
    // presenter object
    var loginViewPresenterObj : LoginViewPresenter?

    
    
    //@IBOutlet weak var bottomCardView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let key = "4d5390bef3ef1ee3" // length == 32
        let iv = "d4a7e77fd42238cc" // length == 16
        let s = "4391551100004069"
        let enc = try! s.aesEncrypt(key, iv: iv)

        print("enc:\(enc)")

        

//        let input: Array<UInt8> = Array("4391551100004069".utf8)
//
//        let encrypted: Array<UInt8> = try! AES(key: "secret0key000000".utf8, iv:"0123456789012345", blockMode: .CBC, padding: PKCS7()).encrypt(input)
//        
//        print(encrypted.toHexString())
//        
//        
//        print(encrypted.toBase64()!)
//
        
        
        
        //needsLove.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!

            // card typr 
        
        
        
        //print(md5Hex.chara)

        self.setLoginButtonOpacity()
        self.setViewTheme()
        
        loginViewPresenterObj = LoginViewPresenter(loginViewProtocolObj: self)
        
        
        
    }
    
    func setLoginButtonOpacity()
    {
        // disable login button
        loginButtonOutlet.alpha = 0.5
        loginButtonOutlet.isEnabled = false
        
        // set textfield delegates
        // Do any additional setup after loading the view.
        usernameTextfield.delegate = self
        passwordTextfield.delegate = self
        
        passwordLabel.isHidden = true
        usernameLabel.isHidden = true
        
        

    }
    
    // test text field lengths
    // test text field lengths
    func textFieldLenghtVerify(notification:NSNotification)->Bool
    {
        // take out user name string from userName textfield
        let userName:String = usernameTextfield.text!
        
        // take out password string from password textfield
        let pwdValue:String = passwordTextfield.text!
        
        // set minimum username length equal to 5
        if (userName.characters.count >= usernameLength)
        {
            // set minimum password length equal to 8
            if (pwdValue.characters.count >= passwordLength)
            {
                // if both the conditions are true enable login button
                loginButtonOutlet.isEnabled = true
                
                // set login button lpha to 1
                loginButtonOutlet.alpha = 1.0
                
                // return true & end this function here
                return true
            }
                
                // password length is less than desired one then disable login button
            else
            {
                // disable login button
                loginButtonOutlet.isEnabled = false
                loginButtonOutlet.alpha = 0.5
            }
            
        }
            
            // if user name is less than desired one then disable login button
        else
        {
            // disable login button
            loginButtonOutlet.isEnabled = false
            loginButtonOutlet
                .alpha = 0.5
        }
        return false;
        
    }
    
    // set initial theme for view
    func setViewTheme()
    {
        
        // card effect
        CommonClass().makeCardViewEffect(customView: cardView, shadowColor: shadowColor , cornerRadius: cornerRadius, shadowOffsetWidth: 10, clipBool: true)

        // master view 
        CommonClass().makeCardViewEffect(customView: masterView, shadowColor: shadowColor ,  cornerRadius: cornerRadius)
        
        //white effect near card
        CommonClass().makeCardViewEffect(customView: cardTopLineView, shadowColor: UIColor.white,  cornerRadius: 0)
        CommonClass().makeCardViewEffect(customView: cardBottomLineView, shadowColor: UIColor.white,  cornerRadius: 0)
        
        // set card view label colors
        cardTitleLabel.textColor = secondaryColor
        cardSubtitleLabel.textColor = secondaryColor
        poweredByLabel.textColor = secondaryblurColor
        
        usernameLabel.textColor = primaryColor
        passwordLabel.textColor = primaryColor
        
        //set view color
        cardTopLineView.backgroundColor = secondaryColor
        cardBottomLineView.backgroundColor = secondaryColor
        bottomCardView.backgroundColor = primaryColor
        
        // set button rounded
        CommonClass().makeButtonRounded(button: loginButtonOutlet, backgroundColor: primaryColor, textColor: UIColor.white)
        
        
        // Forgot paswrd
        forgotPasswordButtnOutlet.setTitleColor(primaryColor, for: .normal)
        createAccntButtnOutlet.setTitleColor(secondaryblurColor, for: .normal)
        

        //header view
        headerView.backgroundColor = primaryColor
        
        //login button
        CommonClass().addBottomLine(textfield: usernameTextfield , borderColor: primaryColor)
        CommonClass().addBottomLine(textfield: passwordTextfield , borderColor: primaryColor)
        CommonClass().makeButtonRounded(button: loginButtonOutlet, backgroundColor: primaryColor, textColor: UIColor.white)
        
        //customize help button
        //self.helpButtonOutlet.setTitle("Help", for: .normal)
        CommonClass().makeButtonRounded(button: helpButtonOutlet, backgroundColor: UIColor.clear, textColor: textColor)
        helpButtonOutlet.layer.borderColor = textColor.cgColor
        helpButtonOutlet.layer.borderWidth = 2
        //self.helpButtonOutlet.setBackgroundImage(UIImage(named : "helpIcon"), for: .normal)

        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //hide nav bar
        self.navigationController?.navigationBar.isHidden = true
        
        //keyboard pop up notification
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        // local notifications to verify username pwd length
        NotificationCenter.default.addObserver(self, selector:#selector(textFieldLenghtVerify), name: NSNotification.Name(rawValue: "UITextFieldTextDidChangeNotification"), object: self.usernameTextfield)
        NotificationCenter.default.addObserver(self, selector:#selector(textFieldLenghtVerify), name: NSNotification.Name(rawValue: "UITextFieldTextDidChangeNotification"), object: self.passwordTextfield)

    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self)
    }
    
    //MARK:- keyboard logic
    func keyboardWillHide(notification:NSNotification)
    {
        //self.animatedTextField(up: false)
            self.view.frame = CGRect(x:0, y : 0, width:UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
    }

    func keyboardWillShow(notification:NSNotification)
    {
        let userInfo = notification.userInfo
        // var userInfo: [NSObject : AnyObject] = notification.userInfo!
        if userInfo != nil {
            let keyboardSize: CGRect = (userInfo![UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
            
            kbHeight = keyboardSize.size.height;
            
            print(commonTextField!.frame.origin.y+commonTextField!.frame.size.height)
            
            if (commonTextField!.frame.origin.y+commonTextField!.frame.size.height + 84 > kbHeight )
            {
                self.animatedTextField(up: true)
            }
        }
    }
    
    // aniated text field
    func animatedTextField(up:Bool)
    {
        let txtPosition: CGFloat = commonTextField!.frame.origin.y + commonTextField!.frame.size.height
        if txtPosition > (self.view.frame.size.height - kbHeight - 84)
        {
            if !(offsetCheckBOOL!)
            {
                let movement: CGFloat = (up ? -80 : 80)
                self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
                UIView.animate(withDuration: 0.0, animations: {() -> Void in
                    self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
                    self.offsetCheckBOOL! = true
                })
            }
                
            else
            {
                if(!up && offsetCheckBOOL!)
                {
                    self.view.frame = self.view.frame.offsetBy(dx: 0, dy: 80)
                    UIView.animate(withDuration: 0.0, animations: {() -> Void in
                        self.view.frame = self.view.frame.offsetBy(dx: 0, dy: 80)
                    })
                }
            }
        }
        
        if (up == true)
        {
            offsetCheckBOOL = true
        }
            
        else
        {
            offsetCheckBOOL = false
        }
        
    }


    

    
    
    
    //MARK:-textfield Delegate
    func textFieldDidEndEditing(_ textField: UITextField) {
        //self.highlightUILabelWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, themeUIColor:UIColor.black)
        if(textField == usernameTextfield)
        {
            CommonClass().disableUILabelColorWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, placeHolderString: "Username")
        }
        else
        {
            CommonClass().disableUILabelColorWithAnim(label: self.passwordLabel, textField: self.passwordTextfield, placeHolderString: "Password")
        }

    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        commonTextField = textField
        if(textField == usernameTextfield)
        {
            //passwordTextfield.resignFirstResponder()
            CommonClass().highlightUILabelWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, themeUIColor:floatingLabelColor)
        }
        else if(textField == passwordTextfield)
        {
            //usernameTextfield.resignFirstResponder()
            CommonClass().highlightUILabelWithAnim(label: self.passwordLabel, textField: self.passwordTextfield, themeUIColor:floatingLabelColor)
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    //MARK:-Login delegate
    func onSuccessfulResponse(sessionID : String)
    {
        gSessionID = sessionID
        self.setDeviceAttributes()
        self.performSegue(withIdentifier: "doLogin", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "doLogin")
        {
            //let vc = segue.destination as! HomeCollectionViewCell
            
        }
    }
    func onErrorMessage(errorMsg : String)
    {
        self.alertView(stringMessage: errorMsg)
    }
    
    
    
    //put an alertview
    // function which shows alert message
    func alertView(stringMessage : String)
    {
        let appearance = SCLAlertView.SCLAppearance(
            kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
            kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
            kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!,
            showCloseButton: true
        )
        
        let alert = SCLAlertView(appearance: appearance)
        
        alert.showWarning("", subTitle: stringMessage)
    }


    @IBAction func loginButtonClicked(_ sender: Any) {
        // validate username & password length
        let checkLengthBool : Bool = (loginViewPresenterObj?.checkUsernamePwdValidations(userName: usernameTextfield.text!, password: passwordTextfield.text!))!
        
        if(checkLengthBool == true)
        {
            loginViewPresenterObj?.hitLoginserver(username: usernameTextfield.text!, password: passwordTextfield.text!)
        }
            
        else
        {
            self.alertView(stringMessage: "please enter valid user name & password")
        }

    }
    
    @IBAction func helpButtonClicked(_ sender: Any) {
        
        if(helpPoppedUpflagValue == false)
        {
            helpPoppedUpflagValue = true
            
            
            viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "popUpView") as! PopUpViewController
            
            
            
            self.addChildViewController(viewController)
            viewController.setDelegate(self)
            viewController.view.frame = CGRect(x: 0, y: 0,width: 250, height: (viewController.okButtonOutlet.frame.origin.y+viewController.okButtonOutlet.frame.height + 20));
            
            viewController.setViewAttributes(subTitle: "Help", content: "For any assistance/queries, Please contact on the number mentioned below \n\nToll Free:   18002232222 \nLandline:    022-40426008")
            viewController.okButtonOutlet.setTitle("OK", for: .normal)
            
            
            
            
            viewController.view.center = self.view.center
            viewController.view.layer.cornerRadius = 10
            self.view.addSubview(viewController.view)
            viewController.didMove(toParentViewController: self)

        }
        

        
    }
    
    
    //MARK:- pop controller delegate
    func okButtonClicked()
    {
        //let viewController:PopUpViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "popUpView") as! PopUpViewController
        viewController.view.removeFromSuperview()
        helpPoppedUpflagValue = false
        viewController.removeFromParentViewController()
    
    }
    
    
    // set All parameters
    func setDeviceAttributes()
    {
        let deviceID = UIDevice.current.identifierForVendor!.uuidString
        gDeviceID = "\(deviceID)"
        gUsername = usernameTextfield.text!
    }
    
    
    
    
    
    
}


