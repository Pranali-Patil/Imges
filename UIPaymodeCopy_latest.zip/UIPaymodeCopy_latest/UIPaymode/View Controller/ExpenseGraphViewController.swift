//
//  ExpenseGraphViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 19/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//  ""  ''
// {  %7B
// } %&D

import UIKit
import Charts

let constantChannel = "channel"
let constantMCC = "mcc"
let channelDispalyDict : NSDictionary = ["no_of_txn_per_channel" : "Total number of Transactions : " , "txn_percentage_per_channel" : "Total number of transactions in % : " , "amount_percentage_per_channel" : "Total amount transacted in % : "]

let mccDispalyDict : NSDictionary = ["total_txn" : "Total number of Transactions :  " , "percentage" : "Total number of transactions in % :  " , "amount" : "Total amount transacted :  "]


class ExpenseGraphViewController: UIViewController , ChartViewDelegate , UIPickerViewDelegate , UIPickerViewDataSource , PexpenseGraphCallBack {
    
    @IBOutlet weak var pieChartView: PieChartView!
    
    var dictionaryPerChannel = NSDictionary()
    var dictionaryPerCategory = NSDictionary()
    var graphCategoryTypeArray = NSMutableArray()
    
    var expenseDict = NSDictionary()
    
    var displayString : String?
    @IBOutlet weak var headerView: UIView!
    
    @IBOutlet weak var categoryPickerView: UIPickerView!
    
    
    var pickerArray = NSMutableArray() // e.g = category in mcc
    var colorArray : [UIColor] = [UIColor]()
    
    
    var mccDictionaryToShow = NSMutableDictionary()
    
    var expenseGraphPresenterObj : ExpenseGraphPresenter?
    var referrenceNumber : String?
    


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
        //let unitsSold = [20.0, 4.0, 6.0, 3.0, 12.0, 16.0]
        
//        self.expenseGraphData()
        //self.showGraph(typeString: constantChannel)
        //setChart(dataPoints: months, values: unitsSold)
        self.pieChartView.delegate = self
        self.headerView.backgroundColor = primaryColor
        self.categoryPickerView.dataSource = self
        self.categoryPickerView.delegate = self
        self.expenseGraphPresenterObj = ExpenseGraphPresenter(pexpenseGraphCallBack: self)
        expenseGraphPresenterObj?.hitExpenseGraph(refNo: referrenceNumber!)
    }

    func setChart(dataPoints: [String], values: [Double]) {
        
//        var dataEntries: [ChartDataEntry] = []
//        
//        for i in 0..<dataPoints.count {
//            let dataEntry1 = PieChartDataEntry(value: Double(i), label: dataPoints[i], data:  dataPoints[i] as AnyObject)
//            
//            dataEntries.append(dataEntry1)
//        }
        
        var dataEntries: [ChartDataEntry] = []
        
        for i in 0..<dataPoints.count {
            //let dataEntry = ChartDataEntry(x: values[i], y: Double(i) , data:  dataPoints[i] as AnyObject)
            let dataEntry = PieChartDataEntry(value: values[i], label: dataPoints[i].clippedMerchantString() , data : ( dataPoints[i] as AnyObject?))
            
            dataEntries.append(dataEntry)
        }
//        print(dataEntries[0].data!)
//        let pieChartDataSet = PieChartDataSet(values: dataEntries, label: "Units Sold")
//        let pieChartData = PieChartData(dataSet: pieChartDataSet)
//        pieChartView.data = pieChartData
//        
//        var colors: [UIColor] = []

        
        let pieChartDataSet = PieChartDataSet(values: dataEntries, label: displayString!)
        pieChartDataSet.sliceSpace = 0
        //pieChartDataSet.colors = [UIColor.red, UIColor.yellow, UIColor.blue , UIColor.black, UIColor.green, UIColor.brown]
        //let p = PieChartData
        //let pieChartData = PieChartData(xVals: dataPoints, dataSet: pieChartDataSet)

        
        //let piecha
        
        //let pieChartData = PieChartData(dataSets: pieChartDataSet)//PieChartData(xVals: dataPoints, dataSet: pieChartDataSet)
        //pieChartView.data = pieChartData
        var colors: [UIColor] = []

        
        for _ in 0..<dataPoints.count {
            let red = Double(arc4random_uniform(256))
            let green = Double(arc4random_uniform(256))
            let blue = Double(arc4random_uniform(256))
            
            let color = UIColor(red: CGFloat(red/255), green: CGFloat(green/255), blue: CGFloat(blue/255), alpha: 1)
            colors.append(color)
            
        }
        pieChartDataSet.colors = colors
        self.colorArray = colors
        self.pieChartView.data = PieChartData(dataSet: pieChartDataSet)

        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK:chart delegate
func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight)
{
    print(entry.description)
    
    print(entry.data as! String)
    
    //let dataIndex : Int = entry.data as! Int
    
    var msg : String = String()

    if(displayString == constantChannel)
    {
        print(dictionaryPerChannel)
        for (key , value) in dictionaryPerChannel
        {
            if(value is NSDictionary)
            {
                let valueDict : NSDictionary = value as! NSDictionary
                let channelCategory : String = channelDispalyDict[(key)] as! String
                
                msg = "\(msg)\(channelCategory) \(valueDict[entry.data as! String]!) \n"

            }
        }
        
        print(msg)
        CommonClass().alertToast(title: entry.data as! String , message: msg , alerBool: true)

    }
    else if(displayString == constantMCC)
    {
        for (key , value) in mccDictionaryToShow
        {
            if(key as? String == (entry.data as? String))
                {
                    if(value is NSDictionary)
                    {
                        let valueDict : NSDictionary = value as! NSDictionary
                        print(valueDict)
                        
                        
                        
                        for(key , value) in valueDict
                        {
                            if mccDispalyDict[key] != nil
                            {
                                let channelCategory : String = mccDispalyDict[(key)] as! String
                                msg = "\(msg)\(channelCategory) : \(value) \n"

                            }
                        }
                        
                    }
                    
                   break

                }
            
        }
        msg = "\((entry.data as! String)) \n\n" + msg
        
        CommonClass().alertToast(title: "" , message: msg , alerBool: true)



    }

    //let msg : String =
}

    
    func chartValueSelected(chartView: ChartViewBase, entry: ChartDataEntry, dataSetIndex: Int, highlight: Highlight) {
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func expenseGraphData()
    {
//        let expenseDict : NSDictionary = ["message":"success","amount":53.05,"success":true,"channel":["no_of_txn_per_channel":["atm":1.0,"international":0.0,"online":0.0,"pos":4.0],"txn_percentage_per_channel":["atm":9.52,"international":0.0,"online":0.0,"pos":90.48],"amount_percentage_per_channel":["atm":5.05,"international":0.0,"online":0.0,"pos":48.0]],"mcc":["myArrayList":[["map":["amount":5.05,"total_txn":1,"percentage":"9.52","mcc":"Financial Institutions – Manual Cash Disbursements"]],["map":["amount":48.0,"total_txn":4,"percentage":"90.48","mcc":"Lodging – Hotels, Motels, Resorts, Central Reservation Services (not elsewhere classified)"]]]]]
        if(expenseDict["message"] as? String == "success")
        {
//            if(expenseDict[constantChannel] is NSDictionary)
//            {
            
                for (key,value) in expenseDict
                {
                    self.graphCategoryTypeArray.add(key)
                    
                    if(key as? String == constantChannel)
                    {
                        self.dictionaryPerChannel = value as! NSDictionary
                        self.pickerArray.add(key)
                    }
                    if(key as? String == constantMCC)
                    {
                        self.dictionaryPerCategory = value as! NSDictionary
                        self.pickerArray.add(key)

                    }
                }
            self.categoryPickerView.reloadAllComponents()
            }
        //}

    }
    
    func showGraph(typeString : String)
    {
        var category = [String]()
        var channel = [Double]()
        if(typeString == constantChannel)
        {
            self.displayString = constantChannel
            print(self.dictionaryPerChannel)
            if(dictionaryPerChannel["txn_percentage_per_channel"] is NSDictionary)
            {
                let dictValue : NSDictionary = dictionaryPerChannel["txn_percentage_per_channel"]  as! NSDictionary
                let mutDictValue : NSMutableDictionary = NSMutableDictionary(dictionary: dictValue)
                
                for (key , value) in mutDictValue
                {
                    if(value as? Double == 0)
                    {
                        mutDictValue.removeObject(forKey: key)
                    }
                }
                
                category  = mutDictValue.allKeys as! [String]
                channel  = mutDictValue.allValues as! [Double]
                
                print(category)

            }
            
        }
        else if(typeString == constantMCC)
        {
            
            self.displayString = constantMCC

            if(dictionaryPerCategory["myArrayList"] is NSArray)
            {
                let myListArray : NSArray = dictionaryPerCategory["myArrayList"] as! NSArray
                
                for mccElement in myListArray
                {
                    if(mccElement is NSDictionary)
                    {
                        let merchantDict : NSDictionary = mccElement as! NSDictionary
                        
                        if(merchantDict["map"] is NSDictionary)
                        {
                            let mapDict = merchantDict["map"] as! NSDictionary
                            print(merchantDict["map"]!)
                            let nameString : String = mapDict["mcc"] as! String
                            print(nameString)
                            category.append(nameString)
                            //= mutDictValue.allKeys as! [String]
                            let percentDouble : String = mapDict["percentage"] as! String

                            channel.append(Double(percentDouble)!)//append(Double(mapDict["percentage"])) // = mutDictValue.allValues as! [Double]
                            mccDictionaryToShow[nameString] = mapDict

                        }
                    }
                }
            }
        }

        
        setChart(dataPoints: category, values: channel)

    }
    
    //MARK: Picker view delegate
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.pickerArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.pickerArray[row] as? String
    }
    
    //MARK:picker view delegate
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        self.showGraph(typeString: pickerArray[row] as! String)
        
    }
    
    
    // navigationbar
    @IBAction func backButtonClicked(_ sender: Any) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    
    //MARK:-Expense Delegate
    func expenseCallBackSuccess(expensseDict : NSDictionary)
    {
        self.expenseDict = expensseDict
        self.expenseGraphData()

    }
    func expenseNoDataFound()
    {
        
    }
    func onFailure(stringMsg:String)
    {
        
    }

    
    
    
    

}


