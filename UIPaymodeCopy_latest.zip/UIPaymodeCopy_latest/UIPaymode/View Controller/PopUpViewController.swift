//
//  PopUpViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 13/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol PpopUpViewDelegeate
{
    func okButtonClicked()
}


class PopUpViewController: UIViewController   {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var subtitleLabel: UILabel!
    
    
    @IBOutlet weak var contentTextView: UITextView!
    @IBOutlet weak var okButtonOutlet: UIButton!
    
    
    
    @IBOutlet weak var okButton: UIButton!
    var delegate1 : PpopUpViewDelegeate?


    override func viewDidLoad() {
        super.viewDidLoad()
        self.okButtonOutlet.backgroundColor = primaryColor
        CommonClass().makeCardViewEffect(customView: self.view, shadowColor: shadowColor, cornerRadius: CGFloat(shadowRad))
        CommonClass().makeButtonRounded(button: okButtonOutlet, backgroundColor: primaryColor, textColor: textColor)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func okButtonClicked(_ sender: Any) {
        delegate1?.okButtonClicked()

    }
    
    func setDelegate(_ delegate:PpopUpViewDelegeate)
    {
        self.delegate1 = delegate
    }
    
    
    func setViewAttributes(title:String = "Payment Modulator", subTitle : String , content : String)
    {
        
        //let attributedString = NSMutableAttributedString(string: "Want to learn iOS? You should visit the best source of free iOS tutorials!")
        //attributedString.addAttribute(NSLinkAttributeName, value: "https://www.hackingwithswift.com", range: NSRange(location: 19, length: 55))

        self.titleLabel.text = title
        //self.contentTextView.attributedText = attributedString
        self.subtitleLabel.text = subTitle
        
        
        let attributedString = NSMutableAttributedString(string: "For any assistance/queries, Please contact on the number mentioned below \n\nToll Free:   ")
        let phoneUrl = NSURL(string: "tel:+18002232222")! // "telprompt://+33687654321" also works
        let attributes = [NSLinkAttributeName: phoneUrl]
        let attributedStringNumber1 = NSAttributedString(string: "18002232222", attributes: attributes)
        attributedString.append(attributedStringNumber1)
        
        attributedString.append(NSAttributedString(string: "\nLandline :   "))
        
        let phoneUrl2 = NSURL(string: "tel:02240426008")!
        let attributes2 = [NSLinkAttributeName: phoneUrl2]
        let attributedStringNumber2 = NSAttributedString(string: "022-40426008", attributes: attributes2)
        attributedString.append(attributedStringNumber2)

        
        
        self.contentTextView.attributedText = attributedString
        self.contentTextView.isUserInteractionEnabled = true // default: true
        self.contentTextView.isEditable = false // default: true
        self.contentTextView.isSelectable = true // default: true
        
        
        // set text view height
        let fixedWidth = contentTextView.frame.size.width
        contentTextView.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
        let newSize = contentTextView.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
        var newFrame = contentTextView.frame
        newFrame.size = CGSize(width: max(newSize.width, fixedWidth), height: newSize.height)
        contentTextView.frame = newFrame;

        
    }
    
    
    
    
    


    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
