//
//  CommunicationManager.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 12/01/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//


import UIKit
import Alamofire
import SWXMLHash
import SVProgressHUD

class CommunicationManager: NSObject {
    
    class func sendGetURL(stringURL : String , onSuccess:@escaping (_ response: DefaultDataResponse?) -> Void, onFailure:@escaping (_ errorString: NSError?) -> Void )
    {
        SVProgressHUD.show()
        
        print(stringURL)
        Alamofire.request(stringURL).response(completionHandler: { response in
            SVProgressHUD.dismiss()
            
            //print(response.response.)
            if(response.error == nil)
            {
                onSuccess(response)
            }
            
            else
            {
                print(response.error?.localizedDescription)
                onFailure(response.error as NSError?)
            }
            
    })
        
        
        
    }
    
    

    
    
    
    
}
