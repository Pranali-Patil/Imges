
//  RegistrationVC.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 21/12/16.
//  Copyright (c) 2016 WorldlineMacbook2. All rights reserved.
//

import UIKit
import SwiftLuhn

class RegistrationVC: UIViewController , UITextFieldDelegate , PRegistrationCallBack {
    
    @IBOutlet weak var cardView: UIView!
    
    @IBOutlet weak var cardNumberTextfield: UITextField!
    
    @IBOutlet weak var cardHolderNameTxtfield: UITextField!
    
    @IBOutlet weak var expDateTxtfield: UITextField!

    @IBOutlet weak var cvvTxtField: UITextField!
    
    @IBOutlet weak var addCardButton: UIButton!
    
    
    
    @IBOutlet weak var cardNoLabel: UILabel!
    
    @IBOutlet weak var cardNumberMainViewLabel: UILabel!
    
    @IBOutlet weak var headerView: UIView!
    
    @IBOutlet weak var headerLabel: UILabel!
    
    @IBOutlet weak var cardTopLineView: UIView!
    
    
    @IBOutlet weak var cardBottomLineView: UIView!
    
    @IBOutlet weak var cardBottomView: UIView!
    
    @IBOutlet weak var protectUrCardLabel: UILabel!
    
    var registrationPresenterObj : RegistrationPresenter?
    
    
    


    @IBOutlet weak var bankSchemeLogo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.cardNumberTextfield.delegate = self
        //self.cardNoLabel.isHidden = true
        
        CommonClass().makeCardViewEffect(customView: cardView, shadowColor: shadowColor ,  cornerRadius: cornerRadius, shadowOffsetWidth: 10, clipBool: true)
        
        CommonClass().makeButtonRounded(button: addCardButton, backgroundColor: primaryColor, textColor: UIColor.white)
        
        cardNumberMainViewLabel.isHidden = true
        //CommonClass().addBottomLine(textfield: cardNumberTextfield, borderColor: UIColor.darkGray)
        self.registrationPresenterObj = RegistrationPresenter(pRegistrationCallBack: self)
        self.setUITheme()
        
        
// give corner radius of card view
//        cardView.layer.cornerRadius = 5
//        cardView.layer.shadowColor = UIColor.darkGray.cgColor
//        cardView.layer.shadowOpacity = 0.5
//        cardView.layer.shadowRadius = 5
//        
//        addCardButton.layer.cornerRadius = 20
//        
//        
//        self.addCardTxtFieldSymbol()
//        
//        cardNumberTextfield.delegate = self
//        
//        
//        //sssssssssssssss
//        self.checkCardDetails()
//        
//        // hide
//        cardHolderNameTxtfield.isHidden = true
//        expDateTxtfield.isHidden = true
//        cvvTxtField.isHidden = true
//        
//        //labels on card
//        nameLabel.isHidden = true
//        expDateLabel.isHidden = true
        
        
        
    }
    
    func setUITheme()
    {
        headerView.backgroundColor = primaryColor
        cardTopLineView.backgroundColor = secondaryColor
        cardBottomLineView.backgroundColor = secondaryColor
        cardBottomView.backgroundColor = primaryColor
        cardNumberMainViewLabel.textColor = secondaryColor
        protectUrCardLabel.textColor = secondaryColor
        CommonClass().makeButtonRounded(button: addCardButton, backgroundColor: secondaryColor, textColor: UIColor.white)
        cardNumberMainViewLabel.textColor = secondaryColor
        CommonClass().addBottomLine(textfield: cardNumberTextfield, borderColor: secondaryColor)
        
        
    }
    

    
    func checkCardDetails()
    {
        let isValid = "5346800017559969".isValidCardNumber()
        print(isValid)
        
        let cardType = SwiftLuhn.CardType(string: "5346800017559969")
        
        if(cardType != nil)
        {
            print(cardType!)
        }
        
        else
        {
            print("card is inavalid")
        }
        
        //.cardType(of: "378282246310005")
//        do {
//            
//            let cardType = try SwiftLuhn.CardType(string: "378282246310005")//.cardType(of: "378282246310005")
//            print(cardType)
//        }
//        catch {
//            // card is invalid
//            print("card is not valid")
//        }

    }
    
        func addCardTxtFieldSymbol()
    {
        // add card number textfield symbol
        self.addCardSymbolToTheLeft(self.cardNumberTextfield, imageName: "card_icon")
        
        // add card holder name textfield symbol
        self.addCardSymbolToTheLeft(self.cardHolderNameTxtfield, imageName: "cardHolder_icon")
        
        // add card number textfield symbol
        self.addCardSymbolToTheLeft(self.expDateTxtfield, imageName: "calender_icon")
        
        // add card number textfield symbol
        self.addCardSymbolToTheLeft(self.cvvTxtField, imageName: "lock_icon")
        

    }
    
    func addCardSymbolToTheLeft(_ textField : UITextField , imageName : String)
    {
        textField.leftViewMode = UITextFieldViewMode.always
        let imageView = UIImageView(frame: CGRect(x: 0 , y: 0, width: 20, height: 20))
        let image = UIImage(named: imageName)
        imageView.image = image
        textField.leftView = imageView

    }
    
    //MARK:- textfield delegate
    
    
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        //self.appendSpaces(originalString: textField.text! + string)
        print((textField.text!))
        
        if(textField.text?.characters.count == 2 && range.length == 0)
        {
            self.registrationPresenterObj?.getCardSchemeImage(cardLogoImgView: self.bankSchemeLogo, cardNumberString: textField.text!)
        }
        if(textField.text?.characters.count == 1 && range.length == 1)
        {
            self.bankSchemeLogo.image = nil
        }
        
        

        //print(textField.text)
        if ((textField.text?.characters.count)! > 19 && range.length == 0)
        {
            
            return false
        }
        
        else
        {
            if(range.length == 0 && (((textField.text?.characters.count)!%5) == 0))
            {
                textField.text =  textField.text! + " "
                //self.writeNumberInCardLabel(cardString: textField.text! + string )
                
            }
            
            if(range.length == 0)
            {
                //self.writeNumberInCardLabel(cardString: textField.text! + string)
                //print(self.insert(seperator: " ", afterEveryXChars: 4, intoString: textField.text! + string))
                cardNoLabel.text = CommonClass().insert(seperator: " ", afterEveryXChars: 4, intoString: textField.text! + string)
                
                
                


            }
            
            else
            {
                let endIndex = textField.text!.index(textField.text!.endIndex, offsetBy: -1)
                let truncated = textField.text!.substring(to: endIndex)
                //self.writeNumberInCardLabel(cardString: truncated)
                //print(.insert(seperator: " ", afterEveryXChars: 4, intoString: truncated))
                cardNoLabel.text = CommonClass().insert(seperator: " ", afterEveryXChars: 4, intoString: truncated)
                

            }
            
        }
        
        return true
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        //self.highlightUILabelWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, themeUIColor:UIColor.black)
        if(textField == cardNumberTextfield)
        {
            CommonClass().disableUILabelColorWithAnim(label: self.cardNumberMainViewLabel, textField: self.cardNumberTextfield, placeHolderString: "Card Number")
        }
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if(textField == cardNumberTextfield)
        {
            //passwordTextfield.resignFirstResponder()
            CommonClass().highlightUILabelWithAnim(label: self.cardNumberMainViewLabel, textField: self.cardNumberTextfield, themeUIColor: secondaryColor)
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    
    func writeNumberInCardLabel(cardString : String)
    {
        let trimmedCardStringArray = cardString.components(separatedBy: " ")
        
        print(trimmedCardStringArray)
        
        
        print(cardString)
        
        let localSwitchNumber : Int = (cardString.characters.count - 1)/5
//        if((cardNumberTextfield.text?.characters.count)! >= 1)
//        {

        
        //}
    }
    
    func addXXXtoCardLabel(cardLabel:UILabel , cardNumberString : String)
    {
        print(cardNumberString)
//        if(cardNumberString.characters.count >= 1)
//        {
            cardLabel.text = cardNumberString
            
            if( cardLabel.text!.characters.count != 4)
            {
                for i in (cardLabel.text!.characters.count) ... 3
                {
                    print(i)
                    cardLabel.text = cardLabel.text! + "X"
                }
            }
            
            
            
        
        //}
    }
    

    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func appendSpaces(originalString : String) -> String
    {
        let newString : String = ""
        
        let characters = Array(originalString.characters)

        //let characters = Array(newString.characters)
        print(characters)
        
        return newString
    }
    
    
    // resign txt fields functions
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)    {
        let touch: UITouch = event!.allTouches!.first!
        
        if self.cardNumberTextfield.isFirstResponder && touch.view != self.cardNumberTextfield {
            self.cardNumberTextfield.resignFirstResponder()
        }
        
        
        super.touchesBegan(touches, with: event)
        
    }
    
    //back button action
    @IBAction func backButtonClicked(_ sender: Any) {
        let _ = navigationController?.popViewController(animated: true)
        
    }
    
    //add Card button Action
    @IBAction func addCardButtonClicked(_ sender: Any) {
        
        self.registrationPresenterObj?.hitAddCardURL(cardNumber: cardNumberTextfield.text!)
    }
    
    //registration callback 
    func onSuccessfulRegistration(message : String)
    {
        CommonClass().alertToast(title: message, message: "")
        self.performSegue(withIdentifier: "registrationOTPSegue", sender: self)
    }
    
    
    
    //MARK:-
    
    


}

