//
//  OTPRequestViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 28/12/16.
//  Copyright © 2016 WorldlineMacbook2. All rights reserved.
//

import UIKit

class OTPRequestViewController: UIViewController , UITextFieldDelegate , POTPRequesCallback {
    
    
    @IBOutlet weak var OTPRequestButtonOutlet: UIButton!
    
    @IBOutlet weak var mainCardView: UIView!
    
    @IBOutlet weak var navTitleLabel: UILabel!
    
    @IBOutlet weak var headerView: UIView!
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var usernameTextfield: UITextField!
    
    var otpRequestPresenterObj : OTPRequestPresenter?
    var reffrenceNoString : String?

    

    override func viewDidLoad() {
        super.viewDidLoad()

        
        OTPRequestButtonOutlet.layer.cornerRadius = 20
        usernameTextfield.delegate = self
        usernameLabel.isHidden = true
        self.setUITheme()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
    func setUITheme()
    {
        CommonClass().makeCardViewEffect(customView: self.mainCardView, shadowColor: shadowColor, cornerRadius: cornerRadius)
        CommonClass().makeButtonRounded(button: OTPRequestButtonOutlet, backgroundColor: primaryColor, textColor: UIColor.white)
        headerView.backgroundColor = primaryColor
        usernameLabel.textColor = primaryColor
        CommonClass().addBottomLine(textfield: usernameTextfield, borderColor: primaryColor)
        
    }
    
    
    @IBAction func backButtonClicked(_ sender: Any) {
        let _ = navigationController?.popViewController(animated: true)
    }
    
    
    //MARK:-textfield Delegate
    func textFieldDidEndEditing(_ textField: UITextField) {
        //self.highlightUILabelWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, themeUIColor:UIColor.black)
        if(textField == usernameTextfield)
        {
            CommonClass().disableUILabelColorWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, placeHolderString: "Username")
        }
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if(textField == usernameTextfield)
        {
            //passwordTextfield.resignFirstResponder()
            CommonClass().highlightUILabelWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, themeUIColor:floatingLabelColor)
        }
        
        return true
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }


    // resign txt fields functions
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)    {
        let touch: UITouch = event!.allTouches!.first!
        
        if self.usernameTextfield.isFirstResponder && touch.view != self.usernameTextfield {
            self.usernameTextfield.resignFirstResponder()
        }
        
        
        super.touchesBegan(touches, with: event)
        
    }
    
    @IBAction func verifyButtonClicked(_ sender: Any) {
        //self.otpRequestPresenterObj = OTPPresenter(pOTPRequesCallback: self)
        //otpRequestPresenterObj?.reqForAnOTP(userNameString: OTPtxtfield.text!)
    }

    @IBAction func otpRequestButtonClicked(_ sender: Any) {
        usernameTextfield.resignFirstResponder()
        self.otpRequestPresenterObj = OTPRequestPresenter(pOTPRequesCallback: self)
        self.otpRequestPresenterObj?.reqForAnOTP(userNameString: usernameTextfield.text!)
    }
    
    //prepare for segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "showResetPwd")
        {
            let vc : ResetPwdViewController = segue.destination as! ResetPwdViewController
            vc.usernameString = usernameTextfield.text
            vc.referrenceNumber = self.reffrenceNoString!
            vc.forgotPwdBool = true
        
        }
    }


    //MARK:presenter delegate
    func onSuccessfulResponse(refNo:String)
    {
        self.reffrenceNoString = refNo
        self.performSegue(withIdentifier: "showResetPwd", sender: self)
        
    }


}
