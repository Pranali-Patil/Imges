//
//  LoginModel.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 23/01/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

class LoginModel: NSObject {
    
    var successCode : Bool?
    var succeessMsg : String?
    var session_id : String?
    var responseCode : Int?
    init(loginDict : [String:Any])
    {
        print(loginDict)
        if(loginDict["success"] is Bool)
        {
            successCode = loginDict["success"] as? Bool
        }
        
        if(loginDict["message"] is String)
        {
            succeessMsg = loginDict["message"] as? String
        }
        
        if(loginDict["session_id"] is Int)
        {
            let intSession = loginDict["session_id"] as! Int
            self.session_id = String(intSession)//String(describing: loginDict["session_id"])
        }
        
        if(loginDict["responseCode"] is Int)
        {
            let intResponseCode = loginDict["responseCode"] as! Int
            self.responseCode = (intResponseCode)//String(describing: loginDict["session_id"])
        }


        
    }

}
