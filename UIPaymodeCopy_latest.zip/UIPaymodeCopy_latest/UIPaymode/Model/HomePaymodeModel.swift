//
//  HomePaymodeModel.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 14/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

class HomePaymodeModel: NSObject {
    
    var balance : String?
    var cardStatus : String?
    var cardType : String?
    var exipryDate : String?
    var cardRegistered : String?
    var cardScheme : String?
    var bankCode : String?
    var cardNumber : String?
    var primaryAddOnIndicator : Int?
    var refNo : String?
    
    
    init(dict : [String:Any])
    {
        print(dict)
        if(dict["balance"] is String)
        {
            self.balance = dict["balance"] as? String
        }
        
        if(dict["cardStatus"] is Int)
        {
            let intCardStatus = dict["cardStatus"] as! Int
            self.cardStatus = String(intCardStatus)
        }
        
        
        if(dict["cardType"] is String)
        {
            self.cardType = dict["cardType"] as? String
        }
        
        if(dict["exipryDate"] is Int)
        {
            let intExipryDate = dict["exipryDate"] as! Int
            self.exipryDate = String(intExipryDate)
        }
        
        if(dict["cardRegistered"] is String)
        {
            self.cardRegistered = dict["cardRegistered"] as? String
        }

        if(dict["cardScheme"] is String)
        {
            self.cardScheme = dict["cardScheme"] as? String
        }
        
        if(dict["bankCode"] is Int)
        {
            let intBankCode = dict["bankCode"] as! Int
            self.bankCode = String(intBankCode)
        }
        
        if(dict["cardNumber"] is String)
        {
            //let intCardNumber = dict["cardNumber"] as! Int
            self.cardNumber = dict["cardNumber"] as? String
        }
        
        if(dict["primaryAddOnIndicator"] is Int)
        {
            self.primaryAddOnIndicator = dict["primaryAddOnIndicator"] as? Int
        }
        if(dict["referenceNumber"] is String)
        {
            self.refNo = dict["referenceNumber"] as! String? //String(intCardStatus)
        }
    }
}


class HomeCardPoseDetailsModel
{
    var acqc : String?
    var acqcSetByPrimary : String?
    var active : String?
    var activeSetByPrimary : String?
    var atm : String?
    var atmSetByPrimary : String?
    var cardDetail : NSDictionary?
    var international : String?
    var internationalSetByPrimary : String?
    var online : String?
    var onlineSetByPrimary : String?
    var pos : String?
    var posSetByPrimary : String?
    var referenceNumber : String?

    init(dict : [String:Any])
    {
        print(dict)
        if(dict["acqc"] is String)
        {
            self.acqc = dict["acqc"] as! String?
        }
        if(dict["acqcSetByPrimary"] is String)
        {
            self.acqcSetByPrimary = dict["acqcSetByPrimary"] as! String?
        }
        if(dict["active"] is String)
        {
            self.active = dict["active"] as! String?
        }
        if(dict["activeSetByPrimary"] is String)
        {
            self.activeSetByPrimary = dict["activeSetByPrimary"] as! String?
        }
        if(dict["atm"] is String)
        {
            self.atm = dict["atm"] as! String?
        }
        if(dict["atmSetByPrimary"] is String)
        {
            self.atmSetByPrimary = dict["atmSetByPrimary"] as! String?
        }
        if(dict["cardDetail"] is NSDictionary)
        {
            self.cardDetail = dict["cardDetail"] as! NSDictionary?
        }
        if(dict["international"] is String)
        {
            self.international = dict["international"] as! String?
        }
        if(dict["internationalSetByPrimary"] is String)
        {
            self.internationalSetByPrimary = dict["internationalSetByPrimary"] as! String?
        }
        if(dict["online"] is String)
        {
            self.online = dict["online"] as! String?
        }
        if(dict["onlineSetByPrimary"] is String)
        {
            self.onlineSetByPrimary = dict["onlineSetByPrimary"] as! String?
        }
        if(dict["pos"] is String)
        {
            self.pos = dict["pos"] as! String?
        }
        if(dict["posSetByPrimary"] is String)
        {
            self.posSetByPrimary = dict["posSetByPrimary"] as! String?
        }
        if(dict["referenceNumber"] is String)
        {
            self.referenceNumber = dict["referenceNumber"] as! String?
        }
        
    }
}


// card account holder details

class HomeCardAccountHolderDetails
{
    var acctLimit : Int?
    var appName : String?
    var authCode : Int?
    var bankCode : Int?
    var cardCashLimit : Int?// total transaction limit
    var cardCreditLimit : Int?//total credit limit
    var cardHolderName : String?
    var cardNumber : String?
    var cardRegistered : String?
    var cardScheme : String?
    var cardStatus : Bool?
    var cardType : String?
    var created : Int?
    var dayLimit : Int?
    var emailId : String?
    var exipryDate : Int?
    var groupReference : Int?
    var intlCardLimit : Int?
    var intlMobileNumber : Int?
    var mobileNumber : Int?
    var mxpAccountNumber : Int?
    var oldCardNumber : Int?
    var overAllLimit : Int? //month limit
    var primaryAddOnIndicator : Int?
    var productName : String?
    var referenceNumber : String?
    var responseCode : Int?
    var updated : Int?
    var virtualCardNumber : String?
 
    init(dict : [String:Any])
    {
        if(dict["acctLimit"] is Int)
        {
            self.acctLimit = dict["acctLimit"] as? Int
        }
        
        if(dict["appName"] is String)
        {
            self.appName = dict["appName"] as? String
        }
        
        
        if(dict["authCode"] is Int)
        {
            self.authCode = dict["authCode"] as? Int
        }
        
        if(dict["bankCode"] is Int)
        {
            self.bankCode = dict["bankCode"] as? Int
        }
        
        if(dict["cardCashLimit"] is Int)
        {
            self.cardCashLimit = dict["cardCashLimit"] as? Int // month total limit
        }
        
        if(dict["cardNumber"] is String)
        {
            self.cardNumber = dict["cardNumber"] as? String
        }
        if(dict["cardHolderName"] is String)
        {
            self.cardHolderName = dict["cardHolderName"] as? String
        }

        if(dict["cardCreditLimit"] is Int)
        {
            self.cardCreditLimit = dict["cardCreditLimit"] as? Int
        }
        if(dict["cardRegistered"] is Int)
        {
            self.cardCreditLimit = dict["cardCreditLimit"] as? Int
        }
        if(dict["cardScheme"] is String)
        {
            self.cardScheme = dict["cardScheme"] as? String
        }
        if(dict["cardStatus"] is Bool)
        {
            self.cardStatus = dict["cardStatus"] as? Bool
        }
        if(dict["cardType"] is String)
        {
            self.cardType = dict["cardType"] as? String
        }
        if(dict["created"] is Int)
        {
            self.created = dict["created"] as? Int
        }

        if(dict["dayLimit"] is Int)
        {
            self.dayLimit = dict["dayLimit"] as? Int
        }
        
        if(dict["emailId"] is String)
        {
            self.emailId = dict["emailId"] as? String
        }

        if(dict["exipryDate"] is Int)
        {
            self.exipryDate = dict["exipryDate"] as? Int
        }
        if(dict["groupReference"] is Int)
        {
            self.groupReference = dict["groupReference"] as? Int
        }
        if(dict["intlCardLimit"] is Int)
        {
            self.intlCardLimit = dict["intlCardLimit"] as? Int
        }
        if(dict["mobileNumber"] is Int)
        {
            self.mobileNumber = dict["mobileNumber"] as? Int
        }
        if(dict["mxpAccountNumber"] is Int)
        {
            self.mxpAccountNumber = dict["mxpAccountNumber"] as? Int
        }
        if(dict["oldCardNumber"] is Int)
        {
            self.oldCardNumber = dict["oldCardNumber"] as? Int
        }
        if(dict["primaryAddOnIndicator"] is Int)
        {
            self.primaryAddOnIndicator = dict["primaryAddOnIndicator"] as? Int
        }
        if(dict["productName"] is String)
        {
            self.productName = dict["productName"] as? String
        }
        if(dict["referenceNumber"] is String)
        {
            self.referenceNumber = dict["referenceNumber"] as? String
        }
        if(dict["responseCode"] is Int)
        {
            self.responseCode = dict["responseCode"] as? Int
        }
        if(dict["updated"] is Int)
        {
            self.updated = dict["updated"] as? Int
        }
        if(dict["virtualCardNumber"] is String)
        {
            self.virtualCardNumber = dict["virtualCardNumber"] as? String
        }
    }
}

// active = y
// card status = 0 == ON


