//
//  RecentTransModel.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 20/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

class RecentTransList: NSObject {
   
    var amount : String?
    var channelId : String?
    var merchantMID : String?
    var merchantName : String?
    var referenceNumber : String?
    var txnDate : Int?
    var tXNTime : Int?
    var txnDateString : String?
    var tXNTimeString : String?
    var txn_message : String?
    
    
    
    init(dict : [String:Any])
    {
        print(dict)
        if(dict["amount"] is Int)
        {
            let amtInt = dict["amount"] as? Int
            self.amount = String(amtInt!)
        }
        
        if(dict["channelId"] is Int)
        {
            let channlIdInt = dict["channelId"] as? Int
            self.channelId = String(channlIdInt!)
        }
        
        
        if(dict["merchantMID"] is String)
        {
            self.merchantMID = dict["merchantMID"] as? String
        }
        
        if(dict["merchantName"] is String)
        {
            self.merchantName = dict["merchantName"] as? String
        }
        
        if(dict["referenceNumber"] is String)
        {
            self.referenceNumber = dict["referenceNumber"] as? String
        }
        
        if(dict["txnDate"] is Int)
        {
            self.txnDate = dict["txnDate"] as? Int
        }
        
        if(dict["tXNTime"] is Int)
        {
            self.tXNTime = dict["tXNTime"] as? Int
        }
        
        if(dict["txn_message"] is String)
        {
            self.txn_message = dict["txn_message"] as? String
        }

        
        
//        if(dict["cardNumber"] is String)
//        {
//            //let intCardNumber = dict["cardNumber"] as! Int
//            self.cardNumber = dict["cardNumber"] as? String
//        }
//        
//        if(dict["primaryAddOnIndicator"] is Int)
//        {
//            self.primaryAddOnIndicator = dict["primaryAddOnIndicator"] as? Int
//        }
//        if(dict["referenceNumber"] is String)
//        {
//            self.refNo = dict["referenceNumber"] as! String? //String(intCardStatus)
//        }
    }

}
