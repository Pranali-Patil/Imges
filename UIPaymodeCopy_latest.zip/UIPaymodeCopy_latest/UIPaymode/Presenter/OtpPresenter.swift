//
//  OtpPresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 28/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol PotpCallback {
    func onSuccess(message : String)
}

class OtpPresenter: NSObject {
    
    var delegate : PotpCallback?
    
    init(potpCallback : PotpCallback)
    {
        self.delegate = potpCallback
    }
    
    // 	static String otp = "{'bankcode':'00006', 'reference_number': '448110971909ea03c5b5fbd812b911d2', 'otp':'1234', 'class_name':'OTPVerificationService','function':'validateOTP'}";
    
    
    //MARK:-verify OTP
    func hitOTPService(otpString : String)
    {
        let  stringURL = "'reference_number':'\(gSessionID)','bankcode':'\(gBankCode)','otp':'\(otpString)','class_name':'OTPVerificationService','function':'validateOTP'"
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        print(correctedURL)
        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let responseDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(responseDict)
                    
                    if(responseDict["responseCode"] as? Int == successResponseCode)
                    {
                        //CommonClass().alertToast(title: "Success", message: "Card Status changed successfully")
                        //self.delegate?.onSuccessMpin(successBool: true)
                        self.delegate?.onSuccess(message: responseDict["message"] as! String)
                    }
                    else
                    {
                        // SCLAlertView().showError("Failure", subTitle: (responseDict["responseCode"] as! String)) // Error
                        //self.delegate?.onSuccessMpin(successBool: false)
                        
                    }
                    
                    
                    
                    print("nmbjkmnbk",responseDict)
                }
            }
            
        } , onFailure: {  error in
            
        })

    }
    
    //MARK:-verify OTP
    func resentOTPhit(cardNumber : String)
    {
        //	static String reOtp = "{'session_id':'907351', 'username':'carduser', 'bankcode':'00006', 'reference_number': '448110971909ea03c5b5fbd812b911d2', 'otp':'123456', 'class_name':'OTPVerificationService','function':'reGenerateOtp'}";
        let  stringURL = "'card_number':'\("01ACED4120965F349234785A2DE23114A6B06D986A4AAEA8798C3ACDEE20D59D")','bankcode':'\(gBankCode)','class_name':'UserRegistrationService','function':'addUser'"
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        print(correctedURL)
        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let responseDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(responseDict)
                    
                    if(responseDict["responseCode"] as? Int == successResponseCode)
                    {
                        //CommonClass().alertToast(title: "Success", message: "Card Status changed successfully")
                        //self.delegate?.onSuccessMpin(successBool: true)
                        gSessionID = responseDict["responseObject"] as! String
                        self.delegate?.onSuccess(message: responseDict["message"] as! String)
                    }
                    else
                    {
                        // SCLAlertView().showError("Failure", subTitle: (responseDict["responseCode"] as! String)) // Error
                        //self.delegate?.onSuccessMpin(successBool: false)
                        
                    }
                    
                    
                    
                    print("nmbjkmnbk",responseDict)
                }
            }
            
        } , onFailure: {  error in
            
        })
        
    }
    
    

}
