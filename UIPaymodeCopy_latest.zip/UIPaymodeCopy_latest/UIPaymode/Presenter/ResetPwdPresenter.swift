//
//  ResetPwdPresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 24/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol PresetPwdPresenterCallback {
    
    func onValidateResponse(responseString : String)
    func onSuccess(message : String)
    func onError(message:String)
}


class ResetPwdPresenter: NSObject {
    
    var delegate : PresetPwdPresenterCallback?

    init(pPresetPwdPresenterCallback : PresetPwdPresenterCallback)
    {
        self.delegate = pPresetPwdPresenterCallback
    }
    
    func validatePaswrd(passwordString : String)->Bool
    {
        let regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,20}$"
        if let range = passwordString.range(of:regexp, options: .regularExpression) {
            let result = passwordString.substring(with:range)
            print(result)
        }
        else
        {
            return false
        }
        
        return true
    }
    
    func validateFieldsOnSubmit(username : String , otpString : String , newPasswrd : String , confrmPasswrd : String)
    {
        if(otpString.characters.count == 6)                         // check otp length
        {
            let validatePwdBool = self.validatePaswrd(passwordString: newPasswrd)
            
            if validatePwdBool == true                              // check pwd with regex
            {
                if(newPasswrd == confrmPasswrd)
                {
                    let md5Data = CommonClass().MD5(string:newPasswrd)
                    let md5Hex =  md5Data!.map { String(format: "%02hhx", $0) }.joined()
                    print("md5Hex: \(md5Hex)")
                    
                    let encrptedPwd = md5Hex//"cfd031fcae0f0dcb451dee4a6a1f792a"//md5Hex

                    let  stringURL = "'session_id':'\(gSessionID)','username':'\(username)','bankcode':'\(gBankCode)','password':'\(encrptedPwd)','otp':'\(otpString)','class_name':'OTPVerificationService','function':'updatePassword'"
                    var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
                    correctedURL = commonURL + "param=" + correctedURL
                    
                    self.hitResetPassword(urlString:correctedURL)

                    
                }
                
                else
                {
                    self.delegate?.onValidateResponse(responseString: "new password and confirm password  should be same")

                }
            }
            else
            {
                self.delegate?.onValidateResponse(responseString: passwrdMessage)

            }
            
        }
        
        else
        {
            self.delegate?.onValidateResponse(responseString: "Please enter valid OTP Pin")
        }
    }
    
    func hitResetPassword(urlString : String)
    {
        CommunicationManager.sendGetURL(stringURL: urlString , onSuccess: { (response) in
            
            
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let recentDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(recentDict)
                    
                    if(recentDict["responseCode"] as? Int == successResponseCode)
                    {
                        self.delegate?.onSuccess(message: (recentDict["message"] as? String)!)
                    }
                    else
                    {
                        self.delegate?.onValidateResponse(responseString: (recentDict["message"] as? String)!)      
                    }
                    
                    
                } else {
                    //self.delegate!.onErrorMessage(errorMsg: "error occurred")
                    self.delegate?.onValidateResponse(responseString: "Please try again")
                    
                    //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: "error occurred")
                }
            }
        }) { (error) in
            
            //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: (error?.localizedDescription)!)
        }

    }
    
    
    func setPwdCredential(username:String , passwrd : String , mPIN : String)
    {
        //	static String addUser = "{'username':'test1','password':'1234', 'bankcode':'00006', 'reference_number': '2c29ab475d13c0c82564f59bf03c7986','mpin':'1234','device_id':'737783476877','platform':'android','class_name':'UserCredentialsService','function':'setUserCredentials'}";
        let md5Data = CommonClass().MD5(string:"1234")
        let md5Hex =  md5Data!.map { String(format: "%02hhx", $0) }.joined()
        print("md5Hex: \(md5Hex)")

        let  stringURL = "'username':'\(username)','password':'\(passwrd)','mpin':'\(md5Hex)','bankcode':'\(gBankCode)','reference_number':'\(gSessionID)','device_id':'737783476878','platform':'iOS','class_name':'UserCredentialsService','function':'setUserCredentials'"
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        
        print(correctedURL)
        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let responseDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(responseDict)
                    
                    if(responseDict["responseCode"] as? Int == successResponseCode)
                    {
                        //CommonClass().alertToast(title: "Success", message: "Card Status changed successfully")
                        //self.delegate?.onSuccessMpin(successBool: true)
                        //gSessionID = responseDict["responseObject"] as! String
                        self.delegate?.onSuccess(message: responseDict["message"] as! String)
                    }
                    else
                    {
                        // SCLAlertView().showError("Failure", subTitle: (responseDict["responseCode"] as! String)) // Error
                        //self.delegate?.onSuccessMpin(successBool: false)
                        self.delegate?.onError(message: responseDict["message"] as! String)
                        
                    }
                    
                    
                    
                    print("nmbjkmnbk",responseDict)
                }
            }
            
        } , onFailure: {  error in
self.delegate?.onError(message: (error?.localizedDescription)!)
        })

    }
    
}
