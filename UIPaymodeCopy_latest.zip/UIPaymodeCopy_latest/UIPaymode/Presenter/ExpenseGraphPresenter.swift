//
//  ExpenseGraphPresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 30/12/1938 Saka.
//  Copyright © 1938 Saka WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol PexpenseGraphCallBack {
    func expenseCallBackSuccess(expensseDict : NSDictionary)
    func expenseNoDataFound()
    func onFailure(stringMsg:String)
}

class ExpenseGraphPresenter: NSObject {
    
    var delegate : PexpenseGraphCallBack?

    init(pexpenseGraphCallBack : PexpenseGraphCallBack)
    {
        self.delegate = pexpenseGraphCallBack
    }
    
    func hitExpenseGraph(refNo:String)
    {
        //static String spends = "{'session_id':'261233', 'username':'carduser', 'bankcode':'00035', 'reference_number': 'e216ed048d02c47ff47116370cac253a', 'startDate': '20151001', 'endDate': '20151031', 'class_name':'TransactionService','function':'getSpendAnalyser'}";
        let  stringURL = "'username':'\(gUsername)','session_id':'\(gSessionID)','bankcode':'\(gBankCode)','reference_number':'\(refNo)','class_name':'TransactionService','function':'getSpendAnalyser'"
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let responseDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(responseDict)
                    self.delegate?.expenseCallBackSuccess(expensseDict: responseDict as NSDictionary)
                }
            }
        } , onFailure: {(error) in
            self.delegate?.onFailure(stringMsg: (error?.localizedDescription)!)
        })
    }
    
}
