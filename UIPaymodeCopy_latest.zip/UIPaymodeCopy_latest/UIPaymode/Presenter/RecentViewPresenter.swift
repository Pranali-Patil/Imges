//
//  RecentViewPresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 16/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol PRecentTrans
{
    func onSucceesfullResponse()
    func onErrorMessage(errorMsg: String)
    func onSuccessfulTransHistory(transArray : NSArray)
}

class RecentViewPresenter: NSObject {
    
    var delegate : PRecentTrans?
    var reponsObjArray = NSMutableArray()
    
    
    init(pRecentTrans : PRecentTrans)
    {
       delegate = pRecentTrans
    }
    
    // hit recent tran server
    func hitRecentTransServer(referrenceNo : String , expensBool : Bool)//, password : String)
    {
        var  functionString  = String()
        if(expensBool == true)
        {
            functionString = "getSpendHistory"
        }
        else
        {
            functionString = "getTransactions"

        }
        
        
         let  stringURL = "'username':'\(gUsername)','session_id':'\(gSessionID)','bankcode':'\(gBankCode)','reference_number':'\(referrenceNo)','class_name':'TransactionService','function':'\(functionString)'"
        
        
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL

        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            
            
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {

                    let recentDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(recentDict)
                    let recentObj = LoginModel(loginDict: recentDict)
                    
                    if(recentObj.responseCode == successResponseCode)
                    {
                        let recDictArray = recentDict["responseObject"] as! NSArray
                        
                        for recentObj in recDictArray
                        {
                            let reModelObj = RecentTransList(dict: recentObj as! [String : Any])
                            
                            reModelObj.txnDateString = self.getDate(date: Double(reModelObj.txnDate!))
                            reModelObj.tXNTimeString = self.getTimeString(hourInt: reModelObj.tXNTime!)
                            reModelObj.amount = reModelObj.amount! + currencySymbol
                            self.reponsObjArray.add(reModelObj)
                        }
                        self.delegate?.onSuccessfulTransHistory(transArray: self.reponsObjArray)
                        
                        
                    }
                    
                    
                    
                    
//                    self.loginModeObj = LoginModel(loginDict: test)
//                    
//                    if(self.loginModeObj?.successCode! == true)
//                    {
//                        self.pLoginViewProtocolObj?.onSuccessfulResponse(sessionID : (self.loginModeObj?.session_id!)!)
//                    }
//                    else
//                    {
//                        self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: (self.loginModeObj?.succeessMsg!)!)
//                        
//                    }
//                    
//                    
//                    print(test)
//                    
//                    
                } else {
                    self.delegate!.onErrorMessage(errorMsg: "error occurred")
                    
                    //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: "error occurred")
                }
            }
            
            
            
            
            print(response!)
            
        }) { (error) in
            
            //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: (error?.localizedDescription)!)
        }

    }
    
    // get time from unix time stamp
    func getDate(date : Double) -> String
    {
        let txnTimeStamp : Double = date/1000
        let date = Date(timeIntervalSince1970: (txnTimeStamp))
        print(date)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM dd, yyyy"
        let dateString = dateFormatter.string(from: date)
        print(dateString)
        return dateString
        
    }
    
    //return time in string format
    func getTimeString(hourInt : Int) -> String
    {
        var hourTime : Float = Float(hourInt)/10000
        var amString = "am"
        var zeroValueString = ""
        if hourTime > 12
        {
            hourTime = hourTime - 12
            if(Int(hourTime) == 0)
            {
                zeroValueString = "00"
            }
            else if((Int(hourTime) > 0 ) && (Int(hourTime)<10) )
            {
                zeroValueString = "0"
            }
            amString = "pm"
            
        }
        
        let trxnTimeString : String = zeroValueString + String(Int(hourTime*10000))
        let trxnTime = CommonClass().insert(seperator: ":", afterEveryXChars: 2, intoString: trxnTimeString)
        print(trxnTime + " " + amString)

        return ("\(trxnTime) \(amString)")
    }
    
    
    
    
}
    


    
    
    //static String spendsHistory = "{'session_id':'261233', 'username':'carduser', 'bankcode':'00035', 'reference_number': 'e216ed048d02c47ff47116370cac253a', 'startDate': '20151001', 'endDate': '20150924', 'class_name':'TransactionService','function':'getSpendHistory'}"
    
    

