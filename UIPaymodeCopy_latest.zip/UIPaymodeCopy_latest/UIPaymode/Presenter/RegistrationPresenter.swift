//
//  RegistrationPresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 28/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol  PRegistrationCallBack {
    func onSuccessfulRegistration(message : String)
}

class RegistrationPresenter: NSObject {
    
    var delegate : PRegistrationCallBack?
    init(pRegistrationCallBack : PRegistrationCallBack)
    {
        self.delegate = pRegistrationCallBack
    }
    
    // get cardd type
    func getCardSchemeImage(cardLogoImgView : UIImageView , cardNumberString : String)
    {
        // 3- american express
        // 4 - visa
        // 5 - master card
        // 6 - rupay
        switch(cardNumberString)
        {
            case " 3" : cardLogoImgView.image = UIImage(named: "americanExp")
            case " 4" : cardLogoImgView.image = UIImage(named: "visa")
            case " 5" : cardLogoImgView.image = UIImage(named: "mastercard")
            case " 6" : cardLogoImgView.image = UIImage(named: "ruPay")

            default: break
        }
    }
    
    // hit add card url
    func hitAddCardURL(cardNumber : String)
    {
        let cardNumberString = cardNumber.replacingOccurrences(of: " ", with: "")
        
        let cardData = getEncryptedCardNumber(cardNumberString: cardNumberString)
        

        
        //static String register = "{'bankcode':'00006', 'card_number': '4311193000335322', 'class_name':'UserRegistrationService','function':'addUser'}";
        let  stringURL = "'card_number':'\(cardData.encryptedCardNumber)','bankcode':'\(gBankCode)','class_name':'UserRegistrationService','function':'addUser','platform':'ios'"
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        print(correctedURL)
        
        
       // print(str)
        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let responseDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(responseDict)
                    
                    if(responseDict["responseCode"] as? Int == successResponseCode)
                    {
                        //CommonClass().alertToast(title: "Success", message: "Card Status changed successfully")
                        //self.delegate?.onSuccessMpin(successBool: true)
                        gSessionID = responseDict["responseObject"] as! String
                        self.delegate?.onSuccessfulRegistration(message: responseDict["message"] as! String)
                    }
                    else
                    {
                        CommonClass().alertToast(title: "Error", message: responseDict["message"] as! String, alerBool: true)
                       // SCLAlertView().showError("Failure", subTitle: (responseDict["responseCode"] as! String)) // Error
                       // self.delegate?.onSuccessfulRegistration(message: false)
                        
                    }
                    
                    
                    
                    print("nmbjkmnbk",responseDict)
                }
            }
            
        } , onFailure: {  error in
            
        })


    }
    
    func getEncryptedCardNumber(cardNumberString : String) ->(encryptedCardNumber : String , randomIV:String)
    {
        
        let stringEncryptionObj = StringEncryption()
        
        let randomIVString : String = "4d5390bef3ef1ee3" //kept static
        
        //static key
        let keyValueString : String = "4d5390bef3ef1ee3d4a7e77fd42238cc"
        
        //strengthen by SHA256
        let keySHA256String : String = stringEncryptionObj.sha256(keyValueString, length: 32)

        //encrypt card number
        let cardDataNumberData = Data.init(base64Encoded: cardNumberString.toBase64())
        let encryptedCardData : Data = stringEncryptionObj.encrypt(cardDataNumberData, key: keySHA256String, iv: randomIVString)
        
        let cardDataNumberDataString  = encryptedCardData.base64EncodedString(options: Data.Base64EncodingOptions.init(rawValue: 0))
        
        print(cardDataNumberDataString)
        print(randomIVString)
        
        
        return (encryptedCardNumber : cardDataNumberDataString , randomIV : randomIVString)
        
    }
    

}
