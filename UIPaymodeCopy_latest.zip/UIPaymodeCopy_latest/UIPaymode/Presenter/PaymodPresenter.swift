//
//  PaymodPresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 10/03/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol PPaymentCallback {
    func onSuccessCallback(message:String)
}

class PaymodPresenter: NSObject {
    
    var delegate : PPaymentCallback?
    
    init(pPaymentCallback : PPaymentCallback)
    {
        self.delegate = pPaymentCallback
    }

    func hitPaymodeSaveChanges(refNo: String)
    {
        //static String updateCard = "{'session_id':'261233', 'username':'carduser', 'bankcode':'00035', 'reference_number': 'e216ed048d02c47ff47116370cac253a', 'update':'{\"Active\":{\"change_flag\":\"N\",\"enable\":\"N\"},\"channels_list\":[{\"channel_id\":1,\"change_flag\":\"N\",\"enable\":\"Y\"},{\"channel_id\":2,\"change_flag\":\"N\",\"enable\":\"Y\"},{\"channel_id\":3,\"change_flag\":\"N\",\"enable\":\"Y\"},{\"channel_id\":4,\"change_flag\":\"N\",\"enable\":\"Y\"}],\"txn_limit\":{\"change_flag\":\"Y\",\"amount\":\"500000\"},\"overall_limit\":{\"change_flag\":\"Y\",\"amount\":\"1000\"}}', 'mpin':'e10adc3949ba59abbe56e057f20f883e', 'class_name':'SetCardStatus','function':'setCardStatus'}";
        let md5Data = CommonClass().MD5(string:"999999")
        let md5Hex =  md5Data!.map { String(format: "%02hhx", $0) }.joined()
        print("md5Hex: \(md5Hex)")

        
        //let  stringURL = "'session_id':'1234','username':'test1','bankcode':'00035','reference_number':'\(refNo)','update':'{\"Active\":{\"change_flag\":\"N\",\"enable\":\"N\"},\"channels_list\":[{\"channel_id\":1,\"change_flag\":\"N\",\"enable\":\"Y\"},{\"channel_id\":2,\"change_flag\":\"N\",\"enable\":\"Y\"},{\"channel_id\":3,\"change_flag\":\"N\",\"enable\":\"Y\"},{\"channel_id\":4,\"change_flag\":\"N\",\"enable\":\"Y\"}],\"txn_limit\":{\"change_flag\":\"Y\",\"amount\":\"500000\"},\"overall_limit\":{\"change_flag\":\"Y\",\"amount\":\"1000\"}}','mpin':'\(md5Hex)','class_name':'SetCardStatus','function':'setCardStatus'"
        
        let  stringURL = "'session_id':'1234','username':'test1','bankcode':'00035','reference_number':'\(refNo)','update':'{'Active':{'change_flag':'N','enable':'N'},'channels_list':[{'channel_id':1,'change_flag':'N','enable':'Y'},{'channel_id':'2','change_flag':'N','enable':'Y'},{'channel_id':'3','change_flag':'N','enable':'Y'},{'channel_id':'4','change_flag':'N','enable':'Y'}],'txn_limit':{'change_flag':'Y','amount':'500000'},'overall_limit':{'change_flag':'Y','amount':'1000'}}','mpin':'\(md5Hex)','class_name':'SetCardStatus','function':'setCardStatus'"
        //http://192.168.32.213:8080/PayModGlobal/services/MainService/masterService?param=%27session_id%27:%271234%27,%27username%27:%27test1%27,%27bankcode%27:%2700035%27,%27reference_number%27:%27hjb%27,%27update%27=%27Active%27:{%27change_flag%27:%27N%27,%27enable%27:%27N%27},%27channels_list%27:[{%27channel_id%27:1,%27change_flag%27:%27N%27,%27enable%27:%27Y%27},{%27channel_id%27:%272%27,%27change_flag%27:%27N%27,%27enable%27:%27Y%27},{%27channel_id%27:%273%27,%27change_flag%27:%27N%27,%27enable%27:%27Y%27},{%27channel_id%27:%274%27,%27change_flag%27:%27N%27,%27enable%27:%27Y%27}],%27txn_limit%27:{%27change_flag%27:%27Y%27,%27amount%27:%27500000%27},%27overall_limit%27:{%27change_flag%27:%27Y%27,%27amount%27:%271000%27,%27mpin%27:%2752c69e3a57331081823331c4e69d3f2e%27,%27class_name%27:%27SetCardStatus%27,%27function%27:%27setCardStatus%27%22
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        print(correctedURL)

        //let stringURL = "https://\(ipAddress):\(portNumber)/CCA-Service/validateCardHolder/bankCode=\(bankCode)/cardHolderId=\(userNameTextfield.text!)/password=\(encrptedPwd)"
        
        
        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            
            
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let test : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(test)
                    
                    
                    
                } else {
                    
                    //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: "error occurred")
                }
            }
            
            
            
            
            print(response!)
            
        }) { (error) in
            
            //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: (error?.localizedDescription)!)
        }
        
        
        
    }
    
    //MARK:-select country
    func selectedCountryAndMerchants(countryBool : Bool)->NSMutableArray
    {
        let defaults = UserDefaults.standard
        if(defaults.object(forKey: countryKey) == nil)
        {
            self.readjson()
        }
        
        var myDict = NSArray()
        
        // take out dictionary from user defaults
        if(countryBool == true)
        {
            myDict = defaults.object(forKey: countryKey) as! NSArray
        }
        else
        {
            myDict = defaults.object(forKey: merchanntKey) as! NSArray
            
        }
        
        // take out values of selected from an array
        let SelectedArray = NSMutableArray()
        
        for dictElement in myDict
        {
            let dictImmutableElement = dictElement as! NSDictionary
            if(dictImmutableElement["isSelected"] as? Bool == countryBool)
            {
                SelectedArray.add(dictImmutableElement["name"]!)
            }
        }
        
        // return an selected arrat
        return SelectedArray
    }
    
    //MARK:- read json
    func readjson()
    {
        if let filepath = Bundle.main.path(forResource: "Country", ofType: "txt")
        {
            do
            {
                let contents = try String(contentsOfFile: filepath)
                print(contents)
                let con = Array(contents.characters)
                print(con.count)
                print(con[17022])
                print(con[17023])
                print(con[17024])
                self.passJsonTct(jsonText: contents)
                
            }
            catch
            {
                // contents could not be loaded
            }
        }
        else
        {
            // example.txt not found!
        }
    }
    
    func passJsonTct(jsonText : String)
    {
        var dictonary:NSDictionary?
        
        if let data = jsonText.data(using: String.Encoding.utf8) {
            
            do {
                dictonary = try JSONSerialization.jsonObject(with: data, options: [])  as? NSDictionary
                
                
                if let myDictionary = dictonary
                {
                    print(myDictionary.count)
                    
                    print(myDictionary["country"])
                    let defaults = UserDefaults.standard
                    
                    // manipulate merchant array
                    let mutableMerchantArray = NSMutableArray()
                    let merchantMainArray : NSArray = myDictionary[merchanntKey] as! NSArray //defaults.value(forKey: merchanntKey) as! NSArray
                    
                    for merchantDict in merchantMainArray
                    {
                        for (key , value) in (merchantDict as! NSDictionary)
                        {
                            print(merchantDict)
                            let merchantDict : NSMutableDictionary = NSMutableDictionary()
                            merchantDict.setValue(key, forKey: "code")
                            merchantDict.setValue(value, forKey: "name")
                            merchantDict.setValue(true, forKey: "isSelected")
                            mutableMerchantArray.add(merchantDict)
                        }
                    }
                    let merchantArray : NSArray = Array(mutableMerchantArray) as NSArray
                    
                    
                    //country
                    defaults.set(myDictionary[countryKey], forKey:countryKey)
                    //merchants
                    defaults.set(merchantArray ,  forKey: merchanntKey)
                    UserDefaults.standard.synchronize()     // synchronise
                }
            } catch let error as NSError {
                print(error)
            }
        }
    }
    
    
    //MARK:-Paymode hit Hit
     


}

