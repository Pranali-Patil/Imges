//
//  OTPRequestPresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 24/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

protocol POTPRequesCallback {
    func onSuccessfulResponse(refNo:String)
}

class OTPRequestPresenter: NSObject {

    var delegate : POTPRequesCallback?
    
    init(pOTPRequesCallback : POTPRequesCallback)
    {
        self.delegate = pOTPRequesCallback
    }
    
    func reqForAnOTP(userNameString : String)
    {
        let  stringURL = "'username':'\(userNameString)','bankcode':'\(gBankCode)','class_name':'OTPVerificationService','function':'resetPassWord'"
        
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let responseDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    if(responseDict[responseCode] as? Int == successResponseCode)
                    {

                        gSessionID  = responseDict["responseObject"] as! String
                        self.delegate?.onSuccessfulResponse(refNo:String(describing: responseDict["responseObject"]))

                    }
                    
                    
                    print("nmbjkmnbk",responseDict)
                }
            }
            
        } , onFailure: {  error in
            
        })


    }
}
