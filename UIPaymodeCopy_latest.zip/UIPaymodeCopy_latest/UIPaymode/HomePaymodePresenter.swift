//
//  HomePaymodePresenter.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 14/02/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit
import SCLAlertView

let constMapName : String = "map"
//home call back
protocol PHomePaymodeCallBack{
    func onSuccessfulResponse(modelObjArray : NSMutableArray)
    func onSucceefulswitchPosition()
    func onSuccessMpin(successBool : Bool)
    func onSuccessBalanceHit(responseObject : String)
    // include error
}

class HomePaymodePresenter: NSObject {
    
    var delegate : PHomePaymodeCallBack?
    var homeModelObjArray = NSMutableArray()
    var refNumberArray = NSMutableArray()
    var paramDict = NSMutableDictionary()
    var homeChannelArray = NSMutableArray()
    var currentCardRefferenceNumber : String?
    var currentSwitchPosition : String?
    init(pLoginViewCallBack : PHomePaymodeCallBack)
    {
        delegate = pLoginViewCallBack
    }

    func getHomeData()
    {
        let stringUrl = commonURL + "param=%7B%27username%27:%27\(gUsername)%27,%27session_id%27:%27\(gSessionID)%27,%27bankcode%27:%2700035%27,%27device_id%27:%27737783477877%27,%27platform%27:%27ios%27,%27cp_flag%27:%27false%27,%27class_name%27:%27CardDetailsService%27,%27function%27:%27getCardDetails%27%7D"
        
        
        
        print(stringUrl)

        //let stringURL = "https://\(ipAddress):\(portNumber)/CCA-Service/validateCardHolder/bankCode=\(bankCode)/cardHolderId=\(userNameTextfield.text!)/password=\(encrptedPwd)"
        
        
        
        CommunicationManager.sendGetURL(stringURL: stringUrl , onSuccess: { (response) in
            
            
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let responseDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    
                    
                    
                    print("nmbjkmnbk",responseDict)
                    if(responseDict["responseCode"]  as? Int == successResponseCode)
                    {
                        if(responseDict["responseObject"]  is NSArray)
                        {
                            let homeCardArray : NSArray = responseDict["responseObject"]  as! NSArray
                            for homeElement in homeCardArray
                            {
                                let modelObj = HomePaymodeModel(dict: homeElement as! [String : Any])
                                self.refNumberArray.add("'\(modelObj.refNo!)'")
                                self.homeModelObjArray.add(modelObj)
                                
                            }
                            self.hitChannelDetails(referrenceNo: self.refNumberArray)
                            
                            self.delegate?.onSuccessfulResponse(modelObjArray: self.homeModelObjArray)
                            
                            
                        }
                        
                        else
                        {
                            print("handle error")
                        }
                    }
                    
                    else
                    {
                        print("handle error")
                    }
                    
                    //self.loginModeObj = LoginModel(loginDict: test)
                    
//                    if(self.loginModeObj?.successCode! == true)
//                    {
//                        //self.pLoginViewProtocolObj?.onSuccessfulResponse()
//                    
//                    }
//                    else
//                    {
//                        //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: (self.loginModeObj?.succeessMsg!)!)
//                        
//                    }
                    
                    
                   // print(test)
                    
                    
                } else {
                    
                    print(response?.error?.localizedDescription)
                    
                    //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: "error occurred")
                }
            }
            
            
            
            
            print(response!)
            
        }) { (error) in
            
            //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: (error?.localizedDescription)!)
        }

    }
    
    //hit channel details service
    func hitChannelDetails(referrenceNo : NSMutableArray)
    {
        let stringRepresentation = referrenceNo.componentsJoined(by: ",")
        
        print(stringRepresentation)
        
        //static String channel = "{'session_id':'261233','bankcode':'00006', 'reference_numbers':['2c29ab475d13c0c82564f59bf03c7986'],'username':'test','class_name':'AllChannelStatusService','function':'getChannelValues'}";
        let  stringURL = "'username':'\(gUsername)','session_id':'\(gSessionID)','bankcode':'\(gBankCode)','reference_numbers':[\(stringRepresentation)],'class_name':'AllChannelStatusService','function':'getChannelValues'"
        
        
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            
            
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let recentDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print("recCode" , recentDict)
                    if(recentDict["success"] as? Bool == true)
                    {
                        if(recentDict["status"] is NSDictionary)
                        {
                            let recentDictValue : NSDictionary = recentDict["status"] as! NSDictionary
                            if(recentDictValue["myArrayList"] is NSArray)
                            {
                                let myArrDetails : NSArray = (recentDictValue["myArrayList"] as! NSArray)
                                
                                for cardDetails in myArrDetails
                                {
                                    self.passChannelValues(cardChannelValues: cardDetails as! NSDictionary)
                                    self.homeChannelArray.add(self.paramDict)
                                }
                                self.delegate?.onSucceefulswitchPosition()
                                
                            }

                        }
                    }
                    
                } else {
                    
                    //self.pLoginViewProtocolObj?.onErrorMessage(errorMsg: "error occurred")
                }
            }
            
            
            
            
            print(response!)
            
        }) { (error) in
            
            print((error?.localizedDescription)!)
        }

    }
    
    //==== 1 ===== card validity check
    func passChannelValues(cardChannelValues : NSDictionary)  //handle first map dictionary
    {
        if cardChannelValues[constMapName]  is  NSDictionary  //check card validity
        {
            let reponseDict = cardChannelValues[constMapName]  as!  NSDictionary
            if(reponseDict["responseCode"] as? Int == successResponseCode)
            {
                if reponseDict["responseObject"] is NSDictionary
                {
                    let responseObjDict =  reponseDict["responseObject"] as! NSDictionary
                    if(responseObjDict[constMapName] is NSDictionary)
                    {
                        self.checkCardActivityDetails(cardActivityDetails:responseObjDict[constMapName] as! NSDictionary)
                    }
                }
            }
            
            else
            {
                //FIXME:- handle error
            }
        }
        
    }
    
    //==== 2 ===== card activity check (POS access details)
    func checkCardActivityDetails(cardActivityDetails : NSDictionary)
    {
        self.paramDict = NSMutableDictionary()
        print("ddwdewf" , cardActivityDetails)
        let modelObj = HomeCardPoseDetailsModel(dict: cardActivityDetails as! [String : Any])
        if(modelObj.cardDetail?[constMapName] is NSDictionary)
        {
            let modelMapDict : NSDictionary = modelObj.cardDetail?[constMapName] as! NSDictionary
            self.paramDict.setValue(modelObj, forKey: "HomeCardPoseDetailsModel")
            self.cardAccountDetails(cardAccountDetails: modelMapDict)
        }
        
    }
    
    //==== 3 ===== card Account Details  
    func cardAccountDetails(cardAccountDetails : NSDictionary)
    {
        let modelObj = HomeCardAccountHolderDetails(dict: cardAccountDetails as! [String : Any])
        self.paramDict.setValue(modelObj, forKey: "HomeCardAccountHolderDetails")
    }

    // get active status
    func getCurrentCardStatus(index : Int)->Bool
    {
        let modelObjDict : NSDictionary = homeChannelArray[index] as! NSDictionary
        let modelObj = modelObjDict["HomeCardPoseDetailsModel"] as! HomeCardPoseDetailsModel
        self.currentCardRefferenceNumber = modelObj.referenceNumber
        self.currentSwitchPosition = "Y"

        var boolToBeReturn : Bool = false
        if( modelObj.active == "Y")
        {
            boolToBeReturn = true
            self.currentSwitchPosition = "N"
            
        }
        
        return boolToBeReturn
    }
    
    //MARK:mpin pop up code
    func popppedUPmPINView()
    {
        // Add a text field
        let alert = SCLAlertView(appearance: SCLAlertView.SCLAppearance(showCloseButton : false))
        
        let txt = alert.addTextField("Enter your MPIN")
        alert.addButton("Submit") {
            print("Text value: \(txt.text)")
            
            let md5Data = CommonClass().MD5(string:txt.text!)
            let md5Hex =  md5Data!.map { String(format: "%02hhx", $0) }.joined()
            print("md5Hex: \(md5Hex)")
            self.urlHitMPIN(mPinString:md5Hex)
            //self.delegate?.onSuccessMpin(successBool: true)
        }
        alert.addButton("Cancel", action: {
            self.delegate?.onSuccessMpin(successBool: false)
        })
        alert.showEdit(dialogueTitle ,
                       subTitle: "Please Enter your MPIN" ,
                       colorStyle : primaryColorHex)
    }
    
    
    //hit mpinService
    func urlHitMPIN(mPinString : String)
    {
        //static String cardlock = "{'session_id':'261233', 'username':'carduser', 'bankcode':'00035', 'reference_number': 'c1055d4f90d70824157abc7778d1ef75', 'lockCode':'N', 'mpin':'e10adc3949ba59abbe56e057f20f883e', 'class_name':'ToggleCardLock','function':'toggleCardLock'}"
        let  stringURL = "'username':'\(gUsername)','session_id':'\(gSessionID)','bankcode':'\(gBankCode)','reference_number':'\(self.currentCardRefferenceNumber!)','lockCode':'\(self.currentSwitchPosition!)','mpin':'\(mPinString)','class_name':'ToggleCardLock','function':'toggleCardLock'"
       // let strURL = "'session_id':'\(gSessionID)', 'username':'\(gUsername)', 'bankcode':'\(gBankCode)', 'reference_number': '\(self.currentCardRefferenceNumber!)', 'lockCode':'\(self.currentSwitchPosition!)', 'mpin':'\(mPinString)', 'class_name':'ToggleCardLock','function':'toggleCardLock'";
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL

        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let responseDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    
                    if(responseDict["responseCode"] as? Int == successResponseCode)
                    {
                        CommonClass().alertToast(title: "Success", message: "Card Status changed successfully")
                        self.delegate?.onSuccessMpin(successBool: true)
                        
                    }
                    else
                    {
                        SCLAlertView().showError("Failure", subTitle: (responseDict["message"] as! String)) // Error
                        self.delegate?.onSuccessMpin(successBool: false)
                        
                    }
                    
                    
                    
                    print("nmbjkmnbk",responseDict)
                }
            }
            
        } , onFailure: {  error in
        
    })
    }
    
    
    //hit piechart url
    //static String spends = "{'session_id':'261233', 'username':'carduser', 'bankcode':'00035', 'reference_number': 'e216ed048d02c47ff47116370cac253a', 'startDate': '20151001', 'endDate': '20151031', 'class_name':'TransactionService','function':'getSpendAnalyser'}";
    
    
    
    
    // tap submit button
    
    func hitPieChartUrl(referrenceNo : String)
    {
        let  stringURL = "'username':'\(gUsername)','session_id':'\(gSessionID)','bankcode':'\(gBankCode)','reference_number':'\(referrenceNo)','class_name':'CardDetailsService','function':'balanceEnquiry'"
        
        
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        
        CommunicationManager.sendGetURL(stringURL: correctedURL , onSuccess: { (response) in
            
            
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let recentDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(recentDict)
                }
            }
        }, onFailure: {(error) in
            CommonClass().alertToast(title: "Error", message:(error?.localizedDescription)!)
        })
    }
    
    func tapSubmitButton(){
        
    }
    
    // func refreshbutton hit
    func hitRefreshButton(referrenceNo : String)
    {
        
        let  stringURL = "'username':'\(gUsername)','session_id':'\(gSessionID)','bankcode':'\(gBankCode)','reference_number':'\(referrenceNo)','class_name':'CardDetailsService','function':'balanceEnquiry'"
        var correctedURL = CommonClass().getCorrectUrl(urlStrng: stringURL)
        correctedURL = commonURL + "param=" + correctedURL
        
        CommunicationManager.sendGetURL(stringURL: correctedURL, onSuccess: {
            (response) in
            if(response?.data != nil)
            {
                if let returnData = String(data: (response?.data!)!, encoding: .utf8)
                {
                    
                    let recentDict : [String:Any] = CommonClass().getJSONfromSoapXMLResponse(responseString: returnData)
                    print(recentDict)
                    if(recentDict["responseObject"] as? Int != nil)
                    {
                        let responseInt = (recentDict["responseObject"]) as! Int
                        self.delegate?.onSuccessBalanceHit(responseObject:String(responseInt))
                    }

                }
            }

            
        }, onFailure: {(error) in
            CommonClass().alertToast(title: "Error", message:(error?.localizedDescription)! , alerBool:  true)

        })
        
    }

    
    
}
