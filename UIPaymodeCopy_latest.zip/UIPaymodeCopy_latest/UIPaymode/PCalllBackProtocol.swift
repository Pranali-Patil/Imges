//
//  PCalllBackProtocol.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 23/01/17.
//  Copyright © 2017 WorldlineMacbook2. All rights reserved.
//

import UIKit

class PCalllBackProtocol: NSObject {

}

//mpinPop up delegate
protocol PMpinProtocol
{
    func onSuccessMpin(successBool : Bool)

}

// logoin View call back
protocol PLoginViewCallBack {
    func onSuccessfulResponse(sessionID : String)
    func onErrorMessage(errorMsg : String)
}

