//
//  ResetPwdViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 23/12/16.
//  Copyright (c) 2016 WorldlineMacbook2. All rights reserved.

/////
//regex   "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,20}$";

import UIKit

class ResetPwdViewController: UIViewController , UITextFieldDelegate , PresetPwdPresenterCallback
{
    
    @IBOutlet weak var usernameTxtField: UITextField!
    
    @IBOutlet weak var OTPTxtField: UITextField!
    
    @IBOutlet weak var newPwdTxtField: UITextField!
    
    @IBOutlet weak var confrmPwdTxtField: UITextField!
    @IBOutlet weak var resendOTPOutlet: UIButton!
    
    @IBOutlet weak var submitBtnOutlet: UIButton!
    
    
    //label outlets
    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var otpLabel: UILabel!
    
    @IBOutlet weak var newPwdLabel: UILabel!
    
    @IBOutlet weak var confrmPwdLabel: UILabel!
    
    @IBOutlet weak var headerView: UIView!
    
    @IBOutlet weak var otpDescriptiveLabel: UILabel!
    
    
    
    var recentPwdPresenterObj : ResetPwdPresenter?

    var commonClassObj : CommonClass?
    
    //ref number to maintain session
    var referrenceNumber : String?
    var usernameString : String? = "Default"
    
    //show pwd
    var showNewPwdSecureEntryBool : Bool = true
    var showConfrmPwdSecureEntryBool : Bool = true
    
    var forgotPwdBool : Bool?
    
    //for keyboard hide show logic
    var commonTextField : UITextField?
    var kbHeight = CGFloat()
    var offsetCheckBOOL :Bool? = false
    var helpPoppedUpflagValue : Bool? = false
    



    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.commonClassObj = CommonClass()
        self.setUITheme()
        
        //usernameTxtField.delegate = self
        
        //for username
        usernameTxtField.text = usernameString
        usernameTxtField.isUserInteractionEnabled = false
        usernameTxtField.textColor = UIColor.darkGray
        
        
        OTPTxtField.delegate = self
        newPwdTxtField.delegate = self
        confrmPwdTxtField.delegate = self
        
        confrmPwdTxtField.isSecureTextEntry = true
        newPwdTxtField.isSecureTextEntry = true
        
        
        self.recentPwdPresenterObj = ResetPwdPresenter(pPresetPwdPresenterCallback: self)
        
        let someString = "abc@123A"
        let regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,20}$"
        if let range = someString.range(of:regexp, options: .regularExpression) {
            let result = someString.substring(with:range)
            print(result)
        }
        
        if(forgotPwdBool == false)
        {
            self.setMpinLabel()
        }
        
        

        
        
        
    }
    
    func setMpinLabel()
    {
        otpLabel.text = "MPIN"
        otpDescriptiveLabel.text = "Please set your 6 digit MPIN"
        OTPTxtField.placeholder = "MPIN"
        resendOTPOutlet.isHidden = true
        usernameTxtField.isUserInteractionEnabled = true
        usernameTxtField.textColor = UIColor.black
        usernameTxtField.text = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setUITheme()
    {
        commonClassObj?.addBottomLine(textfield: usernameTxtField, borderColor: secondaryColor)
        commonClassObj?.addBottomLine(textfield: OTPTxtField , borderColor: secondaryColor)
        commonClassObj?.addBottomLine(textfield: newPwdTxtField, borderColor: secondaryColor)
        commonClassObj?.addBottomLine(textfield: confrmPwdTxtField, borderColor: secondaryColor)
        commonClassObj?.makeButtonRounded(button: resendOTPOutlet, backgroundColor: secondaryColor, textColor: textColor)
        commonClassObj?.makeButtonRounded(button: submitBtnOutlet, backgroundColor: secondaryColor, textColor: textColor)
        usernameLabel.textColor = secondaryColor
        otpLabel.textColor = secondaryColor
        newPwdLabel.textColor = secondaryColor
        confrmPwdLabel.textColor = secondaryColor
        headerView.backgroundColor = primaryColor
        
     }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)

    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if(textField == newPwdTxtField)
        {
            let checkBool  : Bool = (self.recentPwdPresenterObj?.validatePaswrd(passwordString: textField.text!))!
            if(checkBool == true)
            {
                return true
            }
            else
            {
                CommonClass().alertToast(title: "Password Validation", message: passwrdMessage)
                return false
            }
        }
        else
        {
            return true

        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    //MARK:-textfield Delegate
    func textFieldDidEndEditing(_ textField: UITextField) {
        //self.highlightUILabelWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, themeUIColor:UIColor.black)
        
        switch textField
        {
            case usernameTxtField : CommonClass().disableUILabelColorWithAnim(label: self.usernameLabel, textField: self.usernameTxtField, placeHolderString: "Username")
            case OTPTxtField : commonClassObj?.disableUILabelColorWithAnim(label: self.otpLabel, textField: self.OTPTxtField, placeHolderString: "OTP")
            case newPwdTxtField : commonClassObj?.disableUILabelColorWithAnim(label: self.newPwdLabel, textField: self.newPwdTxtField, placeHolderString: "New Password")
            case confrmPwdTxtField : commonClassObj?.disableUILabelColorWithAnim(label: self.confrmPwdLabel, textField: self.confrmPwdTxtField, placeHolderString: "Confirm Password")
            
            default : break
        }
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        self.commonTextField = textField
        switch textField
        {
        case usernameTxtField : commonClassObj?.highlightUILabelWithAnim(label: self.usernameLabel, textField: self.usernameTxtField, themeUIColor:secondaryColor)

        case OTPTxtField : commonClassObj?.highlightUILabelWithAnim(label: self.otpLabel, textField: self.OTPTxtField, themeUIColor:secondaryColor)
        case newPwdTxtField : commonClassObj?.highlightUILabelWithAnim(label: self.newPwdLabel, textField: self.newPwdTxtField, themeUIColor:secondaryColor)
        case confrmPwdTxtField : commonClassObj?.highlightUILabelWithAnim(label: self.confrmPwdLabel, textField: self.confrmPwdTxtField, themeUIColor:secondaryColor)
            
        default : break
        }
        
        return true
    }
    
    // resign txt fields functions
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)    {
        let touch: UITouch = event!.allTouches!.first!
        
        self.touchTxtField(currewntTextfield: self.usernameTxtField , touch: touch)
        self.touchTxtField(currewntTextfield: self.OTPTxtField , touch: touch)
        self.touchTxtField(currewntTextfield: self.newPwdTxtField , touch: touch)
        self.touchTxtField(currewntTextfield: self.confrmPwdTxtField , touch: touch)
        
        
        
        
        
        super.touchesBegan(touches, with: event)
        
    }
    
    func touchTxtField(currewntTextfield : UITextField , touch : UITouch)
    {
        if currewntTextfield.isFirstResponder && touch.view != currewntTextfield {
            currewntTextfield.resignFirstResponder()
        }
        
        
    }
    
    
    @IBAction func backButtonClicked(_ sender: Any) {
        
        let _ = self.navigationController?.popViewController(animated: true)
    }

    //action for show password
    @IBAction func showNewPwd(_ sender: Any) {
        if(showNewPwdSecureEntryBool == true)
        {
            newPwdTxtField.isSecureTextEntry = false
            showNewPwdSecureEntryBool = false
        }
        else
        {
            newPwdTxtField.isSecureTextEntry = true
            showNewPwdSecureEntryBool = true

        }
    }
    
    @IBAction func showConfrmPwd(_ sender: Any) {
        if(showConfrmPwdSecureEntryBool == true)
        {
            confrmPwdTxtField.isSecureTextEntry = false
            showConfrmPwdSecureEntryBool = false
        }
        else
        {
            confrmPwdTxtField.isSecureTextEntry = true
            showConfrmPwdSecureEntryBool = true
            
        }

    }
    

    //reset Pwd delegate 
    func onValidateResponse(responseString : String)
    {
        if responseString == "success"
        {
            
        }
        else
        {
            CommonClass().alertToast(title: "Error", message: responseString)
        }
        
    }
    func onSuccess(message : String)
    {
        CommonClass().alertToast(title: "", message: message )
        self.performSegue(withIdentifier: "showLogin", sender: self)
        //send to home
    }
    
    func onError(message:String)
    {
        CommonClass().alertToast(title: "" , message: message , alerBool: true)

    }
    // submit button clicked
    @IBAction func submitButtonClicked(_ sender: Any) {
        if(forgotPwdBool == true)
        {
            recentPwdPresenterObj?.validateFieldsOnSubmit(username: usernameTxtField.text!, otpString: OTPTxtField.text!, newPasswrd: newPwdTxtField.text!, confrmPasswrd: confrmPwdTxtField.text!)
        }
        else
        {
            recentPwdPresenterObj?.setPwdCredential(username: usernameTxtField.text!, passwrd: newPwdTxtField.text!, mPIN: OTPTxtField.text!)
        }
        

    }
    
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self)
    }
    
    //MARK:- keyboard logic
    func keyboardWillHide(notification:NSNotification)
    {
        //self.animatedTextField(up: false)
        self.view.frame = CGRect(x:0, y : 0, width:UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
    }
    
    func keyboardWillShow(notification:NSNotification)
    {
        let userInfo = notification.userInfo
        // var userInfo: [NSObject : AnyObject] = notification.userInfo!
        if userInfo != nil {
            let keyboardSize: CGRect = (userInfo![UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
            
            kbHeight = keyboardSize.size.height;
            
            print(commonTextField!.frame.origin.y+commonTextField!.frame.size.height)
            
            if (commonTextField!.frame.origin.y+commonTextField!.frame.size.height + 44 > kbHeight )
            {
                self.animatedTextField(up: true)
            }
        }
    }
    
    // aniated text field
    func animatedTextField(up:Bool)
    {
        let txtPosition: CGFloat = commonTextField!.frame.origin.y + commonTextField!.frame.size.height
        if txtPosition > (self.view.frame.size.height - kbHeight - 44)
        {
            if !(offsetCheckBOOL!)
            {
                let movement: CGFloat = (up ? -80 : 80)
                self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
                UIView.animate(withDuration: 0.0, animations: {() -> Void in
                    self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
                    self.offsetCheckBOOL! = true
                })
            }
                
            else
            {
                if(!up && offsetCheckBOOL!)
                {
                    self.view.frame = self.view.frame.offsetBy(dx: 0, dy: 80)
                    UIView.animate(withDuration: 0.0, animations: {() -> Void in
                        self.view.frame = self.view.frame.offsetBy(dx: 0, dy: 80)
                    })
                }
            }
        }
        
        if (up == true)
        {
            offsetCheckBOOL = true
        }
            
        else
        {
            offsetCheckBOOL = false
        }
        
    }

    
    
    

    
}
