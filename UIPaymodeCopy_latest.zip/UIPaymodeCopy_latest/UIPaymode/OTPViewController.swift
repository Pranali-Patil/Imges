//
//  OTPViewController.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 22/12/16.
//  Copyright (c) 2016 WorldlineMacbook2. All rights reserved.
//

//FIXME:- in constants
let textColor : UIColor = UIColor.white

import UIKit

class OTPViewController: UIViewController , UITextFieldDelegate , PotpCallback {
    
    @IBOutlet weak var verifyOTPBtnOutlet: UIButton!
    
    @IBOutlet weak var resetBtnOutlet: UIButton!
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    
    let customView = UIView()
    @IBOutlet weak var headerLabel: UILabel!
    
    @IBOutlet weak var headerView: UIView!
    
    
    @IBOutlet weak var OTPtxtfield: UITextField!
    var commonClassObj : CommonClass?
    var OTPpresenterObj : OtpPresenter?

    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.commonClassObj = CommonClass()
        OTPtxtfield.delegate = self
        
        self.OTPpresenterObj = OtpPresenter(potpCallback: self)


//        // Do any additional setup after loading the view.
//        verifyOTPBtnOutlet.layer.cornerRadius = 20
//        
//        resetBtnOutlet.layer.borderWidth = 1
//        
//        resetBtnOutlet.layer.borderColor = UIColor(red: 0 / 255, green: 103/255, blue: 161/255, alpha: 1).cgColor
//        resetBtnOutlet.layer.cornerRadius = 20
        self.setUITheme()
    }
    
    
    func setUITheme()
    {
        commonClassObj?.makeButtonRounded(button: verifyOTPBtnOutlet, backgroundColor: secondaryColor, textColor: textColor)
        commonClassObj?.makeButtonRounded(button: resetBtnOutlet, backgroundColor: secondaryColor, textColor: textColor)
        headerView.backgroundColor = primaryColor
        headerLabel.textColor = textColor
        titleLabel.textColor = secondaryColor
        titleLabel.isHidden = true
        commonClassObj?.makeCardViewEffect(customView: mainView, shadowColor: shadowColor, cornerRadius: cornerRadius)
        commonClassObj?.addBottomLine(textfield: OTPtxtfield, borderColor: secondaryColor)
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = false
    
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func popMpinButtonPressed(_ sender: AnyObject) {
        
//        let viewController:mPinViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("mPinViewAlert") as! mPinViewController
        
//        let viewController:mPinViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "popUpView") as! mPinViewController
//        
//        
//        
//        self.addChildViewController(viewController)
//        viewController.view.frame = CGRect(x: 0, y: 0,width: 250, height: (viewController.submitButtonOutlet.frame.origin.y+viewController.submitButtonOutlet.frame.height));
//        
//        viewController.view.center = self.view.center
//        viewController.view.layer.cornerRadius = 10
//        self.view.addSubview(viewController.view)
//        viewController.didMove(toParentViewController: self)
        
    }
    
    func buttonClicked(_ sender:AnyObject)
    {
        
    }
    
    
    
    
    
    
    //MARK:-textfield Delegate
    func textFieldDidEndEditing(_ textField: UITextField) {
        //self.highlightUILabelWithAnim(label: self.usernameLabel, textField: self.usernameTextfield, themeUIColor:UIColor.black)
        if(textField == OTPtxtfield)
        {
            CommonClass().disableUILabelColorWithAnim(label: self.titleLabel, textField: self.OTPtxtfield, placeHolderString: "Enter your OTP")
        }
        
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if(textField == OTPtxtfield)
        {
            //passwordTextfield.resignFirstResponder()
            CommonClass().highlightUILabelWithAnim(label: self.titleLabel, textField: self.OTPtxtfield, themeUIColor:secondaryColor)
        }
        
        return true
    }
    
    // resign txt fields functions
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)    {
        let touch: UITouch = event!.allTouches!.first!
        
        if self.OTPtxtfield.isFirstResponder && touch.view != self.OTPtxtfield {
            self.OTPtxtfield.resignFirstResponder()
        }

        
        super.touchesBegan(touches, with: event)
        
    }
    
    //back button clicked
    @IBAction func backButtonClicked(_ sender: Any) {
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func verifyButtonClicked(_ sender: Any) {
        
        OTPpresenterObj?.hitOTPService(otpString: OTPtxtfield.text!)
    }
    
    //MARK:presenter delegate
    func onSuccess(message : String)
    {
        CommonClass().alertToast(title: message, message: "")
        self.performSegue(withIdentifier: "setPwdSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "setPwdSegue")
        {
            let vc = segue.destination as! ResetPwdViewController
            vc.forgotPwdBool = false
        }
    }
    
    


    

}
