var AesUtil = function(keySize, iterationCount) {
  this.keySize = keySize / 32;
  this.iterationCount = iterationCount;
};

AesUtil.prototype.generateKey = function(salt, passPhrase) {
  var key = CryptoJS.PBKDF2(
      passPhrase, 
      CryptoJS.enc.Hex.parse(salt),
      { keySize: this.keySize, iterations: this.iterationCount });
  return key;
}

var generateKey = function(salt, passPhrase) {
    var key = CryptoJS.PBKDF2(
                              passPhrase,
                              CryptoJS.enc.Hex.parse(salt),
                              { keySize: this.keySize, iterations: this.iterationCount });
    return key;
}


// var encrypt = function(salt, iv, passPhrase, plainText) {
//    var key = this.generateKey(salt, passPhrase);
//    var encrypted = CryptoJS.AES.encrypt(
//                                         plainText,
//                                         key,
//                                         { iv: CryptoJS.enc.Hex.parse(iv) });
//    return "hello"//encrypted.ciphertext.toString(CryptoJS.enc.Base64);
//}

var encrypt = function(salt, iv, passPhrase, plainText) {
    var key = this.generateKey(salt, passPhrase);
    
    return "Hola " + salt + " Cómo estás?" + salt;
}


//AesUtil.prototype.encrypt = function(salt, iv, passPhrase, plainText) {
//  var key = this.generateKey(salt, passPhrase);
//  var encrypted = CryptoJS.AES.encrypt(
//      plainText,
//      key,
//      { iv: CryptoJS.enc.Hex.parse(iv) });
//  return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
//}

// ===============================
//var testEncrypt = new AesUtil();
//testEncrypt.encrypt = function(salt, iv, passPhrase, plainText){
//    return AesUtil.prototype.encrypt(salt,iv, passPhrase, plainText);
//}

//var encrypt = function(salt, iv, passPhrase, plainText) {
//    
//    var key = this.generateKey(salt, passPhrase);
//    var encrypted = CryptoJS.AES.encrypt(
//                                         plainText,
//                                         key,
//                                         { iv: CryptoJS.enc.Hex.parse(iv) });
//    return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
//}

//var hola = function(name , ret) {
//    return "Hola " + name + " Cómo estás?" + ret;
//}

var hola = function(name , ret) {
    return "Hola " + name + " Cómo estás?" + ret;
}

var hello = function()
{
    return hola('Gitesh','Gawade')
}
// ===========================
AesUtil.prototype.decrypt = function(salt, iv, passPhrase, cipherText) {
  var key = this.generateKey(salt, passPhrase);
  var cipherParams = CryptoJS.lib.CipherParams.create({
    ciphertext: CryptoJS.enc.Base64.parse(cipherText)
  });
  var decrypted = CryptoJS.AES.decrypt(
      cipherParams,
      key,
      { iv: CryptoJS.enc.Hex.parse(iv) });
  return decrypted.toString(CryptoJS.enc.Utf8);
}
