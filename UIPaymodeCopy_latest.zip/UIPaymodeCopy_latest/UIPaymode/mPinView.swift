//
//  mPinView.swift
//  UIPaymode
//
//  Created by WorldlineMacbook2 on 22/12/16.
//  Copyright (c) 2016 WorldlineMacbook2. All rights reserved.
//

import UIKit

class mPinView: UIView {

    @IBOutlet weak var submtBtnOutlet: UIButton!
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        submtBtnOutlet.layer.borderWidth = 2
        submtBtnOutlet.layer.borderColor = UIColor.white.cgColor
        submtBtnOutlet.layer.cornerRadius = 20
        
        
    }

    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    @IBAction func submitButtonClicked(_ sender: AnyObject) {
        
    }

    

}
