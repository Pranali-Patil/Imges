//
//  RegisterPresenter.swift
//  ToDoAPP
//
//  Created by BridgeLabz on 13/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

/*
 presenter for the register 
1.Data validation 
2.Alert message is given to register view
3.Data will passes to the register Model
 
 */
import Foundation



protocol registerProtocolDelegate {
    func showSuccess(str:String,title:String)
    func showFailure(str:String,title:String)
}
//protocol registerProtocolModelDelegate {
//     func addData(userName:String,userEmail:String,passWord:String)
//}
class RegisterPresenter:NSObject
{

    var msg = ""
    var title = ""
    
    //protocol object
    var mRegisterProtocolObj:registerProtocolDelegate?
   // var mRegisterProtocolModelObj:registerProtocolModelDelegate?
    
    var registerModel:RegisterModel?
    init(registerProtocolObj:registerProtocolDelegate)
    {
        mRegisterProtocolObj = registerProtocolObj
       // mregisterModel = RegisterModel()
       registerModel = RegisterModel()
    }
    
    
    // validation function
    func validateData(name:String,email:String,passWord:String,rePassWord:String)
    {
        
        if(email.isEmpty || passWord.isEmpty || rePassWord.isEmpty)
        {
        msg = "Please  Fill All the details ..."
        title = "!!OOPS..😣.!!"
        mRegisterProtocolObj?.showFailure(str: msg, title: title)
          
        }
        
        // email validation
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        var check = emailPredicate.evaluate(with: email)
        
        
        
        if (check)
        {
            // Password validation
            if passWord.characters.count >= 7 && rePassWord.characters.count >= 7
            {
                // confirm passWord validation
                if (passWord == rePassWord)
                {
                    msg = "Registraion is successfull.\nThank You..!!"
                    title = "SUCESS..😎.!!"
                      registerModel?.addData(userName: name, userEmail: email, passWord: passWord)
                    mRegisterProtocolObj?.showSuccess(str: msg, title:title)
                    
                }
                else
                {
                    msg = "PassWord and  RePassWord..Miss Matching😣"
                    title = "!!OOPS..😣.!!"
                    mRegisterProtocolObj?.showFailure(str: msg, title:title)

                    
                    
                }
                
                
               
            }
            else{
                msg = "Please enter the Valid PassWord..😣"
                title = "!!OOPS..😣.!!"
                check = false
                mRegisterProtocolObj?.showFailure(str: msg,title:title)
             
                
            }
           
        }
        else
        {
            msg = "Please enter the Valid Email..😣"
            title = "!!OOPS..😣.!!"
            mRegisterProtocolObj?.showFailure(str:msg,title:title)
       
        
        }
    }

}
