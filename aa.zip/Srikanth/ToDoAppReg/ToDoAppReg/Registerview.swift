//
//  Registerview.swift
//  ToDoAPP
//
//  Created by BridgeLabz on 13/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

/*
 Register view 
 It takes the input from the user and passes to the 
 register Presenter....
 */



import UIKit
import Foundation


class Registerview: UIViewController,registerProtocolDelegate
{
// RegisterPresenter clsss reference is created
    
    
    // input data of the user is taken by using the TextField
    @IBOutlet weak var fullNameTextField: UITextField!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passWordTextField: UITextField!
    
    
    @IBOutlet weak var RePassWordTextField: UITextField!
  
    //action function
    @IBAction func registerValidation(_ sender: Any)
    {
        registerPresenter?.validateData(name:fullNameTextField.text!,email: emailTextField.text!, passWord: passWordTextField.text!,rePassWord: RePassWordTextField.text!)
    
        
    }
    
    var registerPresenter:RegisterPresenter?
    
    
    
    // This Method will run when  the page is loaded
    override func viewDidLoad()
    {
        super.viewDidLoad()
        registerPresenter = RegisterPresenter(registerProtocolObj: self)
    }
    
    //alert function if validation fails
    func displayMessageError(mesg: String,title:String)
    {
        let alert = UIAlertController(title: title, message: mesg, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style:.default, handler: nil)
        alert.addAction(action)
        present(alert,animated: true,completion: nil)

    }
    
    
    
   // alert function if validation success
    func displayMessageSuccess(mesg: String, title:String)
    {
          let myAlert = UIAlertController(title: title, message: mesg, preferredStyle:UIAlertControllerStyle.alert)
           let myAction = UIAlertAction(title: "👍🏻 OK", style: UIAlertActionStyle.default) { action in
            self.dismiss(animated: true, completion: nil)}
             myAlert.addAction(myAction)
           self.present(myAlert,animated:true,completion: nil)
    }
    
    
    
    // protocol function to show the validation success
    func showSuccess(str:String,title:String){
        displayMessageSuccess(mesg: str, title: title)
    }
    
    
    
    // protocol function to show the validation fails
    func showFailure(str:String,title:String){
        
        displayMessageError(mesg: str, title: title)
        
    }

    
    
    
    
}
