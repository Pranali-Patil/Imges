//
//  RegisterModel.swift
//  ToDoAppReg
//
//  Created by BridgeLabz on 13/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import Foundation

class RegisterModel
{

    func addData(userName:String,userEmail:String,passWord:String)
 {
    UserDefaults.standard.setValue(userName, forKey:"userName")
    UserDefaults.standard.setValue(userEmail, forKey:"userEmail")
    UserDefaults.standard.setValue(passWord, forKey: "password")
    
    }
    
    


}
