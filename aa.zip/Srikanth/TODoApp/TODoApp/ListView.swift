//
//  ListView.swift
//  TODoApp
//
//  Created by BridgeLabz on 14/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import UIKit

class ListView: UIViewController,UITableViewDelegate,UITableViewDataSource
{

    
  //  @IBOutlet weak var tableViewList: UITableView!
    @IBOutlet weak var menuButton: UIBarButtonItem!
    var titleData = NSArray()
    var descriptionData = NSArray()
    var  listPresenter  = ListPresenter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if self.revealViewController() != nil
        {
            menuButton.target = self.revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
    
    }
    
   
        
        func tableView(_ tableView: UITableView,
                       numberOfRowsInSection section: Int) -> Int {
            return 3
        }
        
        func tableView(_ tableView: UITableView,
                       cellForRowAt indexPath: IndexPath)
            -> UITableViewCell {
                let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",for: indexPath)
           cell.
                
                return cell
        }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        titleData = listPresenter.getTitleDetaiils()
        descriptionData = listPresenter.getDescriptionDetaiils()
       
    }

}


   


