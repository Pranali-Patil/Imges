//
//  AddTaskView.swift
//  TODoApp
//
//  Created by BridgeLabz on 15/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import UIKit

class AddTaskView: UIViewController,addTaskProtocolDelegate {

     @IBOutlet weak var menuButton: UIBarButtonItem!
    @IBOutlet weak var taskNameTextField: UITextField!
    @IBOutlet weak var taskDescriptionTextField: UITextField!
    var addTaskPresenter : AddTasKPresenter?
    override func viewDidLoad() {
        super.viewDidLoad()
      
         addTaskPresenter = AddTasKPresenter(addTaskProtocolObj: self)
        if self.revealViewController() != nil
        {
            menuButton.target = self.revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
    }

    @IBAction func saveActionButton(_ sender: UIButton)
    {
        addTaskPresenter?.addTask(title: taskNameTextField.text!, description: taskDescriptionTextField.text!)
        
    }
    @IBAction func clearActionButton(_ sender: UIButton)
    {
        taskNameTextField.text = ""
        taskDescriptionTextField.text = ""
    }
    //alert function if validation fails
    func displayMessageError(mesg: String,title:String)
    {
        let alert = UIAlertController(title: title, message: mesg, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style:.default, handler: nil)
        alert.addAction(action)
        present(alert,animated: true,completion: nil)
        
    }
    
    
   
    
    // alert function if validation success
    func displayMessageSuccess(mesg: String, title:String)
    {
        let myAlert = UIAlertController(title: title, message: mesg, preferredStyle:UIAlertControllerStyle.alert)
        let myAction = UIAlertAction(title: "👍🏻 OK", style: UIAlertActionStyle.default) { action in
            self.dismiss(animated: true, completion: nil)}
        myAlert.addAction(myAction)
        self.present(myAlert,animated:true,completion: nil)
    }
    
    
    
    // protocol function to show the validation success
    func showSuccess(msg:String,title:String){
        displayMessageSuccess(mesg: msg, title: title)
    }
    
    
    
    // protocol function to show the validation fails
    func showFailure(msg:String,title:String){
        
        displayMessageError(mesg: msg, title: title)
        
    }

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
