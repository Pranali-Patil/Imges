//
//  AddTaskModel.swift
//  TODoApp
//
//  Created by BridgeLabz on 15/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import UIKit
import CoreData
class AddTaskModel
{
    

    func save(title: String,description: String) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let task = Task(context:context)
        task.title = title
        task.taskDetails = description
       (UIApplication.shared.delegate as! AppDelegate).saveContext()
    
    }
    
}

   
    

    


