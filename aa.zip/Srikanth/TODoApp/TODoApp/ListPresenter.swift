//
//  ListPresenter.swift
//  TODoApp
//
//  Created by BridgeLabz on 14/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import Foundation


class ListPresenter:NSObject
 {
    var titleData = NSArray()
    var descriptionData = NSArray()
    var listModel = ToDoModel()
    func getTitleDetaiils()->NSArray
       {
     titleData = listModel.getTitleDetails()
    return titleData
    }
    func getDescriptionDetaiils()->NSArray
    {
        
        descriptionData = listModel.getDescription()
        return descriptionData
        
    }
    
}
