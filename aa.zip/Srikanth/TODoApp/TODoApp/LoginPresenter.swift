//
//  LoginPresenter.swift
//  ToDoAppReg
//
//  Created by BridgeLabz on 13/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import Foundation

protocol loginProtocolDelegate {
    func showSuccess(str:String,title:String)
    func showFailure(str:String,title:String)
}
class LoginPresenter:NSObject
{
    var msg:String?
    var title:String?
    var userEmail:String?
    var userPassWord:String?
    var mLoginProtocolObj:loginProtocolDelegate?

    
    
    init(loginProtocolObj:loginProtocolDelegate)
    {
        mLoginProtocolObj = loginProtocolObj
        
    }
    func validate(loginEmail:String,loginPassWord:String) 
    {
        userEmail = UserDefaults.standard.value(forKey: "userEmail") as? String
        userPassWord = UserDefaults.standard.value(forKey: "password") as? String
        if(userEmail == loginEmail)
        {
            if(userPassWord == loginPassWord)
            {
                msg = "Thank You..!!"
                title = "Success...!!"
                mLoginProtocolObj?.showSuccess(str: msg!, title: title!)
                
            }
            else
            {
              msg = "Invalid passWord....!!"
              title = "Wrong...!!"
              mLoginProtocolObj?.showFailure(str: msg!, title: title!)
                
            }
            
        }
        else{
            msg = "Invalid Email..!!"
            title = "Wrong...!!"
            mLoginProtocolObj?.showFailure(str: msg!, title: title!)
            
        }
        
    }
    
   
}
