//
//  AddTaskPresenter.swift
//  TODoApp
//
//  Created by BridgeLabz on 15/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import Foundation
protocol addTaskProtocolDelegate
{
    func showSuccess(msg:String,title:String)
    func showFailure(msg:String,title:String)
}



class AddTasKPresenter:NSObject
{
    
    //protocol object
    var mAddTaskProtocolObj : addTaskProtocolDelegate?
 var  msg = ""
 var alertTitle = ""
    var addTaskModel = AddTaskModel()
        init(addTaskProtocolObj:addTaskProtocolDelegate)
    {
        mAddTaskProtocolObj = addTaskProtocolObj
    }
    func addTask(title:String,description:String)
    {
        if(title.isEmpty)
        {
            msg = "Please  Give the Title name of the task ..."
            alertTitle = "!!OOPS..😣.!!"
            mAddTaskProtocolObj?.showFailure(msg: msg, title: alertTitle)
        }
        else
        {
            if (description.isEmpty) {
                msg = "Please  decscribe the Task ..."
                alertTitle = "!!OOPS..😣.!!"
                mAddTaskProtocolObj?.showFailure(msg: msg, title: alertTitle)
            }
            else {
          addTaskModel.save(title: title, description: description)
                msg = " Task is added ..."
                alertTitle = "SUCESS..😎.!!"
                mAddTaskProtocolObj?.showSuccess(msg: msg, title: alertTitle)
    }
    
    
    }
}
}
