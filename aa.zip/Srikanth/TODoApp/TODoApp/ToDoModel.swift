//
//  ToDoModel.swift
//  TODoApp
//
//  Created by BridgeLabz on 15/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class ToDoModel   {
    var taskData = [NSManagedObject]()
    var titeData = NSArray()
    var descriptionData = NSArray()
    var title:String = ""
    var description:String = ""
    var i:Int = 0
    
    func fetchData()
    {
        let context = (UIApplication.shared.delegate as!AppDelegate).persistentContainer.viewContext
        do{
            taskData = try context.fetch(Task.fetchRequest())as![NSManagedObject]
            
        }
        catch let error as NSError
        {
            print("could not fetch \(error)")
        }
        
        for i in 0..<taskData.count
        {
           title = (taskData[i].value(forKey: "title") as? String)!
            titeData.adding(title)
            description = (taskData[i].value(forKey: "taskDetails") as? String)!
            descriptionData.adding(description)
        }
    }
    func getTitleDetails()->NSArray
    {
        fetchData()
        return titeData
    }
    func getDescription()->NSArray
    {
        fetchData()
        return descriptionData
    }
}
