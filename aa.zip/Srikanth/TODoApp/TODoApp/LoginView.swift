//
//  LoginView.swift
//  ToDoAppReg
//
//  Created by BridgeLabz on 13/04/17.
//  Copyright © 2017 BridgeLabz. All rights reserved.
//

import UIKit

class LoginView: UIViewController,loginProtocolDelegate {

    @IBOutlet weak var userPassWordTextField: UITextField!
    @IBOutlet weak var userLoginEmailTextField: UITextField!
    var loginPresenter:LoginPresenter?
    override func viewDidLoad() {
        super.viewDidLoad()
      loginPresenter = LoginPresenter(loginProtocolObj: self)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func loginValidationButton(_ sender: UIButton)
    {
    loginPresenter?.validate(loginEmail: userLoginEmailTextField.text!, loginPassWord: userPassWordTextField.text!)
            
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func displayMessageError(mesg: String,title:String)
    {
        let alert = UIAlertController(title: title, message: mesg, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style:.default, handler: nil)
        alert.addAction(action)
        present(alert,animated: true,completion: nil)
        
    }
    
 
    func showFailure(str: String, title: String)
    {
        displayMessageError(mesg: str, title: title)
    }
    
    func showSuccess(str: String, title: String)
    {
       displayMessageSuccess(mesg: str, title: title)
        
    }
    
    
    
    // alert function if validation success
    func displayMessageSuccess(mesg: String, title:String)
    {
        let myAlert = UIAlertController(title: title, message: mesg, preferredStyle:UIAlertControllerStyle.alert)
        let myAction = UIAlertAction(title:"👍🏻 OK", style: .default, handler:  { action in
            self.performSegue(withIdentifier: "todo", sender: self) })
        myAlert.addAction(myAction)
        present(myAlert,animated:true,completion: nil)
        
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
