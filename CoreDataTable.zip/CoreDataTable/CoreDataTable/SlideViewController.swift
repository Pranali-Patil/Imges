//
//  SlideViewController.swift
//  CoreDataTable
//
//  Created by gaurav on 05/04/17.
//  Copyright © 2017 Alk. All rights reserved.
//

import UIKit

class SlideViewController: UIViewController {

   //Remove outlate
    @IBOutlet weak var barbtnMenu: UIBarButtonItem!
   
       override func viewDidLoad() {
        super.viewDidLoad()
        barbtnMenu.target=revealViewController()
        barbtnMenu.action=#selector(SWRevealViewController.revealToggle(_:))
        
    }
    
//Stive
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        let menuBtn = UIButton(frame: CGRect(x: 0, y: 0, width: 40, height: 30))
//            menuBtn.backgroundColor = UIColor.blue
//        menuBtn.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
//        let leftBarBtn = UIBarButtonItem(customView: menuBtn)
//        self.navigationItem.leftBarButtonItem = leftBarBtnßß
//       //barbtnMenu.target = self.revealViewController()
//        //barbtnMenu.action = #selector(SWRevealViewController.revealToggle(_:))
//        
//
//        // Do any additional setup after loading the view.
//    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
