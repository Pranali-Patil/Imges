//
//  CollectionViewCell.swift
//  CoreDataTable
//
//  Created by gaurav on 03/04/17.
//  Copyright © 2017 Alk. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var olblTitle: UILabel!
    @IBOutlet weak var lblDisc: UILabel!
    
    
   
 //   @IBOutlet weak var imageView: UIImageView!
}
