//
//  ContainerViewController.swift
//  CoreDataTable
//
//  Created by gaurav on 04/04/17.
//  Copyright © 2017 Alk. All rights reserved.
//

import UIKit

class ContainerViewController: UIViewController {

    @IBOutlet weak var container1: UIView!
    
    @IBOutlet weak var container2: UIView!
    
    
    @IBAction func segmentbtn(_ sender: Any) {
        if((sender as AnyObject).selectedSegmentIndex==0)
        {
            UIView.animate(withDuration: 0.5, animations:{
                self.container1.alpha=0.0
                self.container2.alpha=1.0
            })
        }
        else{
            UIView.animate(withDuration: 0.5, animations: {
                self.container1.alpha=1.0
                self.container2.alpha=0.0
            })
        }
    }

    
  //  }


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
