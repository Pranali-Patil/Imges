//
//  CollViewController.swift
//  CoreDataTable
//
//  Created by gaurav on 03/04/17.
//  Copyright © 2017 Alk. All rights reserved.
//

import UIKit
import CoreData


class CollViewController: UIViewController ,UICollectionViewDataSource,UICollectionViewDelegate {
    
    var List :Array<AnyObject>=[]

    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var barbtnMenu: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //HIDE BACK BUTTON
        self.navigationItem.setHidesBackButton(true, animated:true);
        barbtnMenu.target=revealViewController()
        barbtnMenu.action=#selector(SWRevealViewController.revealToggle(_:))
        
    }

    
    
//    var imglist=["NarendraModi.jpeg","RajnathSingh.jpeg"]
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return List.count

    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell=collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for:indexPath) as! CollectionViewCell
      //  cell.imageView.image=UIImage(named:imglist[indexPath.row])
        let data: NSManagedObject = List[indexPath.row] as! NSManagedObject
        
        cell.olblTitle?.text = data.value(forKey: "title") as? String
        cell.lblDisc?.text = data.value(forKey: "disc") as? String
        cell.layer.borderWidth=0.5

        
        
        
        return cell
    }

    override func viewDidAppear(_ animated: Bool) {
        let AppDel: AppDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let managedObjectContext = AppDel.persistentContainer.viewContext as! NSManagedObjectContext
        let Context = managedObjectContext
        
        // let Context: NSManagedObjectContext = AppDel.managedObjectContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "DataList")
        
        
        List = try! Context.fetch(request)
        
        collectionView.reloadData()
    }

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "update" {
            var locationsList = [NSIndexPath: NSManagedObject]()
            let indexPath: NSIndexPath = self.collectionView.indexPathsForSelectedItems!.first! as NSIndexPath
            let selectedRow: NSManagedObject = locationsList[indexPath]!
            
            
      //      let selectedItem: NSManagedObject = List[self.collectionView.indexPathForSelectedRow!.row] as! NSManagedObject
            
            let ViewCon: AddViewController = segue.destination as! AddViewController
            
            ViewCon.title2 = selectedRow.value(forKey: "title") as! String
            ViewCon.disc = selectedRow.value(forKey: "disc") as! String
            
            ViewCon.existingItem = selectedRow
        }
    }

    */
}
