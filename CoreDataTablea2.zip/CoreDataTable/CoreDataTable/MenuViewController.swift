//
//  MenuViewController.swift
//  CoreDataTable
//
//  Created by gaurav on 05/04/17.
//  Copyright © 2017 Alk. All rights reserved.
//

import UIKit
var touch : UITouch!


class MenuViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,UINavigationControllerDelegate,UIImagePickerControllerDelegate
{

    @IBOutlet weak var imgProfile: UIImageView!
    
    @IBOutlet weak var tblView: UITableView!
    let menuicon=["NarendraModi.jpeg","RajnathSingh.jpeg","Arun Jetaly.jpeg","SushmaSwaraj.jpeg"];
    let menuarry=["NarendraModi","RajnathSingh","Arun Jetaly","SushmaSwaraj"];
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.revealViewController().rearViewRevealWidth = self.view.bounds.width - 100
//        // Do any additional setup after loading the view.
    }

//    func numberOfSections(in tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 1
//    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuarry.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:MenuTableViewCell = tableView.dequeueReusableCell(withIdentifier: "Cell2") as! MenuTableViewCell
        
        cell.imgMenuList.text=menuarry[indexPath.row];
        //cell.cellDesc.text=desglist[indexPath.row];
        let img=UIImage(named: menuicon[indexPath.row]);
        cell.imgMenuIcon.image=img;
        
        return cell
    }

//----------------For Img Picker----------
    
    var loc = CGPoint(x: 0, y: 0)
    
    @IBAction func btnProfilechange(_ sender: Any) {
        let image = UIImagePickerController()
        image.delegate=self
        image.sourceType=UIImagePickerControllerSourceType.photoLibrary
        image.allowsEditing=false
        self.present(image,animated: true)
        {
            //
        }
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            imgProfile.image = image
        }
        else{
            //Error
        }
        self.dismiss(animated: true, completion: nil)

//        //---------------for save the imgage in userDefaults------------------
//
        //let img=UIImage(named:"anushka.png")
//        let img=imgProfile.image
//        let imagedata:NSData=UIImagePNGRepresentation(img!)! as NSData
//        UserDefaults.standard.set(img, forKey: "savedata") as! NSData
//        let data=UserDefaults.standard.object(forKey: "savedata")as! NSData
//        imgProfile.image=UIImage(data: data as Data)
//    
        
        
     /*
        //Save image
        let img = UIImage() //Change to be from UIPicker
        let data = UIImagePNGRepresentation(img)
        UserDefaults.standard.set(data, forKey: "myImageKey")
        UserDefaults.standard.synchronize()
        
        //Get image
        if let imgData = UserDefaults.standard.object(forKey: "myImageKey") as? NSData {
            let retrievedImg = UIImage(data: imgData as Data)
        
        imgProfile.image=retrievedImg
        
        }
       */
        
        
        
        
        
    }
    



    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
