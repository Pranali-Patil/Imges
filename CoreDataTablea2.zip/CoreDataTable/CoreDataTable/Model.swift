//
//  Model.swift
//  CoreDataTable
//
//  Created by gaurav on 27/03/17.
//  Copyright © 2017 Alk. All rights reserved.
//

import UIKit

import CoreData
class Model: NSManagedObject {
    @NSManaged var title :String
    @NSManaged var disc :String

}
